function RunScanTests()
    local V=GVoxel
    assert(V.ValidScanSize(16) and V.ValidScanSize(32))
    assert(not V.ValidScanSize(0) and not V.ValidScanSize(24) and not V.ValidScanSize(255))
    for _,metres in ipairs({16,32}) do
        local center=Vector(100,-200,30)
        local r=V.NewScanRegion(10,center,metres)
        assert(#r.values==33^3,"scan lattice must cover all three dimensions")
        assert(math.abs(r.side*0.0254-metres)<1e-10,"metre conversion incorrect")
        assert((r.origin+Vector(r.side,r.side,r.side)/2):DistToSqr(center)<1e-12,"scan is not centered on aim")
        local seen={}
        for i=0,33^3-1 do
            local p,x,y,z=V.ScanPoint(r,i)
            local index=V.Index(x,y,z,r)
            assert(not seen[index],"duplicate scan coordinate") seen[index]=true
            assert(index==i+1,"linear sampling order differs")
            assert((p-r.origin-Vector(x,y,z)*r.step):LengthSqr()<1e-12)
        end
        local chunks=0
        V.ForChunks(function() chunks=chunks+1 end,r)
        assert(chunks==64,"scan cube must have 64 chunks")
        local p=V.ScanPoint(r,33^3-1)
        assert(p:DistToSqr(r.origin+Vector(r.side,r.side,r.side))<1e-12,"last cube corner not sampled")
    end
    print("PASS: 16/32 metre centered cubes, all 35937 nodes and 64 chunks")

    local state={}
    assert(V.ReloadGesture(state,true,0,true)==nil)
    assert(V.ReloadGesture(state,false,0.1,true)=="tap","short R did not request analysis")
    assert(V.ReloadGesture(state,false,0.2,true)==nil,"release repeated the action")
    assert(V.ReloadGesture(state,true,1,true)==nil)
    assert(V.ReloadGesture(state,true,1.5,true)=="menu","held R did not open menu")
    assert(V.ReloadGesture(state,true,1.6,true)==nil,"menu opened repeatedly")
    assert(V.ReloadGesture(state,false,1.7,true)=="release_menu","long release triggered analysis")
    V.ReloadGesture(state,true,2,true)
    assert(V.ReloadGesture(state,false,2.6,true)=="menu","long press across stalled frames became a tap")
    V.ReloadGesture(state,true,3,true)
    V.ReloadGesture(state,true,3.1,false)
    assert(V.ReloadGesture(state,false,3.2,true)==nil,"weapon switch/menu should cancel pending tap")
    print("PASS: short R, hold R, single dispatch, stalled frame and focus cancellation")

    local r=V.NewScanRegion(11,Vector(),16)
    local rays=0
    -- Infinite horizontal brush half-space with a known surface at z=3.7.
    local function planeTrace(a,b,displacement)
        rays=rays+1
        local belowA,belowB=a.z<3.7,b.z<3.7
        if belowA and not displacement then
            local fraction=(3.7-a.z)/(b.z-a.z)
            return {StartSolid=true,AllSolid=belowB,FractionLeftSolid=not belowB and fraction or 0}
        end
        if not belowA and belowB then
            local fraction=(3.7-a.z)/(b.z-a.z)
            return {Hit=true,HitWorld=true,HitPos=a+(b-a)*fraction,HitNormal=Vector(0,0,1),
                HitTexture=displacement and "**displacement**" or "concrete"}
        end
        return {}
    end
    for _,z in ipairs({-8,0,8,16}) do
        local p=Vector(0,0,z)
        local value=V.ScanDensity(r,p,z<3.7,function(a,b) return planeTrace(a,b,false) end)
        assert(math.abs(value-(z-3.7))<0.02,"brush signed surface distance differs")
        local displaced=V.ScanDensity(r,p,false,function(a,b) return planeTrace(a,b,true) end)
        assert(math.abs(displaced-(z-3.7))<0.02,"displacement orientation not detected")
    end
    assert(rays==4*2*6,"expected all six directions at every node")
    local solid=V.ScanDensity(r,Vector(),true,function() return {StartSolid=true,AllSolid=true} end)
    assert(solid<0,"solid cube interior was discarded")
    local empty=V.ScanDensity(r,Vector(),false,function() return {} end)
    assert(empty>0,"empty volume was filled")
    local staticProp=V.ScanDensity(r,Vector(0,0,8),false,function(a,b)
        local hit=planeTrace(a,b,false) hit.HitTexture="**studio**" return hit
    end)
    assert(staticProp>0,"static prop should not become brush terrain")
    print("PASS: six-axis sampling, brush distances, displacement orientation and full/empty interiors")

    -- Exercise the same extractor on metric scan data, including a hollow volume.
    local shell=V.NewScanRegion(12,Vector(500,200,-50),32)
    local center=shell.base
    local radius=shell.side*0.3
    for i=0,33^3-1 do
        local p,x,y,z=V.ScanPoint(shell,i)
        shell.values[V.Index(x,y,z,shell)]=math.abs(math.sqrt(p:DistToSqr(center))-radius)-shell.step*1.8
    end
    local vertices=0
    V.ForChunks(function(x,y,z)
        local chunk=V.BuildChunk(shell,x,y,z)
        assert(#chunk<65535 and #chunk%3==0,"metric chunk mesh invalid")
        for _,v in ipairs(chunk) do
            assert(v.pos.x>=-0.001 and v.pos.x<=shell.step*8+0.001,"metric mesh uses old chunk size")
        end
        vertices=vertices+#chunk
    end,shell)
    assert(vertices>0,"metric volume mesh is empty")
    print("PASS: metric cube extraction preserves a 3D hollow volume")
end

local V=GVoxel
local old,files,objects,callbacks={},{},{},{}
local scans,scan,failCommit,restored={},nil,false,0
function InstallZoneStoreFixtures()
    old.file=file old.hook=hook old.map=game.GetMap old.error=ErrorNoHalt
    old.crc=util.CRC old.json=util.TableToJSON old.parse=util.JSONToTable old.compress=util.Compress old.decompress=util.Decompress
    old.sessions=V.GetScanSessions old.session=V.GetScanSession old.restore=V.RestoreCachedZone
    hook={Add=function(_,name,fn) callbacks[name]=fn end}
    game.GetMap=function() return "test_map" end
    ErrorNoHalt=function() end
    util.CRC=function(s) local n=0 for i=1,#s do n=(n*33+s:byte(i))%4294967296 end return tostring(n) end
    util.TableToJSON=function(t) local key="json"..(#objects+1) objects[#objects+1]=t return key end
    util.JSONToTable=function(s) local n=tonumber(s:match("^json(%d+)$")) return n and objects[n] end
    util.Compress=function(s) return s end
    util.Decompress=function(s,limit) assert(limit==4*1024*1024,"unbounded cache decompression") return s end
    file={CreateDir=function() end,Open=function()
        return {Read=function() return string.rep("x",1036) end,Size=function() return 1000000 end,Close=function() end}
    end,Write=function(path,data) files[path]=data end,Read=function(path) return files[path] end,
        Size=function(path) return files[path] and #files[path] or -1 end,Exists=function(path) return files[path]~=nil end,
        Delete=function(path) files[path]=nil end,Rename=function(a,b)
            if failCommit and a:find(".pending.dat",1,true) then return false end
            if not files[a] then return false end files[b]=files[a] files[a]=nil return true
        end,Find=function(pattern)
            local folder,glob=pattern:match("^(.-)/([^/]+)$")
            local match="^"..glob:gsub("%.","%%."):gsub("%*",".*").."$"
            local names={}
            for path in pairs(files) do
                local dir,name=path:match("^(.-)/([^/]+)$")
                if dir==folder and name:match(match) then names[#names+1]=name end
            end
            table.sort(names) return names
        end}
    local r=V.NewScanRegion(8801,Vector(),16)
    for i=0,33^3-1 do r.values[i]=r.step end
    scan={completed=true,region=r,snapshot={values=r.values},history={}}
    scans={[r.id]=scan}
    V.GetScanSessions=function() return scans end
    V.GetScanSession=function(id) return scans[id] end
    V.RestoreCachedZone=function(record) restored=restored+1 return {region={id=999},savedKey=record.key} end
end
function RunZoneStoreTests()
    local function pump()
        for _=1,2000 do callbacks["GVoxel.ZoneStorage"]() if not scan.saving then return end end
        error("queued cache write did not finish")
    end
    V.EnsurePersistentZone(scan)
    assert(scan.saving,"completed zone was not automatically queued for persistence") pump()
    local key=assert(scan.savedKey)
    local path="gvoxel/zones/test_map/"..key
    local first=assert(files[path])
    local originalName=V.GetZoneLibrary()[key].name
    assert(not V.GetZoneLibrary()[key].values and not V.GetZoneLibrary()[key].history,"catalogue retains the full field/journal after saving")
    assert(key=="zone_1_0.dat","zone does not use the single canonical map cache")
    failCommit=true assert(V.SaveZone(scan,"Renomme")) pump() failCommit=false
    assert(files[path]==first and V.GetZoneLibrary()[key].name==originalName,"failed commit discarded the previous valid cache")
    assert(not V.ZoneLibraryAction({admin=false},"delete",0,key),"non-admin deleted a server save")
    local admin=_ScanFixture.ply admin.admin=true
    assert(not V.ZoneLibraryAction(admin,"load",0,"../escape.dat"),"client supplied arbitrary cache path")
    files[path..".previous.dat"]=files[path] files[path]=nil scans={}
    files["gvoxel/zones/test_map/zone_2_19.dat"]=first
    callbacks["GVoxel.LoadZoneCaches"]()
    assert(files[path]==first,"startup did not recover a cache interrupted during rename")
    callbacks["GVoxel.ZoneStorage"]()
    assert(restored==1,"server boot did not automatically restore its saved zone")
    assert(V.ZoneLibraryAction(admin,"delete",0,key))
    callbacks["GVoxel.LoadZoneCaches"]()
    callbacks["GVoxel.ZoneStorage"]()
    assert(restored==1,"deleting the single cache resurrected an old multi-zone file")
    file=old.file hook=old.hook game.GetMap=old.map ErrorNoHalt=old.error
    util.CRC=old.crc util.TableToJSON=old.json util.JSONToTable=old.parse util.Compress=old.compress util.Decompress=old.decompress
    V.GetScanSessions=old.sessions V.GetScanSession=old.session V.RestoreCachedZone=old.restore
    print("PASS: actual queued cache store verifies writes, preserves previous cache on rename failure, recovers interrupted replacement, rejects unauthorized paths and auto-restores at boot")
end

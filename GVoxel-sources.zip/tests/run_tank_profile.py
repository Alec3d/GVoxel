"""Profile tank brush CPU with the installed LuaJIT, without launching GMod."""
from pathlib import Path
import argparse
import ctypes
import os
import zipfile

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--report", type=Path)
parser.add_argument("--geometry", type=Path, help="Alternative geometry source for before/after CPU comparisons")
parser.add_argument("--explosions-only", action="store_true", help="Measure only the actual seeded RPG/tank impacts")
parser.add_argument("--detail", action="store_true", help="Instrument nested CPU work (adds overhead; not a latency benchmark)")
parser.add_argument("--compare-upper-core", action="store_true",
                    help="Compare the previous inscribed-sphere test with the production upper-core test in memory")
args = parser.parse_args()
ROOT = Path(__file__).resolve().parents[1]
GAME = ROOT.parent.parent.parent.parent
handles = [os.add_dll_directory(str(path)) for path in (GAME / "bin/win64", GAME / "bin") if path.is_dir()]
lua = ctypes.CDLL(str(GAME / "bin/win64/lua_shared.dll"))
lua.luaL_newstate.restype = ctypes.c_void_p
for name, types in {
    "luaL_openlibs": [ctypes.c_void_p],
    "luaL_loadbuffer": [ctypes.c_void_p, ctypes.c_char_p, ctypes.c_size_t, ctypes.c_char_p],
    "lua_pcall": [ctypes.c_void_p, ctypes.c_int, ctypes.c_int, ctypes.c_int],
    "lua_getfield": [ctypes.c_void_p, ctypes.c_int, ctypes.c_char_p],
    "lua_tolstring": [ctypes.c_void_p, ctypes.c_int, ctypes.c_void_p],
    "lua_close": [ctypes.c_void_p],
}.items():
    getattr(lua, name).argtypes = types
lua.lua_tolstring.restype = ctypes.c_char_p
state = lua.luaL_newstate()
if not state:
    raise RuntimeError("LuaJIT state creation failed")


def execute(source, name):
    if isinstance(source, str):
        source = source.encode()
    if lua.luaL_loadbuffer(state, source, len(source), name.encode()) or lua.lua_pcall(state, 0, 0, 0):
        raise RuntimeError(lua.lua_tolstring(state, -1, None).decode("utf-8", "replace"))


try:
    lua.luaL_openlibs(state)
    execute("_PROFILE_MESSAGES={}; print=function(s) _PROFILE_MESSAGES[#_PROFILE_MESSAGES+1]=tostring(s) end", "capture_profile")
    if args.explosions_only:
        execute("_PROFILE_EXPLOSIONS_ONLY=true", "profile_explosions_only")
    for path in (
        "tests/field_spec.lua", "tests/float_vectors.lua",
        "lua/gvoxel/sh_field.lua", "lua/gvoxel/sh_crater.lua",
        "lua/gvoxel/sh_features.lua", "lua/gvoxel/sh_scan.lua",
        "lua/gvoxel/sh_mask.lua", "lua/gvoxel/sh_sculpt.lua",
        "lua/gvoxel/sh_collision.lua", "tests/bsp_spec.lua",
        "lua/gvoxel/sh_bsp.lua", "lua/gvoxel/sh_bsp_geometry.lua",
    ):
        if args.geometry and path.endswith("sh_bsp_geometry.lua"):
            if zipfile.is_zipfile(args.geometry):
                with zipfile.ZipFile(args.geometry) as archive:
                    source = archive.read("sh_bsp_geometry.lua")
            else:
                source = args.geometry.read_bytes()
        else:
            source = (ROOT / path).read_bytes()
        execute(source, path)
    profile = (ROOT / "tests/profile_tank.lua").read_bytes()
    execute("concommand={Add=function() end}; IsValid=function(e) return type(e)=='table' and e.valid~=false end", "tank_profile_adapters")
    execute((ROOT / "lua/gvoxel/sv_tank.lua").read_bytes(), "sv_tank")
    if args.detail:
        execute('''
local counters,stack={},{}
for _,name in ipairs({"BSPCell", "BSPCellSolids", "BSPPieceHull", "ApplyBSPBrushPlanes", "ClipBSPPolygon"}) do
    local original=GVoxel[name]
    local counter={calls=0,total=0,self=0}; counters[name]=counter
    GVoxel[name]=function(...)
        local frame={start=os.clock(),child=0}; stack[#stack+1]=frame
        local a,b=original(...)
        local elapsed=os.clock()-frame.start; stack[#stack]=nil
        if stack[#stack] then stack[#stack].child=stack[#stack].child+elapsed end
        counter.calls=counter.calls+1; counter.total=counter.total+elapsed; counter.self=counter.self+elapsed-frame.child
        return a,b
    end
end
function ProfileExplosionDetails()
    for name,c in pairs(counters) do
        print(string.format("DETAIL %s calls=%d inclusive=%.2f self=%.2f ms",name,c.calls,c.total*1000,c.self*1000))
        c.calls=0; c.total=0; c.self=0
    end
end
''', "detail_adapters")
    if args.compare_upper_core:
        geometry = (ROOT / "lua/gvoxel/sh_bsp_geometry.lua").read_text(encoding="utf-8")
        previous = geometry
        for current, old in (
            ("V.BrushInnerRadius(last.radius,last.seed)",
             "V.BrushInnerRadius(last.radius,last.seed,last.center.z,last.floorZ)"),
        ):
            if previous.count(current) != 1:
                raise RuntimeError("Production shortcut changed; review this in-memory comparison")
            previous = previous.replace(current, old)
        early = """    if lastIndexed then
        low=Vector(x,y,z)*r.step high=low+Vector(1,1,1)*r.step
        -- A final interior has no original face left to recover.
        -- Decide before displacement triangulation/BSP occupancy work.
        if fillWholeBrushCell(r,low,high,lastIndexed,result) then cache[key]=result return result end
    end
"""
        if previous.count(early) != 1:
            raise RuntimeError("Production early-out changed; review this in-memory comparison")
        previous = previous.replace(early, "")
        execute(previous, "previous_inscribed_sphere_in_memory")
        execute('print("VERSION TANK: previous inscribed-sphere classification (in-memory comparison only)")', "version_previous")
        execute(profile, "profile_tank_previous")
        execute(geometry, "production_upper_core")
        execute('print("VERSION TANK: production spherical-core intersection with upper half-space")', "version_production")
    execute(profile, "profile_tank")
    execute('_PROFILE_LOG=table.concat(_PROFILE_MESSAGES,"\\n")', "profile_log")
    lua.lua_getfield(state, -10002, b"_PROFILE_LOG")
    output = lua.lua_tolstring(state, -1, None).decode("utf-8")
    print(output)
    if args.report:
        args.report.write_text(output + "\n", encoding="utf-8")
finally:
    lua.lua_close(state)

"""Run standard Lua tests using the LuaJIT DLL shipped with this Garry's Mod install.

No game process is started and no third-party package is required.
"""
import ctypes
import os
import argparse
from pathlib import Path

parser = argparse.ArgumentParser(description=__doc__)
mode = parser.add_mutually_exclusive_group()
for flag in ("displacements", "profile", "profile-latency", "profile-visibility", "inspect-joins", "terrain-coverage", "profile-option-a", "profile-holes", "vehicles", "lighting", "tank", "custom-block", "navigation", "ballistics", "visibility", "zones"):
    mode.add_argument("--" + flag, action="store_true")
parser.add_argument("--map", type=Path, help="Additional real BSP layer regression")
parser.add_argument("--report", type=Path, help="Save the complete validation output as UTF-8")
parser.add_argument("--baseline", type=Path, help="Compare hole CPU/geometry against an archived addon ZIP (with --profile-holes)")
args = parser.parse_args()
if args.baseline and not args.profile_holes:
    parser.error("--baseline requires --profile-holes")
source_notes = []

ROOT = Path(__file__).resolve().parents[1]
GAME = ROOT.parent.parent.parent.parent
DLL_DIRS = [GAME / "bin" / "win64", GAME / "bin"]
handles = [os.add_dll_directory(str(p)) for p in DLL_DIRS if p.is_dir()]
lua = ctypes.CDLL(str(DLL_DIRS[0] / "lua_shared.dll"))
lua.luaL_newstate.restype = ctypes.c_void_p
lua.luaL_openlibs.argtypes = [ctypes.c_void_p]
lua.luaL_loadbuffer.argtypes = [ctypes.c_void_p, ctypes.c_char_p, ctypes.c_size_t, ctypes.c_char_p]
lua.luaL_loadbuffer.restype = ctypes.c_int
lua.lua_pcall.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_int, ctypes.c_int]
lua.lua_pcall.restype = ctypes.c_int
lua.lua_tolstring.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.POINTER(ctypes.c_size_t)]
lua.lua_tolstring.restype = ctypes.c_char_p
lua.lua_settop.argtypes = [ctypes.c_void_p, ctypes.c_int]
lua.lua_getfield.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_char_p]
lua.lua_setfield.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_char_p]
lua.lua_pushlstring.argtypes = [ctypes.c_void_p, ctypes.c_char_p, ctypes.c_size_t]
lua.lua_pushcclosure.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_int]
lua.lua_close.argtypes = [ctypes.c_void_p]
state = lua.luaL_newstate()
if not state:
    raise RuntimeError("LuaJIT state creation failed")


def check(status):
    if status:
        message = lua.lua_tolstring(state, -1, None).decode("utf-8", "replace")
        lua.lua_getfield(state, -10002, b"_VEHICLE_ADAPTER_ERROR")
        diagnostic = lua.lua_tolstring(state, -1, None)
        if diagnostic:
            message += "\n" + diagnostic.decode("utf-8", "replace")
        raise RuntimeError(message)


def execute(source, name):
    check(lua.luaL_loadbuffer(state, source, len(source), name.encode()))
    check(lua.lua_pcall(state, 0, 0, 0))


def compiled_chunk(source, name, global_name):
    """Leave a source chunk unexecuted until its Lua fixture is ready."""
    check(lua.luaL_loadbuffer(state, source, len(source), name.encode()))
    lua.lua_setfield(state, -10002, global_name.encode())


# GMod provides CompileString but removes Lua's upvalue mutation APIs. Model
# that environment instead of accidentally testing unrestricted DLL facilities.
@ctypes.CFUNCTYPE(ctypes.c_int, ctypes.c_void_p)
def compile_string_adapter(active_state):
    source = lua.lua_tolstring(active_state, 1, None) or b""
    name = lua.lua_tolstring(active_state, 2, None) or b"vehicle_method_test"
    lua.luaL_loadbuffer(active_state, source, len(source), name)
    # On error the top item is its diagnostic string, matching CompileString.
    return 1


def method_source(source, path):
    """Mount the exact executed source for debug line ranges/file.Read."""
    lua.lua_getfield(state, -10002, b"_VehicleMethodSources")
    lua.lua_pushlstring(state, source, len(source))
    lua.lua_setfield(state, -2, path.encode())
    lua.lua_settop(state, 0)
    execute(source, "@" + path)


def vehicle_source(family, name):
    """Read/hash installed Lua in memory; never extract or edit Workshop files."""
    from inspect_vehicle_sources import ARCHIVES, entries
    import hashlib

    archive = ARCHIVES[family]
    _, files = entries(archive)
    offset, size = next((offset, size) for path, offset, size in files if path == name)
    with archive.open("rb") as stream:
        stream.seek(offset)
        source = stream.read(size)
    note = f"SOURCE: {family} {name} sha256={hashlib.sha256(source).hexdigest()}"
    source_notes.append(note)
    print(note, flush=True)
    return source.replace(b"\r", b"")


def output_log():
    execute(b'_TEST_LOG = table.concat(_TEST_MESSAGES, "\\n")', 'validation_log')
    lua.lua_getfield(state, -10002, b"_TEST_LOG")
    output = lua.lua_tolstring(state, -1, None).decode("utf-8")
    print(output, flush=True)
    if args.report:
        args.report.write_text("\n".join([syntax_result, *source_notes, output]) + "\n", encoding="utf-8")



try:
    lua.luaL_openlibs(state)
    files = sorted((ROOT / "lua").rglob("*.lua"))
    for path in files:
        source = path.read_bytes()
        check(lua.luaL_loadbuffer(state, source, len(source), str(path).encode()))
        lua.lua_settop(state, 0)
    syntax_result = f"PASS: Lua 5.1 / LuaJIT syntax ({len(files)} files)"
    print(syntax_result, flush=True)
    # GMod's DLL redirects native print to an engine callback unavailable here.
    execute(b'_TEST_MESSAGES = {}; print = function(s) _TEST_MESSAGES[#_TEST_MESSAGES+1] = tostring(s) end', 'capture_print')
    execute((ROOT / "tests" / "field_spec.lua").read_bytes(), "field_spec")
    if args.terrain_coverage or args.profile_option_a or args.profile_holes or args.vehicles or args.tank or args.custom_block or args.navigation or args.ballistics or args.visibility:
        execute((ROOT / "tests" / "float_vectors.lua").read_bytes(), "float_vectors")
    execute((ROOT / "lua" / "gvoxel" / "sh_field.lua").read_bytes(), "sh_field")
    execute((ROOT / "lua" / "gvoxel" / "sh_crater.lua").read_bytes(), "sh_crater")
    execute((ROOT / "lua" / "gvoxel" / "sh_features.lua").read_bytes(), "sh_features")
    execute((ROOT / "lua" / "gvoxel" / "sh_scan.lua").read_bytes(), "sh_scan")
    execute((ROOT / "lua" / "gvoxel" / "sh_mask.lua").read_bytes(), "sh_mask")
    execute((ROOT / "lua/gvoxel/sh_zones.lua").read_bytes(), "sh_zones")
    execute((ROOT / "lua" / "gvoxel" / "sh_sculpt.lua").read_bytes(), "sh_sculpt")
    execute((ROOT / "lua/gvoxel/sh_custom_block.lua").read_bytes(), "sh_custom_block")
    execute((ROOT / "lua" / "gvoxel" / "sh_collision.lua").read_bytes(), "sh_collision")
    execute((ROOT / "lua" / "gvoxel" / "sh_bsp_light.lua").read_bytes(), "sh_bsp_light")
    if args.navigation or args.ballistics:
        execute((ROOT / "tests/bsp_spec.lua").read_bytes(), "bsp_spec")
        for module in ("sh_bsp", "sh_bsp_geometry", "sh_vehicle_world"):
            execute((ROOT / f"lua/gvoxel/{module}.lua").read_bytes(), module)
        execute((ROOT / "tests/props_spec.lua").read_bytes(), "props_spec")
        execute(b'GetConVar=function() return {GetFloat=function() return 600 end} end; FCVAR_REPLICATED=0; math.Clamp=function(x,a,b) return math.max(a,math.min(b,x)) end', "navigation_engine_adapters")
        for module in ("sh_move", "sv_props", "sv_nav_graph", "sv_navigation", "sv_actors"):
            execute((ROOT / f"lua/gvoxel/{module}.lua").read_bytes(), module)
        execute((ROOT / "tests/navigation_spec.lua").read_bytes(), "navigation_spec")
        if args.ballistics:
            execute((ROOT / "tests/ballistics_spec.lua").read_bytes(), "ballistics_spec")
            execute(b'ENT={}; AddCSLuaFile=function() end; TRANSMIT_NEVER=2', "projectile_contact_entity_adapters")
            execute((ROOT / "lua/entities/vm_projectile_stop.lua").read_bytes(), "projectile_contact_entity")
            execute(b'_ProjectileStopDefinition=ENT; ENT=nil', "projectile_contact_definition")
            execute((ROOT / "lua/gvoxel/sh_ballistics.lua").read_bytes(), "sh_ballistics")
            execute((ROOT / "lua/gvoxel/sv_projectiles.lua").read_bytes(), "sv_projectiles")
            execute(b"RunBallisticsTests(); RunProjectileFlightTests()", "run_ballistics")
        else:
            execute(b"RunZonePropTransitionTests(); RunNavigationTests()", "run_navigation")
        output_log()
        raise SystemExit(0)
    if args.custom_block:
        execute((ROOT / "tests/bsp_spec.lua").read_bytes(), "bsp_spec")
        for module in ("sh_bsp", "sh_bsp_geometry", "sh_scan_columns", "sh_vehicle_world"):
            execute((ROOT / f"lua/gvoxel/{module}.lua").read_bytes(), module)
        execute((ROOT / "tests/custom_block_spec.lua").read_bytes(), "custom_block_spec")
        execute(b"RunCustomBlockTests()", "run_custom_block")
        execute((ROOT / "tests/custom_block_ui_spec.lua").read_bytes(), "custom_block_ui_spec")
        compiled_chunk((ROOT / "lua/gvoxel/cl_custom_block.lua").read_bytes(), "custom_block_ui", "_CUSTOM_BLOCK_UI")
        compiled_chunk((ROOT / "lua/gvoxel/cl_tool.lua").read_bytes(), "custom_block_tool", "_CUSTOM_BLOCK_TOOL")
        execute(b"RunCustomBlockUITests(_CUSTOM_BLOCK_UI,_CUSTOM_BLOCK_TOOL)", "run_custom_block_ui")
        output_log()
        raise SystemExit(0)
    if args.tank:
        execute((ROOT / "tests/bsp_spec.lua").read_bytes(), "bsp_spec")
        for module in ("sh_bsp", "sh_bsp_geometry"):
            execute((ROOT / f"lua/gvoxel/{module}.lua").read_bytes(), module)
        execute((ROOT / "tests/tank_geometry_spec.lua").read_bytes(), "tank_geometry_spec")
        execute(b"RunTankGeometryTests()", "run_tank_geometry")
        execute((ROOT / "tests/explosion_optimization_spec.lua").read_bytes(), "explosion_optimization_spec")
        execute(b"RunExplosionOptimizationTests()", "run_explosion_optimization")
        execute((ROOT / "tests/server_scan_spec.lua").read_bytes(), "tank_server_api_adapters")
        execute((ROOT / "lua/gvoxel/sv_scan.lua").read_bytes(), "tank_shared_explosion_queue")
        execute((ROOT / "tests/tank_server_spec.lua").read_bytes(), "tank_server_spec")
        execute((ROOT / "lua/gvoxel/sv_tank.lua").read_bytes(), "sv_tank")
        execute(b"RunTankServerTests()", "run_tank_server")
        execute((ROOT / "tests/glide_shell_spec.lua").read_bytes(), "glide_shell_spec")
        execute(b"PrepareGlideShellTests()", "prepare_glide_shell")
        explosions = (ROOT / "lua/gvoxel/sv_explosions.lua").read_bytes()
        execute(explosions, "sv_explosions")
        compiled_chunk(explosions, "reload_sv_explosions", "_RELOAD_GLIDE_EXPLOSIONS")
        weaponry = vehicle_source("glide", "lua/glide/server/weaponry.lua")
        explosion = weaponry[weaponry.index(b"do\n    local BlastDamage"):weaponry.index(b"\nlocal GetParent")]
        compiled_chunk(explosion, "installed_glide_create_explosion", "_INSTALLED_GLIDE_EXPLOSION")
        projectile = vehicle_source("glide", "lua/entities/glide_projectile.lua")
        explode = projectile[projectile.index(b"function ENT:Explode()"):projectile.index(b"\nlocal FrameTime")]
        compiled_chunk(explode, "installed_glide_projectile_explode", "_INSTALLED_GLIDE_EXPLODE")
        missile = vehicle_source("glide", "lua/entities/glide_missile/init.lua")
        explode = missile[missile.index(b"function ENT:Explode()"):missile.index(b"\nfunction ENT:PhysicsCollide")]
        compiled_chunk(explode, "installed_glide_missile_explode", "_INSTALLED_GLIDE_MISSILE_EXPLODE")
        compiled_chunk(vehicle_source("glide", "lua/glide/vsweps/missile_launcher.lua"),
                       "installed_glide_missile_launcher", "_INSTALLED_GLIDE_MISSILE_LAUNCHER")
        for aircraft in ("lazer", "strikeforce"):
            source = vehicle_source("glide", f"lua/entities/gtav_{aircraft}.lua")
            start = source.index(b"    function ENT:CreateFeatures()")
            end = source.index(b"\n    function ENT:", start + 1)
            compiled_chunk(source[start:end], f"installed_{aircraft}_weapons", "_INSTALLED_" + aircraft.upper())
        execute(b"RunGlideShellTests(_RELOAD_GLIDE_EXPLOSIONS,_INSTALLED_GLIDE_EXPLOSION,_INSTALLED_GLIDE_EXPLODE, "
                b"_INSTALLED_GLIDE_MISSILE_EXPLODE,_INSTALLED_GLIDE_MISSILE_LAUNCHER,{_INSTALLED_LAZER,_INSTALLED_STRIKEFORCE}); "
                b"_RELOAD_GLIDE_EXPLOSIONS=nil; _INSTALLED_GLIDE_EXPLOSION=nil; _INSTALLED_GLIDE_EXPLODE=nil", "run_glide_shell")
        output_log()
        raise SystemExit(0)
    if args.zones:
        execute((ROOT / "lua/gvoxel/sh_zones.lua").read_bytes(), "sh_zones")
        execute((ROOT / "tests/zones_spec.lua").read_bytes(), "zones_spec")
        execute(b"RunZoneLookupTests()", "run_zones")
        execute((ROOT / "lua/gvoxel/sh_bsp_geometry.lua").read_bytes(), "sh_bsp_geometry")
        execute((ROOT / "tests/texture_provenance_spec.lua").read_bytes(), "texture_provenance_spec")
        execute(b"RunTextureProvenanceTests()", "run_texture_provenance")
        execute((ROOT / "tests/server_scan_spec.lua").read_bytes(), "server_scan_spec")
        execute((ROOT / "lua/gvoxel/sv_session.lua").read_bytes(), "sv_session")
        execute((ROOT / "lua/gvoxel/sv_scan.lua").read_bytes(), "sv_scan")
        execute((ROOT / "tests/single_session_spec.lua").read_bytes(), "single_session_spec")
        execute(b"RunSingleSessionTests()", "run_single_session")
        execute((ROOT / "lua/gvoxel/sv_zone_cache.lua").read_bytes(), "sv_zone_cache")
        execute((ROOT / "tests/zone_cache_spec.lua").read_bytes(), "zone_cache_spec")
        execute(b"RunZoneCacheTests(); RunCachedRegionRestoreTests()", "run_zone_cache")
        execute((ROOT / "tests/zone_store_spec.lua").read_bytes(), "zone_store_spec")
        execute(b"InstallZoneStoreFixtures()", "zone_store_fixtures")
        execute((ROOT / "lua/gvoxel/sv_zone_store.lua").read_bytes(), "sv_zone_store")
        execute(b"RunZoneStoreTests()", "run_zone_store")
        execute((ROOT / "tests/blasts_spec.lua").read_bytes(), "blasts_spec")
        execute(b"InstallBlastTestFixtures()", "blast_fixtures")
        execute((ROOT / "lua/gvoxel/sv_blasts.lua").read_bytes(), "sv_blasts")
        execute(b"RunBlastTests()", "run_blasts")
        output_log()
        raise SystemExit(0)
    if args.visibility:
        execute((ROOT / "tests/bsp_spec.lua").read_bytes(), "bsp_spec")
        for module in ("sh_bsp", "sh_bsp_geometry", "cl_visibility"):
            execute((ROOT / f"lua/gvoxel/{module}.lua").read_bytes(), module)
        execute((ROOT / "tests/visibility_spec.lua").read_bytes(), "visibility_spec")
        execute(b"RunVisibilityBridgeTests()", "run_visibility_bridge")
        execute((ROOT / "tests/exterior_occlusion_spec.lua").read_bytes(), "exterior_occlusion_spec")
        execute(b"RunExteriorOcclusionTests()", "run_exterior_occlusion")
        if args.map:
            if args.map.suffix.lower() == ".gma":
                from inspect_vehicle_sources import entries
                title, files = entries(args.map)
                maps = [(name, offset, size) for name, offset, size in files if name.endswith(".bsp")]
                if len(maps) != 1:
                    raise ValueError("Expected one BSP in this map GMA")
                name, offset, size = maps[0]
                with args.map.open("rb") as stream:
                    stream.seek(offset)
                    map_bytes = stream.read(size)
                source_notes.append(f"MAP SOURCE: {title}; {name}; read-only GMA")
            else:
                map_bytes = args.map.read_bytes()
            lua.lua_pushlstring(state, map_bytes, len(map_bytes))
            lua.lua_setfield(state, -10002, b"_VIS_MAP_BYTES")
            execute(b"local data=GVoxel.ReadBSP(BSPTestStream(_VIS_MAP_BYTES)); _VIS_MAP_BYTES=nil; RunNativeVisibilityTests(data)", "native_visibility")
        execute((ROOT / "tests/visibility_server_spec.lua").read_bytes(), "visibility_server_spec")
        execute((ROOT / "lua/gvoxel/sv_visibility.lua").read_bytes(), "sv_visibility")
        execute(b"RunServerVisibilityTests()", "run_server_visibility")
        execute((ROOT / "tests/sky_spec.lua").read_bytes(), "sky_spec")
        execute((ROOT / "lua/gvoxel/cl_sky.lua").read_bytes(), "cl_sky")
        execute(b"RunVoxelSkyTests()", "run_sky")
        output_log()
        raise SystemExit(0)
    if args.lighting:
        execute(b"CONTENTS_SOLID=1; util={}; hook={Add=function() end}; concommand={Add=function() end}; "
                b"IsValid=function(e) return type(e)=='table' and e.valid~=false end; "
                b"GVoxel.SurfaceMaterial=function(b) return b.material end; "
                b"GVoxel.SurfaceFlashMaterial=function(b) return b.flashMaterial end", "lighting_adapters")
        execute((ROOT / "tests/lighting_spec.lua").read_bytes(), "lighting_spec")
        execute((ROOT / "lua/gvoxel/cl_lighting.lua").read_bytes(), "cl_lighting")
        execute(b"RunLightingTests()", "run_lighting")
        execute((ROOT / "lua/gvoxel/cl_cut_lighting.lua").read_bytes(), "cl_cut_lighting")
        execute((ROOT / "tests/cut_lighting_spec.lua").read_bytes(), "cut_lighting_spec")
        execute(b"RunCutLightingTests()", "run_cut_lighting")
        execute((ROOT / "tests/bsp_light_spec.lua").read_bytes(), "bsp_light_spec")
        execute(b"RunBSPLightTests()", "run_bsp_light")
        execute((ROOT / "tests/corner_lighting_spec.lua").read_bytes(), "corner_lighting_spec")
        execute(b"RunCornerLightingTests()", "run_corner_lighting")
        output_log()
        raise SystemExit(0)
    if args.vehicles:
        lua.lua_pushcclosure(state, compile_string_adapter, 0)
        lua.lua_setfield(state, -10002, b"CompileString")
        execute(b"debug.setupvalue=nil; debug.upvaluejoin=nil; debug.upvalueid=nil; "
                b"_VehicleMethodSources={}; file={Read=function(path) return _VehicleMethodSources[path] end}",
                "gmod_restricted_vehicle_api")
        execute((ROOT / "tests/bsp_spec.lua").read_bytes(), "bsp_spec")
        for module in ("sh_bsp", "sh_bsp_geometry", "sh_vehicle_world"):
            execute((ROOT / f"lua/gvoxel/{module}.lua").read_bytes(), module)
        execute((ROOT / "tests/props_spec.lua").read_bytes(), "props_spec")
        execute(b"file={Read=function(path) return _VehicleMethodSources[path] end}", "mounted_vehicle_sources")
        method_source((ROOT / "tests/vehicle_bridge_spec.lua").read_bytes(), "tests/vehicle_bridge_spec.lua")
        for module in ("sh_vehicle_methods", "sh_ballistics", "sh_vehicle_compat", "sv_props", "sv_vehicles"):
            execute((ROOT / f"lua/gvoxel/{module}.lua").read_bytes(), module)
        execute(b"ErrorNoHalt=function(message) _VEHICLE_ADAPTER_ERROR=message end", "vehicle_adapter_diagnostic")
        execute((ROOT / "tests/vehicle_methods_spec.lua").read_bytes(), "vehicle_methods_spec")
        execute(b"RunVehicleMethodCloneTests()", "run_vehicle_method_clone")
        execute(b"RunVehicleBridgeTests()", "run_vehicle_bridge")
        execute((ROOT / "tests/hl2_wheels_spec.lua").read_bytes(), "hl2_wheels_spec")
        execute((ROOT / "lua/gvoxel/sv_hl2_wheels.lua").read_bytes(), "sv_hl2_wheels")
        execute(b"RunHL2WheelTests()", "run_hl2_wheels")
        execute(b"RunGenericProjectileTraceTests()", "run_generic_projectile")
        # Execute the installed frameworks' actual Lua probe functions from
        # their GMA archives. Never extract or edit Workshop contents.
        execute(b"PrepareInstalledVehicleTests()", "installed_vehicle_adapters")
        glide = vehicle_source("glide", "lua/entities/glide_wheel/init.lua")
        glide = glide[glide.index(b"local MAP_SURFACE_OVERRIDES"):]
        method_source(b"local ENT={}; local GetTable=FindMetaTable('Entity').GetTable; "
                      b"local Abs,Clamp=math.abs,math.Clamp; " + glide +
                      b"\n_InstalledGlidePhysics=ENT.DoPhysics", "entities/glide_wheel/init.lua")
        sim = vehicle_source("simfphys", "lua/entities/gmod_sent_vehicle_fphysics_base/simfunc.lua")
        sim = sim[:sim.index(b"function ENT:SimulateAirControls")]
        method_source(b"local ENT={}; " + sim + b"\n_InstalledSimfphysGround=ENT.WheelOnGround", "entities/gmod_sent_vehicle_fphysics_base/simfunc.lua")
        projectile = vehicle_source("glide", "lua/entities/glide_projectile.lua")
        projectile = projectile[projectile.index(b"local FrameTime = FrameTime"):projectile.index(b"\nfunction ENT:PhysicsCollide")]
        method_source(b"local ENT={}; local CurTime=CurTime; " + projectile +
                      b"\n_InstalledGlideProjectileThink=ENT.Think", "entities/glide_projectile.lua")
        missile = vehicle_source("glide", "lua/entities/glide_missile/init.lua")
        missile = missile[missile.index(b"local FrameTime = FrameTime"):missile.index(b"\nlocal ApproachAngle")]
        method_source(b"local ENT={}; local CurTime=CurTime; " + missile +
                      b"\n_InstalledGlideMissileThink=ENT.Think", "entities/glide_missile/init.lua")
        water = vehicle_source("glide", "lua/entities/base_glide/sv_water.lua")
        method_source(b"local ENT={}\n" + water + b"\n_InstalledGlideWater=ENT", "entities/base_glide/sv_water.lua")
        hover = vehicle_source("glide", "lua/entities/base_glide/sv_wheels.lua")
        method_source(b"local ENT={}\n" + hover + b"\n_InstalledGlideWheels=ENT", "entities/base_glide/sv_wheels.lua")
        execute(b"RunInstalledVehicleTests()", "run_installed_vehicle_functions")
        execute(b"RunInstalledGlideHoverWaterTests()", "run_installed_glide_hover_water")
        compiled_chunk((ROOT / "lua/gvoxel/sh_vehicle_compat.lua").read_bytes(),
                       "reload_vehicle_projectile_adapters", "_RELOAD_PROJECTILE_ADAPTERS")
        execute(b"RunInstalledGlideProjectileTests(_RELOAD_PROJECTILE_ADAPTERS); "
                b"_RELOAD_PROJECTILE_ADAPTERS=nil", "run_installed_glide_projectile")
        execute(b"RunInstalledGlideMissileTests()", "run_installed_glide_missile")
        map_bytes = (GAME / "garrysmod/maps/gm_construct.bsp").read_bytes()
        lua.lua_pushlstring(state, map_bytes, len(map_bytes))
        lua.lua_setfield(state, -10002, b"_VEHICLE_MAP_BYTES")
        execute(b"local data=GVoxel.ReadBSP(BSPTestStream(_VEHICLE_MAP_BYTES)); "
                b"_VEHICLE_MAP_BYTES=nil; RunNativeVehicleSeamTests(data)", "native_vehicle_seam")
        execute(b"assert(not debug.setupvalue and not debug.upvaluejoin, 'restricted GMod API was not retained'); "
                b"assert(not _VEHICLE_ADAPTER_ERROR, _VEHICLE_ADAPTER_ERROR)", "no_silent_vehicle_adapter_failure")
        output_log()
        raise SystemExit(0)
    if args.terrain_coverage or args.profile_option_a or args.profile_holes:
        import json
        fixture = json.loads((ROOT / "tests" / "native-20261026" / "foreground_native_region_fixture.json").read_text())
        execute(("_NATIVE_TERRAIN_VALUES={" + ",".join(map(str, fixture["values"])) + "}").encode(), "native_values")
        execute((ROOT / "tests" / "bsp_spec.lua").read_bytes(), "bsp_spec")
        for module in ("sh_bsp", "sh_bsp_geometry", "sh_scan_columns"):
            execute((ROOT / "lua" / "gvoxel" / f"{module}.lua").read_bytes(), module)
        map_bytes = (GAME / "garrysmod" / "maps" / "gm_construct.bsp").read_bytes()
        lua.lua_pushlstring(state, map_bytes, len(map_bytes))
        lua.lua_setfield(state, -10002, b"_NATIVE_BSP_BYTES")
        execute(b"_NATIVE_BSP_DATA=GVoxel.ReadBSP(BSPTestStream(_NATIVE_BSP_BYTES)); _NATIVE_BSP_BYTES=nil", "coverage_bsp")
        if args.profile_holes:
            execute((ROOT / "tests/client_edit_spec.lua").read_bytes(), "hole_render_adapters")
            execute((ROOT / "lua/gvoxel/cl_surface.lua").read_bytes(), "hole_render_surface")
            execute(b"_HOLE_CURRENT_API={}; for k,v in pairs(GVoxel) do _HOLE_CURRENT_API[k]=v end", "save_hole_api")
            if args.baseline:
                import zipfile
                with zipfile.ZipFile(args.baseline) as archive:
                    for module in ("sh_field", "sh_bsp_geometry", "cl_surface"):
                        execute(archive.read(f"lua/gvoxel/{module}.lua"), f"baseline_{module}")
                execute(b"_HOLE_BASELINE_API={}; for k,v in pairs(GVoxel) do _HOLE_BASELINE_API[k]=v end; "
                        b"for k,v in pairs(_HOLE_CURRENT_API) do GVoxel[k]=v end", "save_baseline_api")
        test = "profile_holes" if args.profile_holes else "profile_option_a" if args.profile_option_a else "terrain_coverage_spec"
        execute((ROOT / "tests" / f"{test}.lua").read_bytes(), test)
        if args.terrain_coverage:
            lattice = json.loads((ROOT / "tests/lighting-live-20261027/hill_field.json").read_text())
            execute(("_NATIVE_LATTICE_VALUES={" + ",".join(map(str, lattice["values"])) + "}").encode(), "native_lattice_values")
            execute((ROOT / "tests/lattice_ground_spec.lua").read_bytes(), "lattice_ground_spec")
            execute((ROOT / "tests" / "optimization_a_spec.lua").read_bytes(), "optimization_a_float")
            execute(b"RunOptionAAllocationTests(); RunOptionACacheTests()", "run_optimization_a_float")
        output_log()
        raise SystemExit(0)
    if args.displacements:
        execute((ROOT / "tests" / "bsp_spec.lua").read_bytes(), "bsp_spec")
        for module in ("sh_bsp", "sh_bsp_geometry", "sh_scan_columns"):
            execute((ROOT / "lua" / "gvoxel" / f"{module}.lua").read_bytes(), module)
        execute((ROOT / "tests" / "displacement_spec.lua").read_bytes(), "displacement_spec")
        execute(b"RunDisplacementTests()", "run_displacements")
        execute((ROOT / "tests/open_layers_spec.lua").read_bytes(), "open_layers_spec")
        execute(b"RunOpenLayerTests()", "run_open_layers")
        map_bytes = (GAME / "garrysmod" / "maps" / "gm_construct.bsp").read_bytes()
        lua.lua_pushlstring(state, map_bytes, len(map_bytes))
        lua.lua_setfield(state, -10002, b"_DISPLACEMENT_BSP")
        execute(b"RunNativeDisplacementTests(GVoxel.ReadBSP(BSPTestStream(_DISPLACEMENT_BSP))); _DISPLACEMENT_BSP=nil", "native_displacements")
        output_log()
        raise SystemExit(0)
    if args.profile or args.profile_latency:
        execute(b"bit={band=function(a,b) local n,p=0,1; while a>0 and b>0 do "
                b"if a%2==1 and b%2==1 then n=n+p end; a=math.floor(a/2); b=math.floor(b/2); p=p*2 end return n end}; "
                b"hook={Add=function() end}", "profile_adapters")
        execute((ROOT / "lua" / "gvoxel" / "sh_bsp.lua").read_bytes(), "sh_bsp")
        execute((ROOT / "lua" / "gvoxel" / "sh_bsp_geometry.lua").read_bytes(), "sh_bsp_geometry")
        profile = "profile_latency" if args.profile_latency else "profile_edits"
        execute((ROOT / "tests" / f"{profile}.lua").read_bytes(), profile)
        output_log()
        raise SystemExit(0)
    if args.profile_visibility or args.inspect_joins:
        execute((ROOT / "tests" / "bsp_spec.lua").read_bytes(), "bsp_spec")
        for module in ("sh_bsp", "sh_bsp_geometry", "cl_visibility"):
            execute((ROOT / "lua" / "gvoxel" / f"{module}.lua").read_bytes(), module)
        map_bytes = (GAME / "garrysmod" / "maps" / "gm_construct.bsp").read_bytes()
        lua.lua_pushlstring(state, map_bytes, len(map_bytes))
        lua.lua_setfield(state, -10002, b"_NATIVE_BSP_BYTES")
        execute(b"_NATIVE_BSP_DATA=GVoxel.ReadBSP(BSPTestStream(_NATIVE_BSP_BYTES)); _NATIVE_BSP_BYTES=nil", "native_bsp")
        if args.inspect_joins:
            execute((ROOT / "tests" / "inspect_joins.lua").read_bytes(), "inspect_joins")
        else:
            execute((ROOT / "tests" / "native_background_spec.lua").read_bytes(), "native_background_spec")
            execute(b"RunNativeBackgroundTests(_NATIVE_BSP_DATA)", "native_background")
        output_log()
        raise SystemExit(0)
    execute(b"RunFieldTests()", "run")
    execute(b"RunPhysicsGeometryTests()", "run_physics_geometry")
    execute((ROOT / "tests" / "scan_spec.lua").read_bytes(), "scan_spec")
    execute(b"RunScanTests()", "run_scan")
    execute((ROOT / "lua" / "gvoxel" / "sh_scan_columns.lua").read_bytes(), "sh_scan_columns")
    execute((ROOT / "tests" / "columns_spec.lua").read_bytes(), "columns_spec")
    execute(b"RunColumnTests()", "run_columns")
    execute((ROOT / "tests" / "sculpt_spec.lua").read_bytes(), "sculpt_spec")
    execute(b"RunSculptTests()", "run_sculpt")
    execute((ROOT / "tests" / "mask_spec.lua").read_bytes(), "mask_spec")
    execute(b"RunMaskTests()", "run_mask")
    execute((ROOT / "tests" / "collision_spec.lua").read_bytes(), "collision_spec")
    execute(b"RunCollisionTests()", "run_collision")
    execute((ROOT / "tests" / "features_spec.lua").read_bytes(), "features_spec")
    execute(b"RunFeatureTests()", "run_features")
    execute((ROOT / "tests" / "rotated_spec.lua").read_bytes(), "rotated_spec")
    execute(b"RunRotatedTests()", "run_rotated")
    execute((ROOT / "tests" / "performance_spec.lua").read_bytes(), "performance_spec")
    execute(b"RunPerformanceTests()", "run_performance")
    execute((ROOT / "tests" / "server_scan_spec.lua").read_bytes(), "server_scan_spec")
    execute((ROOT / "lua" / "gvoxel" / "sv_session.lua").read_bytes(), "sv_session")
    execute((ROOT / "lua" / "gvoxel" / "sv_scan.lua").read_bytes(), "sv_scan")
    execute((ROOT / "lua" / "gvoxel" / "sv_explosions.lua").read_bytes(), "sv_explosions")
    execute(b"RunServerScanTests(); RunCustomServerScanTests(); RunSharedSessionTests()", "run_server_scan")
    execute((ROOT / "tests" / "client_mask_spec.lua").read_bytes(), "client_mask_spec")
    execute((ROOT / "lua" / "gvoxel" / "cl_mesh.lua").read_bytes(), "cl_mesh")
    execute((ROOT / "lua" / "gvoxel" / "cl_visibility.lua").read_bytes(), "cl_visibility")
    execute((ROOT / "lua" / "gvoxel" / "cl_mask.lua").read_bytes(), "cl_mask")
    execute(b"RunClientMaskTests()", "run_client_mask")
    execute((ROOT / "tests" / "client_edit_spec.lua").read_bytes(), "client_edit_spec")
    execute((ROOT / "lua" / "gvoxel" / "cl_surface.lua").read_bytes(), "cl_surface")
    execute((ROOT / "lua" / "gvoxel" / "cl_scan.lua").read_bytes(), "cl_scan")
    execute((ROOT / "lua" / "gvoxel" / "cl_tool.lua").read_bytes(), "cl_tool")
    execute(b"RunSurfaceExposureTests()", "run_surface_exposure")
    execute(b"RunSurfaceProjectionTests()", "run_surface_projection")
    execute(b"RunSurfaceResolutionTests()", "run_surface_resolution")
    execute(b"RunClientEditTests()", "run_client_edit")
    execute(b"RunClientCustomBlockTests()", "run_client_custom_block")
    reload_scan = (ROOT / "lua" / "gvoxel" / "cl_scan.lua").read_bytes()
    check(lua.luaL_loadbuffer(state, reload_scan, len(reload_scan), b"reload_cl_scan"))
    lua.lua_setfield(state, -10002, b"_RELOAD_CLIENT_SCAN")
    execute(b"RunClientMeshLifecycleTests(_RELOAD_CLIENT_SCAN); _RELOAD_CLIENT_SCAN=nil", "run_client_mesh_lifecycle")
    execute(b"RunClientBSPPreparationTests()", "run_client_bsp_preparation")
    execute(b"RunClientLightingCancellationTests()", "run_client_lighting_cancellation")
    execute((ROOT / "tests" / "lighting_spec.lua").read_bytes(), "lighting_spec")
    execute((ROOT / "lua" / "gvoxel" / "cl_lighting.lua").read_bytes(), "cl_lighting")
    execute(b"RunLightingTests()", "run_lighting")
    execute((ROOT / "lua/gvoxel/cl_cut_lighting.lua").read_bytes(), "cl_cut_lighting")
    execute((ROOT / "tests/cut_lighting_spec.lua").read_bytes(), "cut_lighting_spec")
    execute(b"RunCutLightingTests()", "run_cut_lighting")
    execute((ROOT / "tests/bsp_light_spec.lua").read_bytes(), "bsp_light_spec")
    execute(b"RunBSPLightTests()", "run_bsp_light")
    execute((ROOT / "tests/corner_lighting_spec.lua").read_bytes(), "corner_lighting_spec")
    execute(b"RunCornerLightingTests()", "run_corner_lighting")
    execute(b"RunExteriorCaptureFailureTests()", "run_exterior_capture_failure")
    execute((ROOT / "tests" / "movement_spec.lua").read_bytes(), "movement_spec")
    execute((ROOT / "lua" / "gvoxel" / "sh_move.lua").read_bytes(), "sh_move")
    execute(b"RunMovementTests()", "run_movement")
    execute((ROOT / "tests" / "props_spec.lua").read_bytes(), "props_spec")
    execute((ROOT / "lua" / "gvoxel" / "sv_props.lua").read_bytes(), "sv_props")
    execute(b"RunPropTests(); RunPropWorldLifetimeTests(); RunPropAtomicEditTests(); RunVehicleLightTests()", "run_props")
    execute((ROOT / "tests" / "server_physics_spec.lua").read_bytes(), "server_physics_spec")
    execute((ROOT / "lua" / "gvoxel" / "sv_session.lua").read_bytes(), "session_physics")
    execute((ROOT / "lua" / "gvoxel" / "sv_scan.lua").read_bytes(), "scan_physics")
    execute(b"RunServerPhysicsTests()", "run_server_physics")
    execute((ROOT / "tests" / "actors_spec.lua").read_bytes(), "actors_spec")
    for module in ("sv_nav_graph", "sv_navigation"):
        execute((ROOT / f"lua/gvoxel/{module}.lua").read_bytes(), module)
    execute((ROOT / "lua" / "gvoxel" / "sv_actors.lua").read_bytes(), "sv_actors")
    execute(b"RunActorTests()", "run_actors")
    execute(b"IN_ATTACK=1; IN_ATTACK2=2; IN_USE=32", "grab_buttons")
    execute((ROOT / "tests" / "grab_spec.lua").read_bytes(), "grab_spec")
    execute((ROOT / "lua" / "gvoxel" / "sh_grab.lua").read_bytes(), "sh_grab")
    execute(b"RunGrabTests()", "run_grab")
    execute((ROOT / "tests" / "bsp_spec.lua").read_bytes(), "bsp_spec")
    execute((ROOT / "lua" / "gvoxel" / "sh_bsp.lua").read_bytes(), "sh_bsp")
    execute((ROOT / "lua" / "gvoxel" / "sh_bsp_geometry.lua").read_bytes(), "sh_bsp_geometry")
    execute(b"RunBSPGeometryTests()", "run_bsp_geometry")
    execute((ROOT / "tests/visibility_spec.lua").read_bytes(), "visibility_spec")
    execute(b"RunVisibilityBridgeTests()", "run_visibility_bridge")
    execute((ROOT / "tests/exterior_occlusion_spec.lua").read_bytes(), "exterior_occlusion_spec")
    execute(b"RunExteriorOcclusionTests()", "run_exterior_occlusion")
    execute((ROOT / "tests/custom_block_spec.lua").read_bytes(), "custom_block_spec")
    execute(b"RunCustomBlockTests()", "run_custom_block_full")
    execute((ROOT / "tests" / "optimization_a_spec.lua").read_bytes(), "optimization_a")
    execute(b"RunOptionAAllocationTests(); RunOptionACacheTests(); RunOriginalPartitionCacheTests()", "run_optimization_a")
    execute((ROOT / "tests" / "layers_spec.lua").read_bytes(), "layers_spec")
    execute(b"RunLayerTests()", "run_layers")
    execute((ROOT / "tests" / "displacement_spec.lua").read_bytes(), "displacement_spec")
    execute(b"RunDisplacementTests()", "run_displacements")
    execute((ROOT / "tests/open_layers_spec.lua").read_bytes(), "open_layers_spec")
    execute(b"RunOpenLayerTests()", "run_open_layers")
    execute(b"RunBSPBrushPerformanceTests()", "run_bsp_brush_performance")
    execute((ROOT / "tests" / "crater_spec.lua").read_bytes(), "crater_spec")
    execute(b"RunCraterTests()", "run_craters")
    execute((ROOT / "tests/explosion_optimization_spec.lua").read_bytes(), "explosion_optimization_spec")
    execute(b"RunExplosionOptimizationTests()", "run_explosion_optimization")
    execute((ROOT / "tests" / "server_scan_spec.lua").read_bytes(), "server_scan_bsp_spec")
    execute(b"_ORIGINAL_BSP_GET=GVoxel.GetBSPGeometry; "
            b"_OLD_MOVE_RELEASE=GVoxel.ReleaseVoxelMovement; _OLD_BODY_CHECK=GVoxel.BrushIntersectsBody; "
            b"GVoxel.ReleaseVoxelMovement=nil; GVoxel.BrushIntersectsBody=nil; local calls=0; "
            b"GVoxel.GetBSPGeometry=function() calls=calls+1; "
            b"if calls<4 then return nil,false end return _BSP_TEST_FLOOR,true end", "pending_bsp")
    execute(b"_PREPARE_BEFORE_TEST=GVoxel.PrepareBSPRegion; _DENSITY_BEFORE_TEST=GVoxel.ScanDensity; "
            b"GVoxel.PrepareBSPRegion=function(r,...) r.bsp=_BSP_TEST_FLOOR; coroutine.yield(); "
            b"local result=_PREPARE_BEFORE_TEST(r,...); r._TEST_PREPARED=true; return result end; "
            b"GVoxel.ScanDensity=function(r,...) assert(r._TEST_PREPARED,'server sampled incomplete geometry'); return _DENSITY_BEFORE_TEST(r,...) end", "deferred_bsp_preparation")
    execute((ROOT / "lua" / "gvoxel" / "sv_session.lua").read_bytes(), "sv_session_bsp")
    execute((ROOT / "lua" / "gvoxel" / "sv_scan.lua").read_bytes(), "sv_scan_bsp")
    execute((ROOT / "lua" / "gvoxel" / "sv_explosions.lua").read_bytes(), "sv_explosions_bsp")
    execute(b"RunServerScanTests(); GVoxel.GetBSPGeometry=_ORIGINAL_BSP_GET; "
            b"GVoxel.PrepareBSPRegion=_PREPARE_BEFORE_TEST; GVoxel.ScanDensity=_DENSITY_BEFORE_TEST; "
            b"print('PASS: server waits for cooperative BSP preparation before sampling terrain'); "
            b"GVoxel.ReleaseVoxelMovement=_OLD_MOVE_RELEASE; GVoxel.BrushIntersectsBody=_OLD_BODY_CHECK; "
            b"print('PASS: server waits for asynchronous BSP readiness, sends exact-mode metadata and replays exact CSG strokes')", "run_exact_server")
    map_bytes = (GAME / "garrysmod" / "maps" / "gm_construct.bsp").read_bytes()
    lua.lua_pushlstring(state, map_bytes, len(map_bytes))
    lua.lua_setfield(state, -10002, b"_NATIVE_BSP_BYTES")
    execute(("local data=GVoxel.ReadBSP(BSPTestStream(_NATIVE_BSP_BYTES)); "
             "assert(#data.faces>100 and #data.nodes>100); "
             "local tested=false; for _,face in ipairs(data.faces) do "
             "local p=(face.low+face.high)/2+face.normal*2; local leaf=GVoxel.BSPLeaf(data,p); "
             "if not leaf.solid and leaf.cluster>=0 then local row=GVoxel.BSPVisibleClusters(data,p); "
             "assert(row and GVoxel.BSPClustersInPVS(row,{leaf.cluster})); tested=true; break end end; "
             "assert(tested,'native BSP PVS not exercised'); "
             "print('PASS: installed gm_construct.bsp decoded: '..#data.faces..' world faces, '..#data.nodes..' nodes'); "
             "RunNativeBSPLightTests(data); RunHDRLightReaderTests(_NATIVE_BSP_BYTES); "
             "_NATIVE_BSP_DATA=data; _NATIVE_BSP_BYTES=nil; "
             "BSPTestRestoreGlobals()").encode(), "read_native_bsp")
    execute((ROOT / "tests" / "native_background_spec.lua").read_bytes(), "native_background_spec")
    execute(b"RunNativeBackgroundTests(_NATIVE_BSP_DATA)", "native_background")
    execute(b"RunNativeDisplacementTests(_NATIVE_BSP_DATA)", "native_displacements")
    execute((ROOT / "tests" / "local_collision_spec.lua").read_bytes(), "local_collision_spec")
    execute(b"RunLocalCollisionTests(_NATIVE_BSP_DATA); _NATIVE_BSP_DATA=nil", "local_collision")
    if args.map:
        map_path = args.map
        map_bytes = map_path.read_bytes()
        lua.lua_pushlstring(state, map_bytes, len(map_bytes))
        lua.lua_setfield(state, -10002, b"_MAP_BYTES")
        execute(b"local data=GVoxel.ReadBSP(BSPTestStream(_MAP_BYTES)); _MAP_BYTES=nil; RunMapLayerTests(data)", "map_layers")
    execute((ROOT / "tests" / "tool_core_spec.lua").read_bytes(), "tool_core_spec")
    execute((ROOT / "lua" / "gvoxel" / "sv_terrain.lua").read_bytes(), "sv_terrain")
    execute(b"RunToolCoreTests()", "tool_core")
    execute((ROOT / "tests" / "loader_spec.lua").read_bytes(), "loader_spec")
    boot = (ROOT / "lua" / "autorun" / "gvoxel.lua").read_bytes()
    check(lua.luaL_loadbuffer(state, boot, len(boot), b"addon_loader"))
    lua.lua_setfield(state, -10002, b"_BOOT_LOADER")
    execute(b"RunLoaderTests(_BOOT_LOADER); _BOOT_LOADER=nil", "run_loader")
    execute((ROOT / "tests/visibility_server_spec.lua").read_bytes(), "visibility_server_spec")
    execute((ROOT / "lua/gvoxel/sv_visibility.lua").read_bytes(), "sv_visibility")
    execute(b"RunServerVisibilityTests()", "run_server_visibility")
    execute((ROOT / "tests/sky_spec.lua").read_bytes(), "sky_spec")
    execute((ROOT / "lua/gvoxel/cl_sky.lua").read_bytes(), "cl_sky")
    execute(b"RunVoxelSkyTests()", "run_sky")
    output_log()
finally:
    lua.lua_close(state)

-- Load the actual lean server entry point, with no demo/network/build hooks.
local V=GVoxel
local names={"CreateConVar","IsValid","hook","concommand","game","ents"}
local old={} for _,name in ipairs(names) do old[name]=_G[name] end
local keys={"Regions","RemoveRegion","PlaceDemoRegion","CanEdit","CanManageScan","Notify","BrushIntersectsBody","Edit","EditScannedTerrain","CancelScan"}
local saved={} for _,key in ipairs(keys) do saved[key]=V[key] end
local commands={}
local hooks={}
local given=0
local edits,cleared,notifications=0,0,0
local result=true
local public=false
local bodies={}
function CreateConVar() return {GetBool=function() return public end} end
function IsValid(ent) return type(ent)=="table" and ent.valid~=false end
hook={Remove=function() end,Add=function(_,name,fn) hooks[name]=fn end}
concommand={Add=function(name,fn) commands[name]=fn end,Remove=function() end}
game={SinglePlayer=function() return false end}
ents={FindInSphere=function() return bodies end}
V.Regions={} V.RemoveRegion=nil V.PlaceDemoRegion=nil
V.EditScannedTerrain=function(_,radius,adding)
    assert(radius==48 and not adding) edits=edits+1 return result
end
V.CancelScan=function() cleared=cleared+1 end
function RunToolCoreTests()
    local ply={admin=false,IsPlayer=function() return true end,SteamID64=function() return "owner" end,
        IsAdmin=function(self) return self.admin end,ChatPrint=function() notifications=notifications+1 end,
        Give=function(_,class) assert(class=="weapon_voxel_crowbar") given=given+1 end,SelectWeapon=function() end}
    assert(not V.CanEdit(nil) and not V.CanEdit(ply))
    assert(not V.CanEdit(ply,{owner="owner"}) and not V.CanEdit(ply,{owner="else"}))
    public=true
    assert(not V.CanEdit(ply,{}) and not V.CanManageScan(ply),"legacy public edit bypasses admin-only tools")
    commands.vm_give(ply)
    assert(given==0,"non-admin obtained the voxel tool")
    assert(hooks["GVoxel.AdminToolPickup"](ply,{GetClass=function() return "weapon_voxel_crowbar" end})==false,
        "non-admin can pick up an administrator's tool")
    public=false
    ply.admin=true assert(V.CanEdit(ply))
    commands.vm_give(ply) commands.vm_clear(ply)
    assert(given==1,"administrator cannot obtain the voxel tool")
    assert(cleared==1 and not commands.vm_demo and not commands.vm_stats,"legacy demo routes survived")
    assert(V.Edit(ply,48,false)) result=false assert(not V.Edit(ply,48,false))
    result=nil assert(not V.Edit(ply,48,false) and notifications==1 and edits==3)
    assert(not V.BrushIntersectsBody(Vector(),48))
    bodies={{IsPlayer=function() return true end,WorldSpaceAABB=function() return Vector(-8,-8,-8),Vector(8,8,8) end}}
    assert(V.BrushIntersectsBody(Vector(),48),"adding matter lost body protection")
    assert(not V.PlaceDemoRegion and not V.RemoveRegion,"legacy demo terrain implementation survived")
    for _,key in ipairs(keys) do V[key]=saved[key] end
    for _,name in ipairs(names) do _G[name]=old[name] end
    print("PASS: lean server tool retains permissions, sculpt dispatch, give/clear and body protection; no demo/network/build hooks")
end

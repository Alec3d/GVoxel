# GVoxel

Addon Lua pour Garry’s Mod : analyse du terrain BSP, reconstruction voxel destructible, textures et collisions.

Une seule zone persistante par map. Les outils sont reserves aux administrateurs. La zone est sauvegardee automatiquement apres son analyse, puis restauree aux parties suivantes. Le cache conserve le releve et les modifications ; les maillages et objets physiques sont prepares au chargement.

## Utilisation

1. Installer le dossier runtime `gvoxel` dans `garrysmod/addons/`, puis redemarrer la partie.
2. Administrateur : commande `vm_give` pour obtenir le pied-de-biche.
3. R maintenu : dimensions de la cage ou boite personnalisee. R court : analyser.
4. Clic gauche : creuser ; clic droit : ajouter.
5. Utilities → GVoxel → Zones persistantes : gestion du cache et de la zone.

Les explosions RPG, SLAM et les degats explosifs reconnus peuvent creuser le terrain. La compatibilite generique depend des evenements emis par les armes. Les integrations vehicules et PNJ conservent les contraintes du moteur Source.

Les sauvegardes runtime sont dans `garrysmod/data/gvoxel/zones/<map>/`. Elles sont locales au serveur et ne sont pas incluses dans ce depot.

## Developpement

Placer ce projet dans `garrysmod/addons/all source file/gvoxel_sources/`. Les sources de travail restent dans ce dossier ; `addons/gvoxel` contient les copies deployees.

```powershell
python -B tests/run_tests.py
python -B tests/run_tests.py --zones
python -B tools/deploy_runtime.py --write
python -B tools/build_workshop.py
```

Les tests utilisent LuaJIT fourni par cette installation de Garry’s Mod. Certains controles optionnels demandent les maps ou addons Workshop correspondants. Le build produit `dist/gvoxel.gma` et `dist/gvoxel-workshop.zip`, sans publier automatiquement.

## Validation et limites

Les tests hors jeu verifient la geometrie, les collisions adaptees, le reseau, les droits et les caches. Ils ne certifient ni le rendu GPU, ni les FPS, ni la conduite ou le comportement d’une vraie partie multijoueur. Un client lent ou hostile peut encore retarder les edits qui attendent ses accuses de reception. Des essais en jeu restent necessaires avant une diffusion large.

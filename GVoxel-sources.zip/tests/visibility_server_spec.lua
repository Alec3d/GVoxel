local V=GVoxel
local saved={hook=hook,ents=ents,IsValid=IsValid,AddOriginToPVS=AddOriginToPVS,GetRegion=V.GetServerMovementRegion,concommand=concommand}
local hooks,entities,origins={},{},{}
hook={Add=function(_,name,fn) hooks[name]=fn end}
concommand={Add=function() end}
ents={FindByClass=function(class)
    local list={} for _,ent in ipairs(entities) do if ent.class==class then list[#list+1]=ent end end return list
end}
IsValid=function(ent) return type(ent)=="table" and ent.valid~=false end
AddOriginToPVS=function(point) origins[#origins+1]=point end
local function entity(class,key,fields)
    local ent={class=class,fields=fields or {},inputs=0}
    ent.fields.m_portalNumber=key
    function ent:GetInternalVariable(name) return self.fields[name] end
    function ent:WorldSpaceAABB() return Vector(9000,9000,9000),Vector(9001,9001,9001) end
    function ent:Input(name,_,_,value)
        if hooks["GVoxel.KeepOpenedVisibility"](self,name,nil,nil,value) then return end
        self.inputs=self.inputs+1
        if name=="Open" then self.fields.m_state=1 elseif name=="Close" then self.fields.m_state=0
        elseif name=="Activate" then self.fields.m_bActive=true elseif name=="Deactivate" then self.fields.m_bActive=false
        elseif name=="SetFadeStartDistance" then self.fields.m_flFadeStartDist=value
        elseif name=="SetFadeEndDistance" then self.fields.m_flFadeDist=value end
    end
    entities[#entities+1]=ent return ent
end
function RunServerVisibilityTests()
    local r=V.NewScanRegion(8801,Vector(),16)
    local near={low=Vector(-5,-5,-5),high=Vector(5,5,5)}
    r.bsp={areaPortals={[1]=near,[2]=near,[3]={low=Vector(5000,0,0),high=Vector(5010,10,10)}},
        sky={camera={origin=Vector(10000,10000,10000)}}}
    r.bspEdits={{center=-r.origin,radius=48,adding=false}}
    local portal=entity("func_areaportal",1,{m_state=0})
    local window=entity("func_areaportalwindow",2,{m_flFadeStartDist=100,m_flFadeDist=200})
    local far=entity("func_areaportal",3,{m_state=0})
    local blocker=entity("func_occluder",nil,{m_bActive=true})
    blocker.WorldSpaceAABB=function() return near.low,near.high end
    V.RefreshVoxelVisibility(r) assert(portal.inputs==0,"unmodified scan opened map portals")
    r.revision=1 V.RefreshVoxelVisibility(r)
    assert(portal.fields.m_state==1 and window.fields.m_flFadeStartDist>10000 and not blocker.fields.m_bActive,
        "local compiled portals/window/occluder remained closed")
    assert(far.inputs==0,"unrelated map portal was modified")
    local calls=portal.inputs V.RefreshVoxelVisibility(r) assert(portal.inputs==calls,"unchanged revision repeats map inputs")
    V.ReleaseVoxelVisibility(r)
    assert(portal.fields.m_state==0 and window.fields.m_flFadeStartDist==100 and window.fields.m_flFadeDist==200
        and blocker.fields.m_bActive,"map settings not restored on release")
    V.RefreshVoxelVisibility(r)
    portal:Input("Open") blocker:Input("Deactivate") window:Input("SetFadeEndDistance",nil,nil,333)
    assert(portal.fields.m_state==1 and window.fields.m_flFadeDist==1000000,"map controller broke the active bridge")
    V.ReleaseVoxelVisibility(r)
    assert(portal.fields.m_state==1 and not blocker.fields.m_bActive and window.fields.m_flFadeDist==333,
        "latest map-controller intent was lost on restore")
    r.visibilityOrigins={Vector(1,0,0),Vector(8,0,0)}
    V.GetServerMovementRegion=function() return r end
    local player={GetShootPos=function() return Vector() end}
    hooks["GVoxel.OpenRoomPVS"](player)
    assert(#origins==3 and origins[3]==r.bsp.sky.camera.origin,"peer misses neighbouring-room or 3D-sky PVS")
    player.GetShootPos=function() return Vector(20000,20000,20000) end
    hooks["GVoxel.OpenRoomPVS"](player) assert(#origins==3,"distant player receives extra zone PVS")
    V.ReleaseAllVoxelVisibility()
    hook=saved.hook ents=saved.ents IsValid=saved.IsValid AddOriginToPVS=saved.AddOriginToPVS V.GetServerMovementRegion=saved.GetRegion concommand=saved.concommand
    print("PASS: only cut-local compiled portals/windows/occluders relax; release restores values and later controller intent; nearby ready peer receives room/sky PVS, distant peer does not")
end

"""Deploy only mountable runtime files; keep tests, reports and backups central."""
from pathlib import Path
from datetime import datetime
from zipfile import ZipFile, ZIP_DEFLATED
import argparse
import shutil

ROOT=Path(__file__).resolve().parents[1]
RUNTIME=ROOT.parent.parent/'gvoxel'
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--write',action='store_true')
parser.add_argument('--baseline',type=Path,help='Refuse to overwrite runtime files changed since this source snapshot')
args=parser.parse_args()
files=[p for p in (ROOT/'lua').rglob('*.lua')]+[ROOT/'addon.json']
changed=[p for p in files if not (RUNTIME/p.relative_to(ROOT)).exists() or p.read_bytes()!=(RUNTIME/p.relative_to(ROOT)).read_bytes()]
if args.baseline:
    with ZipFile(args.baseline) as archive:
        for source in changed:
            relative=source.relative_to(ROOT).as_posix()
            target=RUNTIME/relative
            if target.exists() and (relative not in archive.namelist() or target.read_bytes()!=archive.read(relative)):
                raise SystemExit(f'Runtime changed outside this deployment: {relative}')
if args.write and changed:
    backup=ROOT/'backups'/f'deployment-{datetime.now():%Y%m%d-%H%M%S}.zip'
    backup.parent.mkdir(exist_ok=True)
    with ZipFile(backup,'w',ZIP_DEFLATED) as archive:
        for source in changed:
            target=RUNTIME/source.relative_to(ROOT)
            if target.exists(): archive.write(target,source.relative_to(ROOT))
    for source in changed:
        target=RUNTIME/source.relative_to(ROOT)
        target.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(source,target)
    print(f'Deployed {len(changed)} files; previous runtime saved in {backup}')
elif changed:
    print(f'{len(changed)} runtime files differ; pass --write to deploy')
else:
    print('Runtime matches all source Lua files and addon.json')
if args.write:
    assert all(p.read_bytes()==(RUNTIME/p.relative_to(ROOT)).read_bytes() for p in files)

-- Continuous seam and assembly tests with the production vehicle modules.
-- These adapters do not simulate the actual Source tyre solver.
local V=GVoxel
local f=_VoxelBodyFixture
local world=game.GetWorld()
local zero=Vector()
local classes={}
local testRegion
scripted_ents={GetList=function() return classes end,GetStored=function(name) return classes[name] end}
local function entity(class,pos,extent)
    local e=f.entity(class,pos,extent)
    function e:GetTable() return self end
    function e:IsVehicle() return self.class:sub(1,13)=="prop_vehicle_" end
    function e:GetChildren() return self.children or {} end
    function e:GetParent() return self.parent end
    return e
end
-- Infinite native floor and a 20-unit wall just INSIDE the cage. A car's
-- front can reach that wall while its rear is still on the external BSP.
local data={head=0,planes={{normal=Vector(0,0,1),distance=0},{normal=Vector(1,0,0),distance=-240},{normal=Vector(1,0,0),distance=-260}},
    nodes={{plane=1,front=1,back=-2},{plane=2,front=-1,back=2},{plane=3,front=-2,back=-1}},
    leaves={{solid=false},{solid=true}},faces={}}
data.faces[1]={normal=Vector(0,0,1),tex={flags=0},low=Vector(-2000,-2000,0),high=Vector(2000,2000,0),
    vertices={Vector(-2000,-2000,0),Vector(2000,-2000,0),Vector(2000,2000,0),Vector(-2000,2000,0)}}
for _,x in ipairs({-260,-240}) do data.faces[#data.faces+1]={normal=Vector(x==-260 and -1 or 1,0,0),tex={flags=0},
    low=Vector(x,-2000,0),high=Vector(x,2000,2000),vertices={Vector(x,-2000,0),Vector(x,2000,0),Vector(x,2000,2000),Vector(x,-2000,2000)}} end
local nativeCalls=0
local waterSurface
local function nativeTrace(t)
    nativeCalls=nativeCalls+1
    local out={Hit=false,StartSolid=false,AllSolid=false,Fraction=1,HitPos=t.endpos,HitNormal=Vector(),HitWorld=false,Entity={valid=false}}
    if not t.ignoreworld then
        local mins,maxs=t.mins or zero,t.maxs or zero
        local dz=t.endpos.z-t.start.z
        if waterSurface and t.mask and bit.band(t.mask,48)~=0 then
            local height=t.start.z+mins.z-waterSurface
            if height< -0.001 then out.Hit=true out.StartSolid=true out.Fraction=0 out.HitPos=t.start out.HitWorld=true out.Entity=world
            elseif dz<0 and t.endpos.z+mins.z<waterSurface then
                out.Hit=true out.Fraction=-height/dz out.HitPos=t.start+(t.endpos-t.start)*out.Fraction
                out.HitNormal=Vector(0,0,1) out.HitWorld=true out.Entity=world
            end
        end
        if not t.mask or bit.band(t.mask,1)~=0 then
        local floor=t.start.z+mins.z
        if floor< -0.001 then out.Hit=true out.StartSolid=true out.Fraction=0 out.HitPos=t.start out.HitWorld=true out.Entity=world
        elseif dz<0 and t.endpos.z+mins.z<0 then
            local fraction=-floor/dz
            if fraction<out.Fraction then out.Hit=true out.Fraction=fraction out.HitPos=t.start+(t.endpos-t.start)*fraction out.HitNormal=Vector(0,0,1) out.HitWorld=true out.Entity=world end
        end
        local dx=t.endpos.x-t.start.x
        if t.start.z+maxs.z>0 then
            local lo,hi=-260-maxs.x,-240-mins.x
            if t.start.x>lo and t.start.x<hi then
                out.Hit=true out.StartSolid=true out.Fraction=0 out.HitPos=t.start out.HitWorld=true out.Entity=world
            elseif math.abs(dx)>1e-12 then
                local a,b=(lo-t.start.x)/dx,(hi-t.start.x)/dx if a>b then a,b=b,a end
                if a>=0 and a<out.Fraction and a<=1 then
                    out.Hit=true out.Fraction=a out.HitPos=t.start+(t.endpos-t.start)*a
                    out.HitNormal=Vector(dx>0 and -1 or 1,0,0) out.HitWorld=true out.Entity=world
                end
            end
        end
        end
    end
    if t.output then for key,value in pairs(out) do t.output[key]=value end return t.output end
    return out
end
util.TraceLine=nativeTrace util.TraceHull=nativeTrace
util.GetSurfaceIndex=function() return 1 end
NULL={valid=false}
CONTENTS_SOLID=1 MAT_DIRT=68
local GenericTrace=util.TraceHull
local function genericRoundThink(self,input)
    return GenericTrace(input)
end
function RunGenericProjectileTraceTests()
    classes.voxel_test_bullet_base={t={}}
    classes.unnamed_round={t={Base="voxel_test_bullet_base",Think=genericRoundThink}}
    V.InstallVehicleAdapters()
    local ent=entity("unnamed_round",Vector(-360,0,60))
    assert(V.IsVoxelProjectile(ent),"projectile base was not recognized without a model/class allowlist")
    ent.Think=classes.unnamed_round.t.Think
    local trace={start=ent:GetPos(),endpos=Vector(-150,0,60),mins=Vector(-1,-1,-1),maxs=Vector(1,1,1),filter={ent}}
    assert(nativeTrace(trace).Hit and not ent:Think(trace).Hit,"non-vehicle projectile kept its captured BSP trace")
    trace.start.y=100 trace.endpos.y=100
    assert(ent:Think(trace).Hit,"generic projectile ignored intact voxels")
    assert(util.TraceHull==GenericTrace,"projectile adapter replaced global util")
    V.ReleaseVehicleAdapters()
    assert(classes.unnamed_round.t.Think==genericRoundThink)
    classes.voxel_test_bullet_base=nil classes.unnamed_round=nil
    print("PASS: unnamed third-party projectile inherits a bullet base, adapts its cached TraceHull without a vehicle owner, crosses the hole and respects intact voxels without global trace replacement")
end

function RunVehicleBridgeTests()
    local r=V.NewScanRegion(2110,Vector(),16)
    for i=0,33^3-1 do local p,x,y,z=V.ScanPoint(r,i) r.values[V.Index(x,y,z,r)]=V.BSPSolid(data,p) and -r.step or r.step end
    V.PrepareBSPRegion(r,data)
    local yields=0
    local co=coroutine.create(function() V.PrepareVehicleExterior(r,data,function() yields=yields+1 coroutine.yield() end) end)
    repeat local ok,err=coroutine.resume(co) assert(ok,err) until coroutine.status(co)=="dead"
    assert(yields>0 and r.vehicleExterior.triangles>0,"world seam did not prepare cooperatively")
    local groups=r.vehicleExterior.groups
    local floorOutside=V.TraceVehicleExterior(r,Vector(-360,0,30),Vector(-360,0,-30),zero,zero)
    assert(floorOutside.Hit and math.abs(floorOutside.HitPos.z)<1e-5,"external native floor lost")
    local floorInside=V.TraceVehicleExterior(r,Vector(0,0,30),Vector(0,0,-30),zero,zero)
    assert(not floorInside.Hit,"original exterior support leaked inside the voxel cage")
    local dirty=V.ApplyBrush(r,Vector(-250,0,60),64,false) r.revision=1
    assert(r.vehicleExterior.groups==groups,"a local hole rebuilt the exterior world")
    V.PrepareChangedCollisions(r,dirty)
    local through={start=Vector(-360,0,60),endpos=Vector(-150,0,60),mins=Vector(-6,-6,-6),maxs=Vector(6,6,6)}
    assert(nativeTrace(through).Hit,"regression scene has no original wall")
    local tr=V.TraceVehicleTerrain(r,through,nativeTrace)
    assert(not tr.Hit,"car trace still hits the hidden BSP in its voxel opening")
    through.start.y=100 through.endpos.y=100
    assert(V.TraceVehicleTerrain(r,through,nativeTrace).Hit,"intact voxel wall was removed by the bridge")
    local below={start=Vector(-360,0,30),endpos=Vector(-300,0,-30),mins=Vector(-8,-8,0),maxs=Vector(8,8,16),output={stale=true}}
    local ground=V.TraceVehicleTerrain(r,below,nativeTrace)
    assert(ground==below.output and not ground.stale and ground.Hit and math.abs(ground.HitPos.z)<0.001,
        "straddling suspension hull lost BSP floor or output-table semantics")
    print("PASS: cooperative exterior seam keeps BSP floor outside, excludes BSP inside, preserves intact walls and lets continuous hulls cross a voxel opening")

    through.start.y=0 through.endpos.y=0
    local obstacle=entity("prop_physics",Vector(),Vector(2,2,2))
    local function withObstacle(t)
        local result=nativeTrace(t)
        if t.ignoreworld and (type(t.filter)~="function" or t.filter(obstacle)) and 0.6<result.Fraction then
            result.Hit=true result.Fraction=0.6 result.Entity=obstacle result.HitWorld=false
        end
        return result
    end
    assert(V.TraceVehicleTerrain(r,through,withObstacle).Entity==obstacle,"vehicle traces lost dynamic prop blockers")
    through.filter={obstacle}
    assert(not V.TraceVehicleTerrain(r,through,withObstacle).Hit,"vehicle trace ignored the framework blacklist")
    through.whitelist=true
    assert(V.TraceVehicleTerrain(r,through,withObstacle).Entity==obstacle,"vehicle trace ignored the framework whitelist")
    through.whitelist=nil through.filter={"prop_*"}
    assert(not V.TraceVehicleTerrain(r,through,withObstacle).Hit,"class wildcard filter was lost")
    through.filter=nil obstacle.VMVoxelCollider=true
    assert(not V.TraceVehicleTerrain(r,through,withObstacle).Hit,"hidden collision proxy was traced twice")
    through.ignoreworld=true assert(not V.TraceVehicleTerrain(r,through,nativeTrace).Hit)
    through.ignoreworld=nil
    print("PASS: terrain trace preserves dynamic blockers, blacklist/whitelist/class filters, ignoreworld and excludes hidden proxy meshes")

    f.setEntities({}) V.PreparePropRegion(r,world)
    local function tick() f.advance(0.02) f.hooks["GVoxel.PropPhysics"]() end
    for _=1,5000 do tick() if not r.propPhysics.jobs then break end end
    assert(r.propPhysics.exteriorReady and r.propPhysics.readyRevision==1,"vehicle support admitted before native seam cooking")
    V.GetServerScanRegion=function() return r end
    local function car(kind)
        local e=entity(kind=="HL2" and "prop_vehicle_unlisted_hl2" or "vehicle_model_never_registered",Vector(-365,0,40),Vector(100,35,20))
        e.IsGlideVehicle=kind=="Glide" or nil e.LVS=kind=="LVS" or nil
        if kind=="Simfphys" then e.class="gmod_sent_vehicle_fphysics_base" end
        return e
    end
    for _,kind in ipairs({"HL2","Glide","LVS","Simfphys"}) do
        local e=car(kind)
        local wheel=entity("arbitrary_wheel",Vector(-290,28,14),Vector(12,5,12))
        local master=entity("arbitrary_suspension",Vector(-300,28,30),Vector(2,2,2))
        local joint={Type="Elastic",Ent1=e,Ent2=wheel}
        e.constraints={joint} wheel.constraints={joint,{Type="AdvBallsocket",Ent1=wheel,Ent2=master}}
        master.constraints={wheel.constraints[2]}
        assert(not V.VoxelBodyContained(r,e,24),"test car is fully inside; boundary bug not exercised")
        assert(V.TryEnrollVoxelVehicle(r,e),kind.." assembly did not enter while its rear was on native BSP")
        for _,part in ipairs({e,wheel,master}) do
            assert(part.worldDisabled and part.VMVehicleRoot==e and part.VMPropRegion==r,kind.." left a constrained part on BSP collision")
            assert(f.hooks["GVoxel.PropTerrainPairs"](r.propPhysics.guard,part)==false,"solid cage guard blocks the car")
        end
        local exterior
        for _,collider in pairs(r.propPhysics.colliders) do if IsValid(collider) and collider.VMVehicleExterior then exterior=collider break end end
        assert(exterior and f.hooks["GVoxel.PropTerrainPairs"](exterior,wheel)==nil,"wheel missed outside support")
        assert(e.constraints[1]==joint,"framework's suspension constraint replaced")
        e:SetPos(Vector(-600,0,40)) wheel:SetPos(Vector(-550,28,14)) master:SetPos(Vector(-560,28,30))
        f.hooks["GVoxel.VehicleAssemblies"]()
        assert(not e.worldDisabled and not wheel.worldDisabled and not master.worldDisabled,"assembly failed to restore native world collision outside the cage")
    end
    print("PASS: HL2/Glide/LVS/Simfphys families transfer complete unnamed constrained assemblies before cage entry; chassis/wheels bypass BSP, guards allow crossing, native support restores on exit")

    local anchored=car("LVS") anchored.constraints={{Type="Weld",Ent1=anchored,Ent2=world}}
    assert(not V.TryEnrollVoxelVehicle(r,anchored) and not anchored.worldDisabled,"world-anchored vehicle was detached")
    print("PASS: world-anchored assemblies are refused without removing user constraints")

    local simRoot=car("Simfphys")
    local simWheel=entity("gmod_sent_vehicle_fphysics_wheel",Vector(),Vector(2,2,2))
    function simWheel:GetBaseEnt() return simRoot end
    local simGhost=entity("gmod_sent_vehicle_fphysics_attachment",Vector(),Vector(2,2,2)) simGhost.parent=simWheel
    assert(V.GetVoxelVehicleRoot(simGhost)==simRoot,"client Simfphys ghost could not resolve its vehicle through BaseEnt")
    print("PASS: client Simfphys visual wheel resolves ghost -> physical wheel -> BaseEnt without server-only ownership fields")

    local trailer=car("LVS")
    assert(V.TryEnrollVoxelVehicle(r,trailer))
    local added=entity("prop_physics",Vector(-280,0,30),Vector(3,3,3))
    assert(V.EnrollVoxelNativeBody(r,added,added:GetPos()))
    local link={Type="Weld",Ent1=trailer,Ent2=added}
    trailer.constraints={link} added.constraints={link}
    assert(V.TryEnrollVoxelVehicle(r,trailer,true) and added.VMVehicleRoot==trailer,"newly joined enrolled body was not adopted")
    trailer.constraints={} added.constraints={}
    assert(V.TryEnrollVoxelVehicle(r,trailer,true) and added.VMVehicleRoot==added,"detached body remained owned by the moving car")
    assert(V.VehicleStates[added].detached and added.worldDisabled,"broken-off body lost voxel collision before leaving")
    assert(V.ReleaseVehicleRegion(r))
    assert(not trailer.worldDisabled and not added.worldDisabled,"assembly cleanup left BSP pairs disabled")
    print("PASS: attached props join the vehicle transaction; broken-off parts keep independent terrain support and all world pairs restore on cleanup")

    local failing=car("Glide")
    local badWheel=entity("unlisted_wheel",Vector(-280,0,30),Vector(3,3,3))
    failing.constraints={{Type="Weld",Ent1=failing,Ent2=badWheel}}
    local makePair=constraint.NoCollide
    constraint.NoCollide=function(e,...) if e==badWheel then return false end return makePair(e,...) end
    assert(not V.TryEnrollVoxelVehicle(r,failing) and not failing.worldDisabled and not badWheel.worldDisabled,
        "partial assembly admission left the chassis with BSP disabled")
    constraint.NoCollide=makePair
    print("PASS: failed wheel world-pair creation rolls back admission of the complete vehicle")

    -- Already-cached and global trace variants, like Glide and Simfphys.
    -- Both retain their existing vehicle physics function and its return tuple.
    local ray=util.TraceHull
    local legacy=function(self,input) return ray(input),nil,27 end
    local modern=function(self,input) return util.TraceHull(input) end
    local helperSource=[=[
local TraceHull=...
local mass
local function Probe(input)
    return TraceHull(input),mass
end
return function(self,input)
    mass=self.probeMass
    return Probe(input)
end
]=]
    _VehicleMethodSources["tests/vehicle_bridge_helper_mass.lua"]=helperSource
    local helperFactory=CompileString(helperSource,"@tests/vehicle_bridge_helper_mass.lua",false)
    assert(type(helperFactory)=="function",helperFactory)
    local helperRoot=helperFactory(util.TraceHull)
    local helperCar=car("Glide") helperCar.probeMass=137
    local nativeHelper,nativeMass=helperRoot(helperCar,through)
    assert(nativeHelper.Hit and nativeMass==137,"helper-only fixture has no native wall or shared mass")
    classes.base_glide={t={IsGlideVehicle=true,PhysicsSimulate=legacy,Probe=legacy}}
    classes.helper_glide={t={IsGlideVehicle=true,PhysicsSimulate=helperRoot}}
    classes.custom_glide={t={Base="base_glide"}}
    classes.gmod_sent_vehicle_fphysics_base={t={Think=modern}}
    V.InstallVehicleAdapters() V.InstallVehicleAdapters()
    local installed
    for i=1,64 do
        local name,value=debug.getupvalue(V.InstallVehicleAdapters,i)
        if not name then break end
        if name=="installed" then installed=value break end
    end
    assert(installed,"adapter resource bookkeeping is unavailable")
    local records=#installed
    for _=1,20 do V.InstallVehicleAdapters() end
    assert(#installed==records,"periodic discovery leaks duplicate non-entry method restoration records")
    local e=car("Glide") through.start.y=0 through.endpos.y=0
    local untouched=util.TraceHull
    local hit,hole,number=classes.base_glide.t.PhysicsSimulate(e,through)
    assert(not hit.Hit and hole==nil and number==27 and util.TraceHull==untouched,"captured wheel trace was not scoped, or return values/global util changed")
    for _,mass in ipairs({11,503,29}) do
        helperCar.probeMass=mass
        local helperHit,helperMass=classes.helper_glide.t.PhysicsSimulate(helperCar,through)
        assert(not helperHit.Hit and helperMass==mass,"scratch group lost its helper-only trace override or split the current vehicle mass")
    end
    local foundMass=false
    for i=1,64 do
        local name,value=debug.getupvalue(helperRoot,i)
        if not name then break end
        if name=="mass" then foundMass=true assert(value==137,"adapted helper group modified the original shared mass cell") end
    end
    assert(foundMass,"helper-only fixture has no original shared mass cell")
    local sim=car("Simfphys") assert(not classes.gmod_sent_vehicle_fphysics_base.t.Think(sim,through).Hit,"global-util wheel probe still sees BSP")
    assert(util.TraceHull(through).Hit,"ordinary tool traces were changed globally")
    classes.base_glide.t.Think=function() error("intentional vehicle fault") end
    V.InstallVehicleAdapters()
    assert(not pcall(classes.base_glide.t.Think,e))
    assert(util.TraceHull(through).Hit,"failed vehicle method leaked the trace context")
    local copied=car("Glide") copied.PhysicsSimulate=classes.base_glide.t.PhysicsSimulate
    V.ReleaseVehicleAdapters()
    assert(classes.base_glide.t.PhysicsSimulate==legacy and classes.gmod_sent_vehicle_fphysics_base.t.Think==modern
        and classes.helper_glide.t.PhysicsSimulate==helperRoot,
        "adapter reload did not restore original methods")
    assert(legacy(e,through).Hit,"adapter reload retained a captured trace override")
    helperCar.probeMass=281
    local restoredHit,restoredMass=helperRoot(helperCar,through)
    assert(restoredHit.Hit and restoredMass==281,"helper-only adapter release changed native trace or original helper mass sharing")
    V.InstallVehicleAdapters() V.AdaptVoxelVehicleEntity(copied)
    assert(not copied:PhysicsSimulate(through).Hit,"spawn-time copied method was not unwrapped/re-adapted after reload")
    V.ReleaseVehicleAdapters()
    print("PASS: inherited framework methods adapt cached/global wheel probes without changing util or growing periodic restoration records; nil returns, errors and reload preserve native methods")
    print("PASS: shared-scratch entry adapts a trace captured only by its private helper, resets vehicle mass per call, preserves original cells and restores native methods on release")
    assert(V.ReleasePropRegion(r))
    testRegion=r
end

function RunNativeVehicleSeamTests(data)
    local r=V.NewScanRegion(2111,Vector(-1002.375,-478.375,-143.25),16)
    local started=os.clock()
    local seam=V.PrepareVehicleExterior(r,data)
    local elapsed=(os.clock()-started)*1000
    local groups=0
    for _,group in pairs(seam.groups) do
        groups=groups+1
        assert(#group.vertices%3==0 and #group.triangles*3==#group.vertices)
        for i=1,#group.vertices,3 do
            local a,b,c=group.vertices[i],group.vertices[i+1],group.vertices[i+2]
            assert(V.PhysicsTriangleUsable(a,b,c),"real map seam contains invalid native mesh input")
            local center=(a+b+c)/3
            assert(center.x<=0.0001 or center.y<=0.0001 or center.z<=0.0001 or center.x>=r.side-0.0001
                or center.y>=r.side-0.0001 or center.z>=r.side-0.0001,"real exterior retained an internal face")
        end
    end
    assert(groups>0 and seam.triangles>0)
    print(string.format("PASS: actual gm_construct exterior compiles %d valid triangles in %d spatial tiles (%.2f ms Lua CPU, without native cooking)",seam.triangles,groups,elapsed))
end

function PrepareInstalledVehicleTests()
    math.Clamp=function(x,a,b) return math.min(b,math.max(a,x)) end
    Glide={MAP_SURFACE_OVERRIDES={},TractionRamp=function() return 1 end,GetDevMode=function() return false end}
    Glide.GetClosestFlare=function() return NULL,math.huge end
    math.Approach=function(value,target,step) return value<target and math.min(target,value+step) or math.max(target,value-step) end
    FrameTime=function() return 0.02 end
    MASK_PLAYERSOLID=1
    MASK_SOLID=1 CONTENTS_WATER=32 CONTENTS_SLIME=16 MASK_WATER=16432
    physenv={GetGravity=function() return Vector(0,0,-600) end}
    Glide.EntityPairs=pairs Glide.ClampForce=function() end Glide.IsUnderWater=function() return false end
    math.ease={OutCubic=function(x) return 1-(1-x)^3 end}
    local vm=getmetatable(Vector())
    local names={"x","y","z"}
    vm.__index=function(v,k) return names[k] and rawget(v,names[k]) or rawget(vm,k) end
    vm.__newindex=function(v,k,value) rawset(v,names[k] or k,value) end
    vm.Zero=function(v) v.x,v.y,v.z=0,0,0 end
    vm.Unpack=function(v) return v.x,v.y,v.z end
    vm.SetUnpacked=function(v,x,y,z) v.x,v.y,v.z=x,y,z end
    simfphys={TractionData={}}
    table.Count=function(t) local n=0 for _ in pairs(t) do n=n+1 end return n end
    util.GetSurfacePropName=function() return "default" end
    local angle={}
    angle.__index=angle angle.__mul=function(a) return a end
    function angle:Up() return Vector(0,0,1) end
    function angle:Forward() return Vector(1,0,0) end
    _VehicleTestAngle=setmetatable({},angle)
    local phys={
        WorldToLocal=function(p,point) return point-p:GetPos() end,
        LocalToWorld=function(p,point) return point+p:GetPos() end,
        GetVelocityAtPoint=function() return Vector() end,
        CalculateForceOffset=function(_,force) return force,Vector() end}
    local ent={GetTable=function(e) return e end,LocalToWorldAngles=function(_,a) return a end,
        SetLocalPos=function(e,p) e.localPos=p end}
    local metas={Vector=getmetatable(Vector()),Angle=angle,PhysObj=phys,Entity=ent}
    FindMetaTable=function(name) return metas[name] end
end

function RunInstalledGlideMissileTests()
    local oldTimer=timer local pending={}
    timer={Simple=function(_,fn) pending[#pending+1]=fn end}
    local function flush() for _,fn in ipairs(pending) do fn() end pending={} end
    local function missile(owner,y)
        local p=entity("glide_missile",Vector(-360,y or 0,60),Vector(1,1,1))
        p.Think=_InstalledGlideMissileThink p.owner=owner p.applyThrust=true p.lifeTime=CurTime()+10
        p.flareExplodeRadius=200^2 p.missThreshold=0.9
        function p:GetOwner() return self.owner end
        function p:GetForward() return Vector(1,0,0) end
        function p:GetVelocity() return Vector(10000,0,0) end
        function p:NextThink() end
        function p:WaterLevel() return self.water or 0 end
        function p:GetEffectiveness() return self.effectiveness or 0 end
        function p:SetEffectiveness(value) self.effectiveness=value end
        function p:SetHasTarget(value) self.hasTarget=value end
        function p.phys:EnableGravity(value) self.gravity=value end
        function p:Explode()
            self.exploded=(self.exploded or 0)+1
            self.cut=V.GetGlideMissileVoxelImpact(self)
            self.nativeOrigin=self:GetPos()
        end
        return p
    end
    local ok,err=pcall(function()
        for _,class in ipairs({"gtav_lazer","gtav_strikeforce"}) do
            local owner=entity(class,Vector(-450,0,60),Vector(60,40,30)) owner.IsGlideVehicle=true
            local p=missile(owner)
            f.hooks["GVoxel.GlideProjectileTraces"](p) flush()
            assert(p.Think~=_InstalledGlideMissileThink and V.GetVoxelVehicleRoot(p)==owner)
            local native=util.TraceHull
            assert(p:Think()==true and not p.exploded,"aircraft missile trace stopped in a dug BSP opening")
            assert(not V.GetGlideMissileVoxelImpact(p),"clear missile trace leaked a stale impact")
            local wall=missile(owner,100)
            f.hooks["GVoxel.GlideProjectileTraces"](wall) flush()
            assert(wall:Think()==true and wall.exploded==1 and wall.cut and math.abs(wall.cut.x+260)<0.02,
                "missile did not publish its predicted voxel wall contact during Explode")
            assert(wall.nativeOrigin.x==-360 and wall:GetPos().x==-360 and util.TraceHull==native,
                "predictive crater changed native missile position or global traces")
            assert(not V.GetGlideMissileVoxelImpact(wall),"predicted contact survived its scoped Think call")
            local revision=testRegion.revision testRegion.revision=0
            local first=missile(owner,100)
            f.hooks["GVoxel.GlideProjectileTraces"](first) flush()
            first:Think()
            assert(first.cut and math.abs(first.cut.x+260)<0.02,"first shot after a revision-zero scan lost its predicted contact")
            testRegion.revision=revision
            wall.lifeTime=CurTime()-1 wall:Think()
            assert(wall.exploded==2 and not wall.cut,"expiry reused a previous collision point")
            local wet=missile(owner) wet.water=1
            f.hooks["GVoxel.GlideProjectileTraces"](wet) flush()
            assert(wet:Think()==true and wet.applyThrust==false and wet.phys.gravity and not wet.exploded,
                "missile trace adapter changed native underwater thrust/gravity")
        end
        V.ReleaseVehicleAdapters()
        print("PASS: installed Lazer/Strikeforce missile Think traces work from scan revision zero, cross dug holes, hit intact voxels and expose only the current predicted contact; native position, expiry, water physics and global traces stay intact")
    end)
    V.ReleaseVehicleAdapters() timer=oldTimer
    if not ok then error(err,0) end
end

function RunInstalledGlideHoverWaterTests()
    local water,hover=_InstalledGlideWater,_InstalledGlideWheels
    assert(water and hover,"installed Glide water/hover sources missing")
    local originals={boat=water.SimulateBoat,sinking=water.ApplySlowSinkingForces,hover=hover.SimulateHovercraft}
    water.IsGlideVehicle=true hover.IsGlideVehicle=true
    local function hoverEntry(self,phys,dt,outLin,outAng)
        return self:SimulateHovercraft(1,0,{Vector()},phys,dt,outLin,outAng)
    end
    local function waterEntry(self,phys,dt,outLin,outAng)
        return self:SimulateBoat(phys,dt,outLin,outAng,0,0)
    end
    hover.PhysicsSimulate=hoverEntry water.PhysicsSimulate=waterEntry
    classes.base_glide_hover={t=hover} classes.base_glide_water={t=water}
    V.InstallVehicleAdapters()
    assert(hover.SimulateHovercraft~=originals.hover,"shared scratch hover method was not adapted")
    assert(water.SimulateBoat==originals.boat and water.ApplySlowSinkingForces==originals.sinking,
        "native buoyancy closures were replaced even though their traces only request water")
    local e=entity("unlisted_glide_hover",Vector(150,0,10),Vector(40,20,10)) e.IsGlideVehicle=true
    function e:GetForward() return Vector(1,0,0) end
    function e:GetRight() return Vector(0,1,0) end
    function e:GetUp() return Vector(0,0,1) end
    function e:GetInputFloat() return 0 end
    function e:GetInputBool() return false end
    function e:GetAngles() return {0,0,0} end
    function e:IsPlayerHolding() return false end
    function e:GetWaterState() return 1 end
    local p={mass=1000,GetMass=function(self) return self.mass end,
        GetPos=function() return e:GetPos() end,GetVelocity=function() return Vector() end,
        GetVelocityAtPoint=function() return Vector() end,GetAngleVelocity=function() return Vector() end,
        CalculateForceOffset=function(_,force) return force,Vector() end,
        ApplyForceOffset=function(self,force) self.applied=Vector(force.x,force.y,force.z) end}
    e.HoverParams={hoverDistance=40,hoverForce=100,hoverZDrag=0,uprightForce=0,
        linearDrag={0,0,0},angularDrag={0,0,0},maxSpeed=500,engineForce=0,turnForce=0,pitchForce=0}
    e.SimulateHovercraft=hover.SimulateHovercraft
    for _,mass in ipairs({1000,3000,500}) do
        p.mass=mass
        local nativeLin,nativeAng=Vector(),Vector()
        assert(originals.hover(e,1,0,{Vector()},p,0.02,nativeLin,nativeAng)==1)
        local lin,ang=Vector(),Vector()
        assert(hover.PhysicsSimulate(e,p,0.02,lin,ang)==1)
        assert(lin:DistToSqr(nativeLin)<math.max(0.01,nativeLin:LengthSqr()*1e-12)
            and ang:DistToSqr(nativeAng)<0.01 and lin.z>0,
            string.format("hover force mismatch mass %d: clone (%g,%g,%g) / (%g,%g,%g), native (%g,%g,%g) / (%g,%g,%g)",
                mass,lin.x,lin.y,lin.z,ang.x,ang.y,ang.z,nativeLin.x,nativeLin.y,nativeLin.z,nativeAng.x,nativeAng.y,nativeAng.z))
    end
    e:SetPos(Vector(0,0,10))
    local lin,ang=Vector(),Vector()
    assert(hover.PhysicsSimulate(e,p,0.02,lin,ang)==0 and lin:LengthSqr()<0.001,
        "installed hovercraft retained the removed BSP support")
    print("PASS: installed Glide hovercraft shares mass/force helper cells, matches native forces across vehicle masses, and loses support over a voxel hole")

    waterSurface=8
    lin,ang=Vector(),Vector()
    assert(hover.PhysicsSimulate(e,p,0.02,lin,ang)==1,
        "mixed solid/water hover trace lost the map water surface inside a voxel hole")
    local mixed=V.TraceVehicleTerrain(testRegion,{start=Vector(0,0,20),endpos=Vector(0,0,-20),mask=49},nativeTrace)
    assert(mixed.Hit and math.abs(mixed.HitPos.z-8)<0.001,"native fluids did not win over the carved-away BSP")
    e:SetPos(Vector(0,0,20)) e.SimulateBoat=water.SimulateBoat
    e.buoyancyPoints={{offset=Vector(0,0,-16),isUnderWater=true}}
    e.BoatParams={waterLinearDrag={0,0,0},buoyancyDepth=40,buoyancy=100,waterAngularDrag={0,0,0},
        alignForce=0,turbulanceForce=0,maxSpeed=500,engineForce=0,engineLiftForce=0,turnForce=0,rollForce=0}
    local last
    for _,mass in ipairs({1000,2000}) do
        p.mass=mass lin,ang=Vector(),Vector()
        water.PhysicsSimulate(e,p,0.02,lin,ang)
        assert(lin.z>0,"installed boat's native water buoyancy was lost")
        if last then assert(math.abs(lin.z/last-2)<0.001,"boat/helper shared mass changed") end
        last=lin.z
        water.ApplySlowSinkingForces(e,e,p,0.02,40)
        assert(p.applied and p.applied.z>0,"native sinking force failed")
    end
    waterSurface=nil
    V.ReleaseVehicleAdapters()
    assert(hover.SimulateHovercraft==originals.hover and water.SimulateBoat==originals.boat)
    print("PASS: installed Glide boat/sinking keep native water probes and shared force state; mixed hover probes preserve water surfaces while solid BSP stays removed")
end

function RunInstalledVehicleTests()
    local r=testRegion
    local dirty=V.ApplyBrush(r,Vector(0,0,-20),64,false)
    r.revision=r.revision+1 V.PrepareChangedCollisions(r,dirty)
    classes.glide_wheel={t={DoPhysics=_InstalledGlidePhysics}}
    classes.gmod_sent_vehicle_fphysics_base={t={WheelOnGround=_InstalledSimfphysGround}}
    V.InstallVehicleAdapters()
    local car=entity("unlisted_glide_car",Vector(0,0,20),Vector(40,20,10))
    car.IsGlideVehicle=true car.steerAngle=_VehicleTestAngle
    local wheel=entity("glide_wheel",Vector(),Vector(2,2,2)) wheel.parent=car
    wheel.params={basePos=Vector(),steerMultiplier=1,suspensionLength=20}
    local ray={}
    wheel.state={radius=10,suspensionLengthMult=1,ray=ray,traceData={start=Vector(),endpos=Vector(),
        mins=Vector(-2,-2,0),maxs=Vector(2,2,5),output=ray}}
    local p={GetPos=function() return car:GetPos() end}
    assert(nativeTrace({start=car:GetPos(),endpos=Vector(0,0,-10)}).Hit,"original floor missing from real wheel regression")
    local result=classes.glide_wheel.t.DoPhysics(wheel,car,p,{car,wheel},Vector(),Vector(),0.015,{},{},car:GetPos(),car)
    assert(result==false and ray.Hit==false and wheel.state.isOnGround==false,
        "installed Glide cached TraceHull still supports a wheel over the carved-away BSP")
    print("PASS: installed Glide DoPhysics executes its real captured TraceHull; output table reports no phantom BSP support over a voxel hole")
    local sim=entity("gmod_sent_vehicle_fphysics_base",Vector(0,0,20),Vector(40,20,10))
    local w=entity("gmod_sent_vehicle_fphysics_wheel",Vector(0,0,10),Vector(10,4,10))
    function w:GetDamaged() return false end
    function w:GetSurfaceMaterial() return "default" end
    function w:SetOnGround(v) self.ground=v end
    function w:SetSpeed() end function w:SetSkidSound() end function w:SetSurfaceMaterial() end
    function sim:GetPowerDistribution() return 0 end
    function sim:LogicWheelPos() return {IsFrontWheel=true} end
    sim.Wheels={w} sim.VehicleData={filter={sim,w}}
    for i=1,6 do sim.VehicleData["onGround_"..i]=0 end
    sim.FrontWheelRadius=10 sim.RearWheelRadius=10 sim.Up=Vector(0,0,1) sim.Vel=Vector()
    classes.gmod_sent_vehicle_fphysics_base.t.WheelOnGround(sim)
    assert(w.ground==0 and sim.DriveWheelsOnGround==0,"installed Simfphys retained phantom traction over voxel hole")
    w:SetPos(Vector(150,0,10))
    classes.gmod_sent_vehicle_fphysics_base.t.WheelOnGround(sim)
    assert(w.ground==1 and sim.DriveWheelsOnGround==1,"installed Simfphys lost contact with the intact voxel floor")
    print("PASS: installed Simfphys WheelOnGround loses traction over the opening and retains contact on intact voxel ground")
    V.ReleaseVehicleAdapters() V.ReleaseVehicleAdapters() V.InstallVehicleAdapters()
    w:SetPos(Vector(0,0,10)) classes.gmod_sent_vehicle_fphysics_base.t.WheelOnGround(sim)
    assert(w.ground==0,"adapter uninstall/reinstall stopped updating probes")
    V.ReleaseVehicleAdapters()
    print("PASS: family adapters can be released repeatedly and reinstalled without retaining stale environments or wrappers")
end

function RunInstalledGlideProjectileTests(reloadAdapters)
    local r=testRegion
    assert(type(_InstalledGlideProjectileThink)=="function" and type(reloadAdapters)=="function")
    local oldTimer,vec=timer,getmetatable(Vector())
    local oldAngle=vec.Angle
    local pending={}
    timer={Simple=function(delay,fn) assert(delay==0) pending[#pending+1]=fn end}
    vec.Angle=function() return _VehicleTestAngle end
    local function flush()
        local callbacks=pending pending={}
        for _,fn in ipairs(callbacks) do fn() end
    end
    local owner=entity("unlisted_glide_tank",Vector(-450,0,60),Vector(60,40,30))
    owner.IsGlideVehicle=true owner.VehicleType=5
    local function projectile(y,think)
        local p=entity("glide_projectile",Vector(-360,y or 0,60),Vector(1,1,1))
        p.Think=think or _InstalledGlideProjectileThink
        p.velocity=Vector(10000,0,0) p.gravity=Vector() p.lifeTime=CurTime()+10 p.phys.asleep=true
        function p:GetOwner() return self.owner end
        function p:WaterLevel() return self.water or 0 end
        function p:SetAngles(a) self.angles=a end
        function p:NextThink(t) self.nextThink=t end
        function p:Explode() self.exploded=(self.exploded or 0)+1 self.impact=self:GetPos() end
        function p.phys:EnableGravity(on) self.gravity=on end
        function p.phys:SetVelocityInstantaneous(v) self.instantVelocity=v end
        return p
    end
    local function upvalue(name)
        for index=1,64 do
            local key,value=debug.getupvalue(_InstalledGlideProjectileThink,index)
            if not key then break end
            if key==name then return value end
        end
        error("installed projectile Think has no "..name.." upvalue")
    end
    local ok,err=pcall(function()
        V.ReleaseVehicleAdapters()
        classes.glide_projectile={t={Think=_InstalledGlideProjectileThink}}
        local onCreated=f.hooks["GVoxel.GlideProjectileTraces"]
        assert(type(onCreated)=="function","new shells lack immediate instance adaptation")
        onCreated(entity("prop_physics"))
        assert(#pending==0,"ordinary entities scheduled vehicle projectile work")
        local p=projectile()
        onCreated(p)
        assert(#pending==1 and p.Think==_InstalledGlideProjectileThink,"creation hook ran before owner setup")
        p.owner=owner -- FireProjectile does this after Spawn, before timer.Simple(0).
        local untouched=util.TraceHull
        flush()
        assert(V.GetVoxelVehicleRoot(p)==owner and p.Think~=_InstalledGlideProjectileThink,
            "deferred shell copy did not resolve its firing vehicle and receive a scoped Think")
        assert(p.mt==MOVETYPE_VPHYSICS and p.phys.asleep,"trace adapter changed the projectile's native physics")
        assert(nativeTrace({start=p:GetPos(),endpos=Vector(-160,0,60)}).Hit)
        assert(p:Think()==true and not p.exploded and p:GetPos():DistToSqr(Vector(-160,0,60))<1e-5,
            "installed Glide Think exploded on old BSP inside the existing voxel opening")
        local ray,traceData=upvalue("ray"),upvalue("traceData")
        assert(not ray.Hit and traceData.output==ray and traceData.filter[1]==p and traceData.filter[2]==owner,
            "cached TraceHull/output or shell-owner filter was lost")
        assert(util.TraceHull==untouched and nativeTrace({start=Vector(-360,0,60),endpos=Vector(-160,0,60)}).Hit,
            "shell adapter replaced ordinary native traces globally")
        print("PASS: installed Glide projectile Think is adapted on creation before periodic discovery; its cached output trace crosses an existing BSP hole and preserves owner filters/native physics")

        local intact=projectile(100) intact.owner=owner onCreated(intact) flush()
        assert(intact:Think()==nil and intact.exploded==1 and intact.impact.x>=-260.01 and intact.impact.x<=-239.99,
            "Glide projectile failed to impact the remaining voxel wall")
        assert(ray.Hit and ray.HitWorld and ray.Entity==world and ray.HitTexture=="gvoxel",
            "Glide impact did not come from the shared voxel terrain")
        print("PASS: installed Glide projectile stops/explodes on intact voxel wall using the same cached output table after crossing was permitted in its neighbouring hole")

        local removed=projectile() onCreated(removed) removed.valid=false flush()
        local underwater=projectile() underwater.owner=owner underwater.water=3
        onCreated(underwater) flush()
        assert(underwater:Think()==false and underwater.submerged and underwater.phys.gravity
            and not underwater.phys.asleep and underwater.phys.instantVelocity:DistToSqr(underwater.velocity*0.5)<1e-6
            and not underwater.exploded,"projectile adapter changed Glide's transition to underwater native physics")
        print("PASS: removed projectiles are ignored by deferred setup and installed Glide underwater physics still wakes, enables gravity and receives half-speed velocity")

        local retained=p.Think
        local duringReload=projectile(nil,retained) duringReload.owner=owner
        onCreated(duringReload) -- Its pending callback deliberately survives a Lua refresh.
        reloadAdapters()
        flush()
        assert(duringReload.Think~=retained and duringReload:Think()==true and not duringReload.exploded,
            "deferred shell retained an obsolete entry/context after Lua refresh")
        V.InstallVehicleAdapters() V.InstallVehicleAdapters()
        local nextShell=projectile(nil,classes.glide_projectile.t.Think) nextShell.owner=owner
        f.hooks["GVoxel.GlideProjectileTraces"](nextShell) flush()
        assert(nextShell:Think()==true and not nextShell.exploded,"repeated class/instance adaptation broke the shell trace")
        print("PASS: live Glide shell method copies and deferred creation callbacks unwrap/re-adapt across Lua refresh without stacking stale trace contexts")
        V.ReleaseVehicleAdapters()
    end)
    V.ReleaseVehicleAdapters()
    timer=oldTimer vec.Angle=oldAngle
    if not ok then error(err,0) end
end

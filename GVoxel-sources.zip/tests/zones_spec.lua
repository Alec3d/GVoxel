local V = GVoxel
function RunZoneLookupTests()
    local a=V.NewScanRegion(51,Vector(),16)
    local b=V.NewScanRegion(52,Vector(2000,0,0),16)
    local records={{region=a,completed=true},{region=b,completed=true}}
    assert(V.NearestZone(records,Vector(2000,0,0)).region==b,"nearest zone remains the last global scan")
    assert(V.RayZone(records,Vector(-1000,0,0),Vector(1,0,0),4096).region==a,"aim chooses the farthest zone")
    assert(not V.RayZone(records,Vector(-1000,0,0),Vector(0,1,0),4096),"ray selects a zone behind a different direction")
    assert(not V.ZonesOverlap(a,b) and V.ZonesOverlap(a,a),"overlap guard is not spatial")
    assert(not V.NearestZone(records,Vector(),function() return false end),"unready zone participates in movement")
    print("PASS: multi-zone lookup chooses containing/nearest and first aimed region, rejects overlap and excludes unready peers")
end

-- Exercise source cloning with GMod's missing debug mutators, not the DLL's
-- more permissive standard debug library. CompileString is a runner adapter.
local fixture=[=[
local TraceHull,util=...
local shared={calls=0}
local scalar=3
local other=4
local ENT={}
function ENT:DoPhysics(data)
    -- scalar = 99; TraceHull = nil
    local text="scalar = 99"
    local long=[==[other = 99]==]
    shared.calls=shared.calls+1
    return TraceHull(data),self.tag,shared,text,long
end
function ENT.Think(self,data)
    return util.TraceHull(data),GLOBAL_VEHICLE_VALUE,self.tag
end
local function helper(data)
    return TraceHull(data),shared
end
local anonymous=function(data) return TraceHull(data) end
local function unsafe(data)
    scalar=scalar+1
    return TraceHull(data),scalar
end
local function multi(data)
    scalar,other=other,scalar
    return TraceHull(data),scalar
end
local function indexed(data)
    scalar,shared.calls=other,9
    return TraceHull(data),scalar
end
local function outer() return function(data) return TraceHull(data) end end
return ENT,helper,anonymous,unsafe,multi,shared,indexed,outer()
]=]
local temporaryFixture=[=[
local TraceHull=...
local mass
local linearImp,angularImp
local function AddForce(value)
    return value*mass*GLOBAL_VEHICLE_FACTOR
end
local function AddForceOffset(value)
    linearImp,angularImp=value*mass,value+mass
    return linearImp,angularImp
end
local function Simulate(value)
    mass=value
    return TraceHull("hover"),AddForce(value),AddForceOffset(value)
end
return Simulate
]=]
local conditionalFixture=[=[
local TraceHull=...
local mass
local function Simulate(value)
    if value then mass=value end
    return TraceHull("conditional"),mass
end
return Simulate
]=]
local helperReadFixture=[=[
local TraceHull=...
local mass
local function ReadMass()
    return mass
end
local function Simulate(value)
    mass=ReadMass()+value
    return TraceHull("read"),mass
end
return Simulate
]=]
local persistentHelperFixture=[=[
local TraceHull=...
local mass,counter=0,0
local function AddForce()
    counter=counter+1
    return mass+counter
end
local function Simulate(value)
    mass=value
    return TraceHull("persistent_helper"),AddForce()
end
return Simulate
]=]
local observerFixture=[=[
local TraceHull=...
local mass
local function Observe()
    return mass
end
local function Simulate(value)
    mass=value
    return TraceHull("observer"),mass
end
return Simulate,Observe
]=]
local ambiguousFixture=[=[
local TraceHull=...
local mass
local function Helper(value)
    mass=value
    return mass
end
local mass
local function Simulate(value)
    mass=value
    return TraceHull("ambiguous"),mass,Helper(value)
end
return Simulate
]=]
function RunVehicleMethodCloneTests()
    local V=GVoxel
    local oldFile,oldSetup,oldJoin=file,debug.setupvalue,debug.upvaluejoin
    local oldGlobal=GLOBAL_VEHICLE_VALUE
    debug.setupvalue=nil debug.upvaluejoin=nil
    local ok,err=pcall(function()
        file={Read=function(path,realm)
            assert(realm=="LUA","clone did not use the mounted Lua source")
            if path=="tests/vehicle_method_fixture.lua" then return fixture end
        end}
        GLOBAL_VEHICLE_VALUE="live global"
        local native=function(data) return "native:"..data end
        local replacement=function(data) return "voxel:"..data end
        local nativeUtil={TraceHull=native}
        local proxy={TraceHull=replacement}
        local factory=CompileString(fixture,"@tests/vehicle_method_fixture.lua",false)
        assert(type(factory)=="function",factory)
        local ent,helper,anonymous,unsafe,multi,shared,indexed,ambiguous=factory(native,nativeUtil)
        local replacements={[native]=replacement,[nativeUtil]=proxy}
        local method,reason=V.CloneVehicleTraceMethod(ent.DoPhysics,replacements)
        assert(method,reason)
        local result,tag,state,text,long=method({tag="tank"},"wheel")
        assert(result=="voxel:wheel" and tag=="tank" and state==shared and state.calls==1,"colon method or shared state lost")
        assert(text=="scalar = 99" and long=="other = 99","source literal changed")
        assert(ent.DoPhysics({tag="original"},"wheel")=="native:wheel" and shared.calls==2,"original closure was modified")
        print("PASS: source-cloned cached TraceHull method works without debug mutators and keeps original shared vectors/tables and source literals")

        local dot,why=V.CloneVehicleTraceMethod(ent.Think,replacements) assert(dot,why)
        local a,b,c=dot({tag="jeep"},"ground")
        assert(a=="voxel:ground" and b=="live global" and c=="jeep","dot method environment or captured util was lost")
        GLOBAL_VEHICLE_VALUE="new global"
        local _,updated=dot({tag="jeep"},"ground") assert(updated=="new global","global environment snapshot was frozen")
        local localClone=assert(V.CloneVehicleTraceMethod(helper,replacements))
        local h,s=localClone("helper") assert(h=="voxel:helper" and s==shared,"local helper lost captured identity")
        local anonymousClone=assert(V.CloneVehicleTraceMethod(anonymous,replacements))
        assert(anonymousClone("anonymous")=="voxel:anonymous","anonymous declaration was not rebuilt")
        print("PASS: source cloning preserves dot/local/anonymous declarations, live global environment and cached util substitutes")

        local bad,message=V.CloneVehicleTraceMethod(unsafe,replacements)
        assert(not bad and message:find("reassigned",1,true),"shared scalar writer was silently cloned")
        bad,message=V.CloneVehicleTraceMethod(multi,replacements)
        assert(not bad and message:find("reassigned",1,true),"shared multiple assignment writer was silently cloned")
        bad,message=V.CloneVehicleTraceMethod(indexed,replacements)
        assert(not bad and message:find("reassigned",1,true),"mixed field/multiple assignment writer was silently cloned")
        bad,message=V.CloneVehicleTraceMethod(ambiguous,replacements)
        assert(not bad and message:find("ambiguous",1,true),"same-line inner closure was mistaken for its outer factory")
        print("PASS: source clone refuses persistent shared-variable writes and ambiguous same-line closure boundaries")

        local sources={}
        file.Read=function(path,realm) assert(realm=="LUA") return sources[path] end
        local function method(source,name)
            local path="tests/vehicle_"..name..".lua"
            sources[path]=source
            local build=CompileString(source,"@"..path,false)
            assert(type(build)=="function",build)
            return build(native)
        end
        local original=method(temporaryFixture,"temporary")
        -- Helpers retain their own environment even if another adapter has
        -- installed a per-function proxy before the group is reconstructed.
        for i=1,20 do
            local name,value=debug.getupvalue(original,i)
            if not name then break end
            if name=="AddForce" then setfenv(value,setmetatable({GLOBAL_VEHICLE_FACTOR=2},{__index=_G})) end
        end
        local a,b,c,d=original(3)
        assert(a=="native:hover" and b==18 and c==9 and d==6)
        local temporary,why=V.CloneVehicleTraceMethod(original,replacements) assert(temporary,why)
        a,b,c,d=temporary(7)
        assert(a=="voxel:hover" and b==98 and c==49 and d==14,"cloned scratch mass was split from force helpers")
        for i=1,20 do
            local name,value=debug.getupvalue(original,i)
            if name=="mass" then assert(value==3,"clone modified the original framework scratch cell") end
            if not name then break end
        end
        a,b,c,d=temporary(2)
        assert(a=="voxel:hover" and b==8 and c==4 and d==4,"scratch state was not reset between vehicles")
        a,b,c,d=original(5)
        assert(a=="native:hover" and b==50 and c==25 and d==10,"native method/helpers changed after cloning")
        print("PASS: temporary force helpers share cloned scratch cells, reset across vehicles, preserve helper environments and leave native cells intact")

        bad,message=V.CloneVehicleTraceMethod(method(conditionalFixture,"conditional"),replacements)
        assert(not bad and message:find("reset",1,true),"conditional scratch reset was accepted")
        bad,message=V.CloneVehicleTraceMethod(method(helperReadFixture,"read_before_reset"),replacements)
        assert(not bad and message:find("reset",1,true),"helper read of old scratch before reset was accepted")
        bad,message=V.CloneVehicleTraceMethod(method(persistentHelperFixture,"persistent_helper"),replacements)
        assert(not bad and message:find("reset",1,true),"helper persistent counter was silently copied into temporary group")
        bad,message=V.CloneVehicleTraceMethod(method(observerFixture,"observer"),replacements)
        assert(not bad and message:find("outside",1,true),"persistent observer of original scratch was silently split")
        bad,message=V.CloneVehicleTraceMethod(method(ambiguousFixture,"ambiguous_cells"),replacements)
        assert(not bad and message:find("ambiguous",1,true),"equal nil cells with distinct lexical declarations were merged")
        print("PASS: shared scratch proof rejects conditional resets, helper reads before initialization, external observers and distinct same-name cells")

        file.Read=function() return nil end
        bad,message=V.CloneVehicleTraceMethod(helper,replacements)
        assert(not bad and message:find("unavailable",1,true),"missing mounted source did not fail safely")
        print("PASS: missing Workshop source leaves native methods unchanged")
    end)
    file=oldFile debug.setupvalue=oldSetup debug.upvaluejoin=oldJoin GLOBAL_VEHICLE_VALUE=oldGlobal
    assert(ok,err)
end

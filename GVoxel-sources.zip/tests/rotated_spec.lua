function RunRotatedTests()
    local V=GVoxel
    local r=V.NewScanRegion(910,Vector(),16)
    local yaw,tilt=math.rad(32),math.rad(17)
    local u=Vector(math.cos(yaw)*math.cos(tilt),math.sin(yaw)*math.cos(tilt),-math.sin(tilt))
    local v=Vector(-math.sin(yaw),math.cos(yaw),0)
    local w=u:Cross(v)
    local basis,half={u,v,w},{85,65,45}
    local center=Vector(3.7,-7.1,2.4)
    local function sdf(p)
        local q=p-center
        local a,b,c=math.abs(q:Dot(u))-half[1],math.abs(q:Dot(v))-half[2],math.abs(q:Dot(w))-half[3]
        return math.sqrt(math.max(0,a)^2+math.max(0,b)^2+math.max(0,c)^2)+math.min(math.max(a,b,c),0)
    end
    for i=0,33^3-1 do local p,x,y,z=V.ScanPoint(r,i) r.values[V.Index(x,y,z,r)]=math.floor(sdf(p)*64+0.5)/64 end
    local function measure()
        local sum,count,edges=0,0,{}
        V.ForChunks(function(x,y,z)
            local offset=r.origin+Vector(x,y,z)*(r.step*8)
            local vertices=V.BuildChunk(r,x,y,z)
            for i=1,#vertices,3 do
                local points={vertices[i].pos+offset,vertices[i+1].pos+offset,vertices[i+2].pos+offset}
                for _,p in ipairs(points) do sum=sum+math.abs(sdf(p)) count=count+1 end
                for j=1,3 do
                    local a,b=points[j],points[j%3+1]
                    local ka,kb=string.format("%.4f:%.4f:%.4f",a.x,a.y,a.z),string.format("%.4f:%.4f:%.4f",b.x,b.y,b.z)
                    if ka>kb then ka,kb=kb,ka end
                    local key=ka.."/"..kb edges[key]=(edges[key] or 0)+1
                end
            end
        end,r)
        return sum/count,edges
    end
    local before=measure()
    for axis,n in ipairs(basis) do for _,sign in ipairs({-1,1}) do
        for _,a in ipairs({-1,1}) do for _,b in ipairs({-1,1}) do
            local i,j=axis%3+1,(axis+1)%3+1
            local p=center+n*(half[axis]*sign)+basis[i]*(half[i]*a)+basis[j]*(half[j]*b)
            V.RecordScanPlane(r,{Hit=true,HitWorld=true,HitPos=p,HitNormal=n*sign,HitTexture="concrete"})
        end end
    end end
    assert(#r.featurePlanes==6,"rotated planes did not merge")
    assert(not V.FeatureAxis(Vector(0.002,0,0.999998):GetNormalized()),"gentle ramp collapsed onto an axis")
    local after,edges=measure()
    assert(after<before*0.7,"rotated brush reconstruction did not improve: "..before.." -> "..after)
    for key,count in pairs(edges) do assert(count==2,"rotated sharp mesh opened a seam: "..key.." / "..count) end
    for i=1,20 do
        local start=center+Vector(math.cos(i*0.7),math.sin(i*0.7),math.sin(i*1.3))*200
        local direction=(center-start):GetNormalized()
        local mesh=V.TraceScanRegion(r,start,direction,500)
        local collision=V.TraceVoxelHull(r,start,start+direction*500,Vector(),Vector())
        assert(mesh and collision.Hit and mesh.HitPos:DistToSqr(collision.HitPos)<0.01,"rotated mesh and collision disagree on ray "..i.." : "..(mesh and math.sqrt(mesh.HitPos:DistToSqr(collision.HitPos)) or -1))
    end
    local clone=V.CloneScanField(r)
    V.ApplyBrush(clone,center+u*half[1],48,false) clone.revision=clone.revision+1
    r=clone
    local _,sculpted=measure()
    for key,count in pairs(sculpted) do assert(count==2,"sculpting rotated brush opened a seam: "..key) end
    print(string.format("PASS: rotated + tilted closed brush, shared collision, mean shape error %.3f -> %.3f",before,after))
end

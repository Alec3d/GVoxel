function RunSculptTests()
    local V=GVoxel
    local r=V.NewScanRegion(1,V.SnapScanPosition(Vector(11,22,3.7)),16)
    for i=0,33^3-1 do
        local p,x,y,z=V.ScanPoint(r,i)
        r.values[V.Index(x,y,z,r)]=math.floor((p.z-3.7)*64+0.5)/64
    end
    local start=Vector(11,22,100)
    local direction=Vector(0,0,-1)
    local hit=V.TraceScanRegion(r,start,direction,320)
    assert(hit and hit.VoxelScan and math.abs(hit.HitPos.z-3.7)<0.02,"exact surface trace missed initial mesh")
    assert(not V.TraceScanRegion(r,start,Vector(0,0,1),320),"upward miss hit ground")
    assert(not V.TraceScanRegion(r,start,direction,50),"reach limit ignored")
    local client=V.CloneScanField(r)
    local center=V.SnapScanPosition(V.BrushCenter(hit,48,false))
    V.ApplyBrush(r,center,48,false)
    V.ApplyBrush(client,center,48,false)
    local carved=V.TraceScanRegion(r,start,direction,320)
    assert(carved and carved.HitPos.z<hit.HitPos.z-10,"ray stopped on original floor instead of hole")
    for i,value in ipairs(r.values) do assert(value==client.values[i],"stroke replay differs from server") end
    assert(V.ScanBrushRadius(r,24)>=r.step,"brush smaller than sampling grid can miss all nodes")

    local oldFloor={Hit=true,HitWorld=true,HitPos=hit.HitPos}
    local function trace(_,_,ignoreWorld) return ignoreWorld and {Hit=false} or oldFloor end
    local resolved=V.ResolveSculptTrace(r,start,direction,320,trace)
    assert(resolved.VoxelScan and resolved.HitPos.z==carved.HitPos.z,"hidden BSP blocked sculpt trace")
    local prop={Hit=true,HitWorld=false,HitPos=Vector(11,22,50)}
    local blocked=V.ResolveSculptTrace(r,start,direction,320,function(_,_,ignoreWorld)
        return ignoreWorld and prop or oldFloor
    end)
    assert(blocked==prop,"prop inside cube did not block sculpting")
    local outsideWall={Hit=true,HitWorld=true,HitPos=r.origin-Vector(10,0,0)}
    local fromSide=r.origin-Vector(100,0,0)
    assert(V.ResolveSculptTrace(r,fromSide,Vector(1,0,0),320,function() return outsideWall end)==outsideWall,
        "unmodified BSP outside selection did not block sculpting")
    local addCenter=V.SnapScanPosition(V.BrushCenter(carved,48,true))
    V.ApplyBrush(r,addCenter,48,true)
    local filled=V.TraceScanRegion(r,start,direction,320)
    assert(filled and filled.HitPos.z>carved.HitPos.z+5,"addition did not rebuild the traced surface")
    print("PASS: exact voxel tracing, repeated digging below BSP, addition, replay and external/prop blockers")

    -- Oblique rays must agree with brute-force rendered triangles, not a
    -- trilinear approximation or fixed-step sampler skipping tiny cells.
    local shape=V.NewScanRegion(2,Vector(),16)
    for i=0,33^3-1 do
        local p,x,y,z=V.ScanPoint(shape,i)
        shape.values[V.Index(x,y,z,shape)]=math.sqrt(p:DistToSqr(Vector()))-70
    end
    local vertices=V.BuildChunk(shape,1,1,1)
    assert(#vertices>0)
    for _,eye in ipairs({Vector(0,0,200),Vector(180,15,10),Vector(1,200,1),Vector(160,140,130)}) do
        local ray=(Vector()-eye):GetNormalized()
        local result=V.TraceScanRegion(shape,eye,ray,600)
        assert(result and math.abs(math.sqrt(result.HitPos:LengthSqr())-70)<2,"DDA missed curved/oblique surface")
    end
    print("PASS: DDA intersections across cell corners and oblique curved surfaces")
    local originalTrace,originalFrame,originalClock=V.TraceSculpt,FrameNumber,SysTime
    local calls,frame=0,1
    FrameNumber=function() return frame end
    SysTime=function() return 10 end
    V.TraceSculpt=function(_,_,_,checkpoint)
        calls=calls+1
        if checkpoint then checkpoint() checkpoint() end
        return {Hit=true}
    end
    local viewer={GetShootPos=function() return Vector(11,22,100) end,GetAimVector=function() return Vector(0,0,-1) end}
    for _=1,100 do V.TraceSculptPreview(viewer,r,320) end
    assert(calls==0,"HUD/cursor performed geometry on the render stack")
    V.ResumeSculptPreview(0)
    frame=frame+1
    for _=1,100 do assert(not V.TraceSculptPreview(viewer,r,320).Hit) end
    V.ResumeSculptPreview(0) V.ResumeSculptPreview(100)
    assert(calls==1 and V.TraceSculptPreview(viewer,r,320).Hit,"pending display trace restarted instead of yielding")
    r.revision=r.revision+1 assert(not V.TraceSculptPreview(viewer,r,320).Hit)
    V.ResumeSculptPreview(100)
    assert(calls==2,"preview ignored a committed edit")
    V.TraceSculpt(viewer,r,320)
    assert(calls==3,"authoritative action reused a display-only trace")
    frame=frame+1 V.TraceSculptPreview(viewer,r,320) V.ResumeSculptPreview(100)
    assert(calls==3,"stationary preview repeated an unchanged world query")
    viewer.GetAimVector=function() return Vector(0.1,0,-1):GetNormalized() end
    frame=frame+1 V.TraceSculptPreview(viewer,r,320) V.ResumeSculptPreview(100)
    assert(calls==4,"preview did not update after the aim changed")
    V.TraceSculpt=originalTrace FrameNumber=originalFrame SysTime=originalClock
    print("PASS: HUD/cursor do no geometry; a shared display trace yields across frames, edits discard stale results, authoritative actions stay fresh")
end

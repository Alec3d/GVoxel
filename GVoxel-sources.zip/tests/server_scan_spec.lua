-- Deterministic server-path integration adapters; no actual game is running.
local V=GVoxel
SERVER=true CLIENT=false FCVAR_ARCHIVE=0 CONTENTS_SOLID=1 MASK_SOLID_BRUSHONLY=1 MASK_SOLID=2
local time,sys=100,0
local messages,receivers,hooks,reads={},{},{},{}
local writing
local traceCount=0
function SysTime() sys=sys+0.00001 return sys end
function CurTime() return time end
function IsValid(value) return type(value)=="table" and value.valid~=false end
function CreateConVar(_,default) return {GetFloat=function() return tonumber(default) end} end
function math.Clamp(n,lo,hi) return math.max(lo,math.min(hi,n)) end
hook={Add=function(_,name,fn) hooks[name]=fn end}
concommand={Add=function() end}
net={
    Receive=function(name,fn) receivers[name]=fn end,
    Start=function(name) writing={name=name,data={}} end,
    WriteUInt=function(v,bits)
        assert(v>=0 and v<2^bits,"network integer exceeds its bit width")
        writing.data[#writing.data+1]=v
    end,
    WriteInt=function(v) writing.data[#writing.data+1]=v end,
    WriteVector=function(v) writing.data[#writing.data+1]=v end,
    WriteFloat=function(v) writing.data[#writing.data+1]=v end,
    WriteBool=function(v) writing.data[#writing.data+1]=v end,
    Send=function(ply) writing.ply=ply messages[#messages+1]=writing writing=nil end,
    ReadUInt=function() return table.remove(reads,1) end,
    ReadVector=function() return table.remove(reads,1) end
}
util={
    AddNetworkString=function() end,
    PointContents=function(p) return p.z<3.7 and 1 or 0 end,
    TraceLine=function(data)
        if type(data.filter)=="function" and data.mask==MASK_SOLID_BRUSHONLY then
            traceCount=traceCount+1
            assert(data.filter({IsWorld=function() return true end}),"world filtered out")
            assert(not data.filter({IsWorld=function() return false end}),"entity included in BSP sample")
        elseif data.ignoreworld then return {Hit=false} end
        local a,b=data.start,data.endpos
        local underA,underB=a.z<3.7,b.z<3.7
        if underA then return {StartSolid=true,AllSolid=underB,
            FractionLeftSolid=not underB and (3.7-a.z)/(b.z-a.z) or 0} end
        if underB then
            local f=(3.7-a.z)/(b.z-a.z)
            return {HitWorld=true,Hit=true,HitPos=a+(b-a)*f,HitNormal=Vector(0,0,1),HitTexture="concrete"}
        end
        return {}
    end
}
V.CanEdit=function(ply) return ply.admin end
V.CanManageScan=V.CanEdit
game={GetWorld=function() return {} end}
V.Notify=function() end
local aimed={HitWorld=true,HitPos=Vector(11,22,3.7),HitNormal=Vector(0,0,1)}
V.Trace=function() return aimed end
V.PlaceDemoRegion=function() error("R scan must never spawn demo terrain") end
local weapon={GetClass=function() return "weapon_voxel_crowbar" end,
    SetZoneMetres=function(self,n) self.metres=n end,SetBrushRadius=function(self,n) self.radius=n end}
local ply={admin=true,GetActiveWeapon=function() return weapon end,
    IsPlayer=function() return true end,
    GetShootPos=function() return Vector(11,22,103.7) end,GetAimVector=function() return Vector(0,0,-1) end}

_ScanFixture={ply=ply,net=net,pointContents=util.PointContents,traceLine=util.TraceLine,trace=V.Trace,canEdit=V.CanEdit,
    messages=messages,receive=function(name,values) reads=values receivers[name](0,ply) end,
    advance=function(dt) time=time+dt end}

function RunCachedRegionRestoreTests()
    local oldMap,oldPrepare,oldBSP=game.GetMap,V.PrepareCollisionChunk,V.GetBSPGeometry
    game.GetMap=function() return "test_map" end
    V.PrepareCollisionChunk=function() end V.GetBSPGeometry=nil
    local original=V.NewScanRegion(7500,Vector(),16)
    for i=0,33^3-1 do original.values[i]=original.step end
    local edited=V.CloneScanField(original)
    V.ApplyBrush(edited,Vector(),40,true,442)
    edited.revision=1
    local record=assert(V.MakeZoneCache({completed=true,region=edited,snapshot={values=original.values},
        history={{center=Vector(),radius=40,adding=true,seed=442}}},"Cache","test-signature"))
    local before=traceCount
    local restored=assert(V.RestoreCachedZone(record))
    for _=1,2000 do hooks["GVoxel.BSPScan"]() if restored.completed then break end end
    assert(restored.completed and not restored.failed and restored.rays==0 and traceCount==before,"cache restore relaunched native terrain scan")
    assert(restored.region.revision==1 and #restored.history==1,"committed cache journal did not restore")
    for i,value in pairs(edited.values) do assert(restored.region.values[i]==value,"cache replay changed published terrain") end
    assert(restored.snapshot.values[0]==original.values[0] and restored.snapshot.values~=restored.region.values,"cached initial snapshot was overwritten by edits")
    V.RemoveScanSession(restored)
    game.GetMap=oldMap V.PrepareCollisionChunk=oldPrepare V.GetBSPGeometry=oldBSP
    print("PASS: actual cached server boot restores immutable initial density and exact seeded edits without native scan rays, then prepares collision before publication")
end

function RunServerScanTests()
    local stage,ready,commit=V.StagePropEdit,V.PropEditReady,V.CommitPropEdit
    local oldEnsure,automaticSaves=V.EnsurePersistentZone,0
    V.EnsurePersistentZone=function(s)
        assert(s.completed and s.snapshot,"initial save started before scan/collision preparation")
        automaticSaves=automaticSaves+1
    end
    V.StagePropEdit=nil V.PropEditReady=nil V.CommitPropEdit=nil
    local prepared,queued=0,0
    local propsCanRelease=true
    V.PreparePropRegion=function(r,owner)
        assert(r.revision==0,"initial physics prepared after the first hole") prepared=prepared+1
        r.propPhysics={initialized=true,readyRevision=0}
    end
    V.QueuePropColliders=function(r,dirty)
        assert(next(dirty) and r.revision>0,"physics rebuilt without dirty chunks or new revision") queued=queued+1
    end
    V.ReleasePropRegion=function() return propsCanRelease end
    local function count(name)
        local n=0 for _,m in ipairs(messages) do if m.name==name then n=n+1 end end return n
    end
    ply.admin=false V.PlaceRegion(ply,16)
    assert(#messages==0,"unauthorized scan started")
    ply.admin=true V.PlaceRegion(ply,24)
    assert(#messages==0,"invalid size accepted")
    aimed.HitSky=true V.PlaceRegion(ply,16)
    assert(#messages==0,"sky selection accepted")
    aimed.HitSky=false
    V.PlaceRegion(ply,16)
    assert(count("vm_scan_begin")==1,"valid scan did not start")
    assert(messages[#messages].data[2]:DistToSqr(aimed.HitPos)<0.01,"scan offset from ground")
    V.PlaceRegion(ply,32)
    assert(count("vm_scan_begin")==1,"active scan duplicated")
    local completed=false
    for _=1,1000 do
        time=time+0.02
        local before=count("vm_scan_chunk")
        hooks["GVoxel.BSPScan"]()
        assert(count("vm_scan_chunk")-before<=2,"snapshot rate limit exceeded")
        local last=messages[#messages]
        if last.name=="vm_scan_progress" and last.data[2]==2 then completed=true break end
    end
    assert(completed,"server scan did not complete")
    assert(automaticSaves==1,"fresh scan completion did not request exactly one automatic save")
    print("PASS: actual scan completion automatically requests persistence once after terrain/collision preparation")
    assert(traceCount<15000 and traceCount>3000,"axis-column scan did not reduce native ray count")
    assert(count("vm_scan_chunk")==64,"incomplete snapshot")
    assert(count("vm_scan_features")==1,"architectural feature metadata missing or duplicated")
    local firstChunk,featurePacket=nil,nil
    for i,m in ipairs(messages) do
        if m.name=="vm_scan_chunk" then firstChunk=firstChunk or i end
        if m.name=="vm_scan_features" then featurePacket=i assert(m.data[2]<=128) end
    end
    assert(featurePacket<firstChunk,"feature planes arrived after mesh-building density chunks")
    local received={}
    for _,m in ipairs(messages) do if m.name=="vm_scan_chunk" then
        assert(#m.data==4+11^3,"halo packet sample count differs")
        local key=V.ChunkKey(m.data[2],m.data[3],m.data[4])
        assert(not received[key],"duplicate snapshot chunk") received[key]=true
        for i=5,#m.data do assert(m.data[i]>=-32767 and m.data[i]<=32767,"invalid network density") end
    end end
    print("PASS: server permissions, cached full-volume scan with "..traceCount.." native rays and 64 bounded halo packets")

    local retained=V.GetServerScanRegion(ply)
    assert(retained,"completed scan was discarded and cannot be edited")
    assert(V.CollisionCacheStats(retained).cells==32^3,"initial scan did not prepare the complete collision volume")
    if V.GetBSPGeometry then
        local data,done=V.GetBSPGeometry()
        if data and done then
            assert(retained.bsp==data,"server did not wait for/use exact BSP geometry")
            assert(messages[featurePacket].data[3]==true,"exact geometry mode absent from network metadata")
        end
    end
    assert(not V.GetServerMovementRegion(ply),"BSP bypass enabled before client reconstructed the terrain")
    reads={retained.id+1,0} receivers.vm_scan_ready(0,ply)
    assert(not V.GetServerMovementRegion(ply),"wrong scan acknowledged")
    assert(prepared==1,"initial physics was not prepared exactly once during the scan")
    assert(not V.QueueRPGCrater(ply,retained.base,112,1),"RPG edited a scan before client readiness")
    reads={retained.id,0} receivers.vm_scan_ready(0,ply)
    assert(V.GetServerMovementRegion(ply)==retained,"ready terrain not exposed to movement")
    assert(prepared==1,"client-ready scan did not start native prop colliders")
    V.ReleaseVoxelMovement=function() return false end
    local beforeCancel=#messages
    receivers.vm_scan_cancel(0,ply)
    assert(V.GetServerScanRegion(ply)==retained and #messages==beforeCancel,"unsafe removal discarded the underground player's terrain")
    V.ReleaseVoxelMovement=nil
    local replay=V.CloneScanField(retained)
    local original=V.TraceSculpt(ply,retained,V.Reach)
    assert(original.VoxelScan)
    local originalApply=V.ApplyBrush
    local originalSculptTrace=V.TraceSculpt
    V.ApplyBrush=function() error("ordinary digging rebuilt the field in the weapon callback") end
    V.TraceSculpt=function() error("ordinary digging clipped geometry in the weapon callback") end
    assert(V.EditScannedTerrain(ply,48,false),"server rejected digging scanned mesh")
    V.ApplyBrush=originalApply
    V.TraceSculpt=originalSculptTrace
    assert(count("vm_scan_edit")==0,"ordinary digging applied synchronously")
    for _=1,1000 do
        reads={retained.id,1} receivers.vm_scan_ready(0,ply)
        assert(retained.revision==0,"early ACK committed an unfinished tool stroke")
        hooks["GVoxel.BSPScan"]()
        if count("vm_scan_edit")==1 then break end
    end
    local stroke=messages[#messages].data
    assert(retained.revision==0 and count("vm_scan_edit")==1,"stroke not staged/broadcast")
    assert(not retained.modifiedChunks,"server exposed a hole before its client mesh")
    assert(not V.EditScannedTerrain(ply,48,false),"pending mesh acknowledgement was replaced by another stroke")
    reads={retained.id,2} receivers.vm_scan_ready(0,ply)
    assert(retained.revision==0,"future mesh revision acknowledged")
    reads={retained.id,1} receivers.vm_scan_ready(0,ply)
    assert(retained.revision==1 and queued==1,"displayed hole still waits for unused collision preparation")
    assert(retained.revision==1 and V.GetServerMovementRegion(ply)==retained and prepared==1,
        "prepared/displayed hole not committed, or physics initialized twice")
    V.ApplyBrush(replay,stroke[3],stroke[4],stroke[5])
    for i,value in ipairs(retained.values) do assert(value==replay.values[i],"network stroke replay differs") end
    assert(not V.EditScannedTerrain(ply,48,false),"server stroke rate limit bypassed")
    local carved=V.TraceSculpt(ply,retained,V.Reach)
    assert(carved.VoxelScan and carved.HitPos.z<original.HitPos.z-10,"second trace hit old BSP")
    time=time+1
    assert(V.EditScannedTerrain(ply,48,true),"server rejected addition")
    -- The preceding hole remains traceable while a new revision is built.
    assert(retained.revision==1 and V.GetServerMovementRegion(ply)==retained)
    for _=1,1000 do hooks["GVoxel.BSPScan"]() end
    assert(retained.revision==1,"server committed before the new client display was acknowledged")
    reads={retained.id,2} receivers.vm_scan_ready(0,ply)
    assert(retained.revision==2)
    assert(queued==2,"authoritative strokes did not update prop collision")
    ply.admin=false time=time+1
    assert(not V.EditScannedTerrain(ply,48,false),"unauthorized edit accepted")
    ply.admin=true
    print("PASS: client display acknowledgement commits server collision immediately, without global/dirty-chunk precache")
    print("PASS: retained server terrain, authoritative sculpting, cooldown, permissions and deterministic network replay")

    local function rocket(position,class)
        return {GetClass=function() return class or "rpg_missile" end,GetPos=function() return position end}
    end
    local function blast(projectile,explosive)
        return {IsExplosionDamage=function() return explosive~=false end,
            GetInflictor=function() return projectile end,GetAttacker=function() return ply end}
    end
    local hit=Vector(55,22,3.7)
    local missile=rocket(hit)
    local explosion={GetClass=function() return "env_explosion" end,GetPos=function() return hit end,
        GetOwner=function() return ply end,GetInternalVariable=function(_,key) assert(key=="m_hInflictor") return missile end}
    local oldEdits=count("vm_scan_edit")
    local originalApply=V.ApplyBrush
    V.ApplyBrush=function() error("field rebuilt inside native explosion callback") end
    assert(hooks["GVoxel.RPGExplosion"](explosion,"Explode")==nil,"native explosion input blocked")
    for _=1,5 do assert(hooks["GVoxel.RPGBlastDamage"]({},blast(missile))==nil,"native blast damage blocked") end
    local second=rocket(Vector(100,22,3.7))
    hooks["GVoxel.RPGBlastDamage"]({},blast(second))
    hooks["GVoxel.RPGBlastDamage"]({},blast(rocket(hit,"npc_grenade_frag")))
    hooks["GVoxel.RPGBlastDamage"]({},blast(rocket(hit),false))
    V.ApplyBrush=originalApply
    assert(count("vm_scan_edit")==oldEdits and retained.revision==2,"explosion applied synchronously")
    assert(not V.QueueRPGCrater({},hit,112,8),"explosion changed another player's zone")
    assert(not V.QueueRPGCrater(ply,Vector(10000,0,0),112,8),"distant blast queued terrain work")
    assert(not V.EditScannedTerrain(ply,48,false),"tool overtook queued explosions")
    local seeds={}
    for revision=3,4 do
        for _=1,3000 do
            -- An acknowledgement can arrive while an explosion has only a
            -- suspended overlap preflight and no cloned field yet.
            reads={retained.id,revision} receivers.vm_scan_ready(0,ply)
            assert(retained.revision==revision-1,"future RPG acknowledgement published unfinished terrain")
            hooks["GVoxel.BSPScan"]()
            if count("vm_scan_edit")==oldEdits+revision-2 then break end
        end
        assert(count("vm_scan_edit")==oldEdits+revision-2,"queued RPG explosion was lost or duplicated")
        local packet=messages[#messages].data
        assert(packet[2]==revision and packet[4]==112 and packet[5]==false and packet[6]>0,"RPG brush descriptor lost radius/seed")
        seeds[#seeds+1]=packet[6]
        local expected=V.CloneScanField(retained)
        V.ApplyBrush(expected,packet[3],packet[4],packet[5],packet[6])
        reads={retained.id,revision} receivers.vm_scan_ready(0,ply)
        for _=1,3000 do hooks["GVoxel.BSPScan"]() if retained.revision==revision then break end end
        assert(retained.revision==revision,"RPG collision transaction did not finish")
        assert(V.CollisionCacheStats(retained).cells>32^3/2,"RPG discarded the collision prepared outside its affected chunks")
        for i,value in ipairs(expected.values) do assert(retained.values[i]==value,"RPG network replay differs") end
    end
    assert(seeds[1]~=seeds[2],"successive RPG craters reuse the same procedural seed")
    ply.admin=false
    assert(not V.QueueRPGCrater(ply,hit,112,17),"unauthorized RPG crater accepted")
    ply.admin=true
    for _=1,20 do hooks["GVoxel.BSPScan"]() end
    assert(count("vm_scan_edit")==oldEdits+2,"victims/other weapons created additional craters")
    assert(V.QueueRPGCrater(ply,Vector(55,22,200),112,19))
    for _=1,50 do hooks["GVoxel.BSPScan"]() end
    assert(count("vm_scan_edit")==oldEdits+2 and retained.revision==4,"air blast without terrain activated voxel reconstruction")
    print("PASS: RPG input with no victims and damage fallback; one crater per rocket, queued hits, seeded replay, early-ack guards and permissions")

    local oldGlide=Glide
    Glide={VEHICLE_TYPE={TANK=5,PLANE=4}}
    local extraEdits=0
    for _,case in ipairs({{"npc_satchel",-150,"slam"},{"npc_tripmine",-230,"slam"},
        {"glide_missile",180,"glide_missile"},{"glide_missile",260,"glide_missile"}}) do
        local origin=Vector(case[2],22,3.7)
        local projectile=rocket(origin,case[1])
        function projectile:GetInternalVariable() return ply end
        function projectile:GetOwner() return {IsGlideVehicle=true,VehicleType=4} end
        local revision=retained.revision+1
        V.ApplyBrush=function() error("explosion built geometry in the native callback") end
        if case[3]=="slam" then
            assert(hooks["GVoxel.SLAMExplosion"]({Entity=projectile,OriginalSoundName="BaseGrenade.Explode"})==nil)
            for _=1,4 do hooks["GVoxel.RPGBlastDamage"]({},blast(projectile)) end
        else
            for _=1,4 do hooks["GVoxel.GlideTankBlastDamage"]({},blast(projectile)) end
        end
        V.ApplyBrush=originalApply
        assert(retained.revision==revision-1,"SLAM/aircraft event published synchronous terrain")
        for _=1,4000 do
            hooks["GVoxel.BSPScan"]()
            if count("vm_scan_edit")==oldEdits+3+extraEdits then break end
        end
        assert(count("vm_scan_edit")==oldEdits+3+extraEdits,"SLAM/aircraft blast did not prepare exactly one edit")
        local packet=messages[#messages].data
        assert(packet[2]==revision and packet[4]==112 and packet[5]==false and packet[6]>0)
        local expected=V.CloneScanField(retained)
        V.ApplyBrush(expected,packet[3],packet[4],packet[5],packet[6])
        assert(V.GetScanSession().editWork.source==case[3],"new blast bypassed the common authoritative queue")
        reads={retained.id,revision} receivers.vm_scan_ready(0,ply)
        for _=1,4000 do hooks["GVoxel.BSPScan"]() if retained.revision==revision then break end end
        assert(retained.revision==revision,"new weapon committed without the normal client/physics transaction")
        for i,value in ipairs(expected.values) do assert(retained.values[i]==value,"SLAM/aircraft replay differs from the RPG crater") end
        extraEdits=extraEdits+1
    end
    Glide=oldGlide
    print("PASS: SLAM satchel/tripmine and two aircraft missiles enqueue asynchronously, produce one authoritative seeded RPG crater each, wait for display ACK and replay identical terrain")

    time=time+10
    assert(V.QueueRPGCrater(ply,hit,112,18))
    propsCanRelease=false
    local oldBegins=count("vm_scan_begin")
    V.PlaceRegion(ply,32)
    assert(count("vm_scan_begin")==oldBegins and V.GetServerScanRegion(ply)==retained,"unsafe prop restoration discarded its terrain")
    propsCanRelease=true
    V.PlaceRegion(ply,32)
    hooks["GVoxel.BSPScan"]()
    receivers.vm_scan_cancel(0,ply)
    local canceled=messages[#messages]
    assert(canceled.name=="vm_scan_progress" and canceled.data[2]==3,"cancel status missing")
    local before=traceCount
    hooks["GVoxel.BSPScan"]()
    assert(traceCount==before,"canceled scan kept running")
    assert(count("vm_scan_edit")==oldEdits+2+extraEdits,"replacement/cancellation retained an old RPG crater")
    reads={32,64} receivers.vm_scan_settings(0,ply)
    assert(weapon.metres==32 and weapon.radius==64,"menu settings not applied")
    time=time+1 reads={24,80} receivers.vm_scan_settings(0,ply)
    assert(weapon.metres==32 and weapon.radius==64,"invalid dimensions accepted")
    print("PASS: server cancellation and validated menu settings")
    V.PreparePropRegion=nil V.QueuePropColliders=nil V.ReleasePropRegion=nil
    V.StagePropEdit=stage V.PropEditReady=ready V.CommitPropEdit=commit
    V.EnsurePersistentZone=oldEnsure
end

function RunCustomServerScanTests()
    local low,high=Vector(-100,-80,-50),Vector(300,120,50)
    local samples=0 local originalDensity=V.ScanDensity
    V.ScanDensity=function(r,p,...)
        assert(V.InScanCube(r,p),"custom scanner sampled the inactive enclosing cube")
        samples=samples+1 return originalDensity(r,p,...)
    end
    time=time+10 ply.admin=true
    reads={low,high} receivers.vm_scan_custom(0,ply)
    local scan=assert(V.GetScanSession()) local r=scan.region
    local function pump(predicate)
        for _=1,5000 do hooks["GVoxel.BSPScan"]() if predicate() then return end end
        error("custom server session did not reach the required state")
    end
    pump(function() return scan.completed and scan.peers[ply].done end)
    V.ScanDensity=originalDensity
    assert(r.custom and r.metres==0 and r.cells.x==32 and r.cells.y==16 and r.cells.z==8)
    assert(samples==33*17*9 and samples<33^3,"custom scan did not skip inactive lattice nodes")
    local packet
    for _,m in ipairs(messages) do if m.name=="vm_scan_begin" then packet=m.data end end
    assert(packet[3]==0 and packet[4]:DistToSqr(low)<1e-8 and packet[5]==r.step
        and packet[6]==32 and packet[7]==16 and packet[8]==8,"custom box metadata was lost in the snapshot")
    reads={r.id,0} receivers.vm_scan_ready(0,ply)
    local guest={admin=false}
    reads={} receivers.vm_scan_sync(0,guest)
    pump(function() return scan.peers[guest].done end)
    reads={r.id,0} receivers.vm_scan_ready(0,guest)
    assert(V.QueueRPGCrater(ply,Vector(50,20,0),80,717))
    pump(function() return scan.editWork and scan.editWork.sent end)
    assert(r.revision==0,"custom region ignored the display/collision publication contract")
    reads={r.id,1} receivers.vm_scan_ready(0,ply)
    assert(r.revision==0,"custom edit ignored its second participant")
    reads={r.id,1} receivers.vm_scan_ready(0,guest)
    pump(function() return r.revision==1 end)
    assert(not V.QueueRPGCrater(ply,Vector(50,300,0),48,718),"explosion outside a short box side was accepted")
    hooks["GVoxel.SessionDisconnect"](guest)
    time=time+10
    local allocate=V.NewScanRegion
    V.NewScanRegion=function() error("invalid custom request allocated a full field") end
    V.PlaceRegion(ply,0,Vector(),Vector(8000,100,100))
    V.PlaceRegion(ply,0,Vector(12000,0,0),Vector(12100,100,100))
    ply.admin=false V.PlaceRegion(ply,0,low,high) ply.admin=true
    V.NewScanRegion=allocate
    assert(V.GetScanSession()==scan,"invalid custom request discarded committed terrain")
    assert(V.ShutdownServerScan())
    print("PASS: authoritative custom request validates permissions/size/distance before allocation, samples only 5049 active nodes, replicates box metadata to a joiner and commits a seeded crater after both ACKs")
end

-- The same networking receivers serve every player, including a late join.
function RunSharedSessionTests()
    local function peer()
        return {admin=false,IsPlayer=function() return true end,GetActiveWeapon=function() return weapon end,
            GetShootPos=ply.GetShootPos,GetAimVector=ply.GetAimVector}
    end
    local guest,late=peer(),peer()
    local function receive(name,who,values) reads=values or {} receivers[name](0,who) end
    local function pumpUntil(predicate)
        for _=1,4000 do hooks["GVoxel.BSPScan"]() if predicate() then return end end
        error("shared session did not reach expected state")
    end
    local function packets(name,who)
        local out={}
        for _,m in ipairs(messages) do if m.name==name and m.ply==who then out[#out+1]=m end end
        return out
    end
    receive("vm_scan_sync",guest)
    time=time+10 ply.admin=true aimed.HitSky=false
    V.PlaceRegion(ply,16)
    local scan=assert(V.GetScanSession())
    pumpUntil(function() return scan.peers[ply].done and scan.peers[guest].done end)
    local r=scan.region
    receive("vm_scan_ready",ply,{r.id,0})
    assert(not V.EditScannedTerrain(ply,48,false),"edit ran before every client had the initial terrain")
    receive("vm_scan_ready",guest,{r.id,0})
    assert(V.GetServerMovementRegion(guest)==r,"guest did not receive shared movement terrain")
    assert(not V.EditScannedTerrain(guest,48,false),"guest bypassed edit permission")
    assert(not V.CancelScan(guest) and V.GetScanSession()==scan,"guest deleted shared terrain")
    local original=r.values[V.Index(16,16,15,r)]
    assert(V.EditScannedTerrain(ply,48,false))
    pumpUntil(function() return scan.editWork and scan.editWork.sent end)
    assert(#packets("vm_scan_edit",guest)==1 and #packets("vm_scan_edit",ply)>=1,"edit not sent to both clients")
    receive("vm_scan_ready",ply,{r.id,1})
    assert(r.revision==0,"owner ACK bypassed another participant")
    receive("vm_scan_ready",guest,{r.id,2})
    assert(r.revision==0,"future guest ACK committed terrain")
    receive("vm_scan_ready",guest,{r.id,1})
    assert(r.revision==1 and V.GetServerMovementRegion(guest)==r,"shared collision never committed")
    receive("vm_scan_sync",late)
    assert(not V.GetServerMovementRegion(late),"late join bypassed BSP before reconstruction")
    pumpUntil(function() return scan.peers[late].sent==1 end)
    local snapshot=packets("vm_scan_chunk",late)
    assert(#snapshot==64 and #packets("vm_scan_edit",late)==1,"late join missed snapshot or edit history")
    assert(scan.snapshot.values[V.Index(16,16,15,r)]==original,"initial snapshot was mutated by an edit")
    receive("vm_scan_ready",late,{r.id,1})
    assert(V.GetServerMovementRegion(late)==r,"late join did not enable movement after replay")
    time=time+1
    assert(V.EditScannedTerrain(ply,48,true))
    pumpUntil(function() return scan.editWork and scan.editWork.sent end)
    receive("vm_scan_ready",ply,{r.id,2})
    receive("vm_scan_ready",guest,{r.id,2})
    assert(r.revision==1)
    hooks["GVoxel.SessionDisconnect"](late)
    assert(r.revision==2,"disconnected participant blocked an acknowledged edit")

    -- A large floor-clipped shell uses the very same private prepare,
    -- all-client commit and late-join journal as ordinary tool strokes.
    local floorZ=math.floor((r.base.z-40)*8)/8
    local expected=V.CloneScanField(r)
    local center=V.SnapScanPosition(r.base+Vector(0,0,40))
    assert(V.QueueTerrainExplosion(ply,{center=center,radius=300,seed=0,floorZ=floorZ,source="glide_tank"}))
    V.ApplyBrush(expected,center,300,false,0,nil,floorZ)
    pumpUntil(function() return scan.editWork and scan.editWork.sent end)
    local preview=packets("vm_scan_prepare",guest)
    local publication=packets("vm_scan_edit",guest)
    for _,packet in ipairs({preview[#preview],publication[#publication]}) do
        assert(packet.data[4]==300 and packet.data[7]==true and packet.data[8]==floorZ,
            "large shell radius/floor lost in private/publication packet")
    end
    receive("vm_scan_ready",ply,{r.id,3})
    assert(r.revision==2,"shell committed before all clients displayed it")
    receive("vm_scan_ready",guest,{r.id,3})
    assert(r.revision==3 and scan.history[3].floorZ==floorZ and scan.history[3].radius==300)
    for i,value in ipairs(r.values) do assert(value==expected.values[i],"shell replay differs from committed field") end
    time=time+6
    receive("vm_scan_sync",late)
    pumpUntil(function() return scan.peers[late].sent==3 end)
    local journal=packets("vm_scan_edit",late)
    assert(journal[#journal].data[4]==300 and journal[#journal].data[8]==floorZ,
        "late join did not receive the full shell radius/floor")
    receive("vm_scan_ready",late,{r.id,3})
    assert(V.GetServerMovementRegion(late)==r)
    hooks["GVoxel.SessionDisconnect"](late)
    print("PASS: 300-SU clipped shell shares private prepare/all-client commit, preserves its floor on replay and reaches late joins through ordered history")
    hooks["GVoxel.SessionDisconnect"](ply)
    assert(V.GetScanSession()==scan and V.GetServerMovementRegion(guest)==r,"owner disconnect removed shared terrain")
    ply.admin=true
    V.CancelScan(ply)
    assert(not V.GetScanSession(),"administrator could not clear ownerless shared terrain")
    hooks["GVoxel.SessionDisconnect"](guest)
    print("PASS: shared scan, permissions, all-client ACKs, future ACK rejection and late-join immutable snapshot plus edit replay")
    print("PASS: guest movement, disconnect during an edit, ownerless terrain retention and administrator cleanup")
end

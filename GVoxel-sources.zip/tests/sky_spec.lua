-- Renderer contract; no pixels/GPU/FPS validation.
local V=GVoxel
local saved={}
for _,name in ipairs({"render","hook","concommand","GetConVar","Material","CreateMaterial","GetRenderTargetEx","FrameNumber","ErrorNoHalt","color_white","util"}) do saved[name]=_G[name] end
local hooks={}
hook={Add=function(_,name,fn) hooks[name]=fn end} concommand={Add=function() end}
local frame,views,cubes,backdrops,errors,allocations=1,0,0,0,0,0
local target,clip,writeDepth,range=nil,true,true,0
local tone=Vector(0.3,16,8)
local fail=false
local skyName="test_sky"
local fogStart,fogEnd
color_white=Color(255,255,255)
util={CRC=function(name) return name end}
GetConVar=function() return {GetString=function() return skyName end} end
Material=function(name)
    local texture={IsError=function() return false end,GetName=function() return name.."_ldr" end,
        Width=function() return 512 end,Height=function() return 256 end}
    return {IsError=function() return false end,GetShader=function() return skyName=="painted" and "g_sky" or "Sky" end,
        GetTexture=function() return texture end}
end
CreateMaterial=function(name,shader,params)
    return {name=name,shader=shader,params=params,SetTexture=function(self,key,value) self.params[key]=value end}
end
GetRenderTargetEx=function(_,w,h,_,depth)
    assert(w==1280 and h==720 and depth==MATERIAL_RT_DEPTH_SEPARATE,"sky target shares the scene depth or changes resolution")
    allocations=allocations+1 return {GetName=function() return "sky_test" end}
end
FrameNumber=function() return frame end
ErrorNoHalt=function() errors=errors+1 end
render={
    EnableClipping=function(value) local old=clip clip=value return old end,
    OverrideDepthEnable=function(enabled,write) writeDepth=not enabled or write end,
    DepthRange=function(value) range=value end,SetColorModulation=function() end,SetMaterial=function() end,
    DrawQuadEasy=function(_,_,_,_,_,rotation)
        assert(not clip and not writeDepth and range>0.99,"sky writes near depth or inherits the world clip plane")
        assert(rotation==180 or rotation==0) cubes=cubes+1
    end,
    DrawQuad=function() assert(not clip and not writeDepth and range>0.99) backdrops=backdrops+1 end,
    GetToneMappingScaleLinear=function() return tone end,SetToneMappingScaleLinear=function(value) tone=value end,
    PushRenderTarget=function(value) assert(not target,"nested sky target") target=value end,
    PopRenderTarget=function() target=nil end,Clear=function() assert(target) end,
    FogMode=function() end,FogStart=function(value) fogStart=value end,FogEnd=function(value) fogEnd=value end,
    FogColor=function() end,FogMaxDensity=function() end,
    RenderView=function(view)
        assert(tone.x==1 and tone.y==16 and tone.z==8,"sky is exposed again during its intermediate capture")
        assert(target and not view.drawviewmodel and not view.drawhud and view.viewid==1)
        assert(V.RenderingReplacement,"sky view recursively re-enabled voxel composition")
        views=views+1
        hooks["GVoxel.SkyCameraFog"]()
        hooks["GVoxel.SkyCameraBackdrop"](false,false,false)
        tone=Vector(9,9,9)
        if fail then error("injected sky view failure") end
    end}
function RunVoxelSkyTests()
    local angles={Forward=function() return Vector(1,0,0) end,Right=function() return Vector(0,-1,0) end,Up=function() return Vector(0,0,1) end}
    local view={origin=Vector(160,-32,80),angles=angles,fov=90,aspect=1280/720,w=1280,h=720,zfar=30000}
    local r={bsp={sky={camera={origin=Vector(1000,2000,3000),scale=16,
        fog={enabled=true,start=160,finish=1600,density=0.5,red=20,green=30,blue=40}}}}}
    local projection=V.VoxelSkyView(r,view)
    assert(projection.origin:DistToSqr(Vector(1010,1998,3005))<1e-12,"3D sky has incorrect parallax/scale")
    local texture=V.PrepareVoxelSky(r,view)
    assert(texture and views==1 and cubes==6 and not target and clip and range==0 and writeDepth)
    assert(fogStart==10 and fogEnd==100 and math.abs(tone.x-0.3)<1e-6 and tone.y==16 and tone.z==8,"sky fog/exposure not restored or scaled")
    V.PrepareVoxelSky(r,view) assert(views==1 and allocations==1,"each aperture renders/allocates its own sky")
    V.DrawVoxelSky(view,texture) assert(backdrops==1 and clip and range==0 and writeDepth)
    frame=frame+1 V.PrepareVoxelSky(r,view) assert(views==2 and allocations==1)
    fail=true frame=frame+1
    assert(not V.PrepareVoxelSky(r,view) and not target and clip and range==0 and writeDepth and tone.y==16)
    for _=1,5 do frame=frame+1 V.PrepareVoxelSky(r,view) end
    assert(errors==1 and views==3,"failed sky view repeats errors or leaks its render target")
    skyName="painted" V.DrawVoxelSky(view) assert(cubes>=18,"procedural native sky was not rendered")
    for name,value in pairs(saved) do _G[name]=value end
    print("PASS: 2D/procedural sky uses far-depth/no-write and ignores world clip; 3D camera retains parallax/fog, shares one target/view across exits, restores state and logs failure once")
end

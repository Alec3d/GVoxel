function RunTextureProvenanceTests()
    local V=GVoxel
    local r=V.NewScanRegion(711,Vector(),16)
    r.bsp={textures={{name="tools/toolsnodraw"},{name="ground/grass"},{name="floor/concrete"}}}
    local function floor(z,texture,flags)
        return {normal=Vector(0,0,1),tex={texture=texture,flags=flags or 0},
            vertices={Vector(-40,-40,z),Vector(40,-40,z),Vector(40,40,z),Vector(-40,40,z)}}
    end
    local visible=floor(0,2)
    local hidden=floor(0.01,1,128)
    local below=floor(-8,3)
    r.bspFaceBins={}
    local q=(Vector()-r.origin)/r.step
    r.bspFaceBins[V.Index(math.floor(q.x),math.floor(q.y),math.floor(q.z),r)]={visible,hidden,below}
    assert(V.BSPFaceAt(r,Vector(0,0,0.02),Vector(0,0,1))==visible,"closer NODRAW face stole the ground texture")
    assert(V.BSPFaceAt(r,Vector(0,0,-8),Vector(0,0,1))==below,"stacked lower floor lost its original material")
    print("PASS: material provenance ignores hidden/tool BSP faces while retaining distinct original textures on stacked floors")
end

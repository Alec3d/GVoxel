-- Real terrain geometry, lightweight entity/queue adapters. No game control.
local V=GVoxel
local queued,messages
IsValid=function(e) return type(e)=="table" and e.valid~=false end
concommand={Add=function() end}
V.Notify=function(_,message) messages[#messages+1]=message end
V.QueueTerrainExplosion=function(ply,work)
    work.author=ply work.adding=false work.center=V.SnapScanPosition(work.center) queued=work return true
end
local function tank(scale,yaw)
    local e={IsGlideVehicle=true,VehicleType=5,wheels={}}
    local c,s=math.cos(yaw or 0),math.sin(yaw or 0)
    function e:GetModelBounds() return Vector(-143.701,-64.670,-34.225),Vector(225.598,65.033,76.395) end
    function e:GetModelScale() return scale or 1 end
    function e:LocalToWorld(p) return Vector(p.x*c-p.y*s,p.x*s+p.y*c,p.z+34.225*(scale or 1)) end
    function e:WorldToLocal(p) return Vector(p.x*c+p.y*s,-p.x*s+p.y*c,p.z-34.225*(scale or 1)) end
    function e:GetForward() return Vector(c,s,0) end
    return e
end
local function scene(thickness,metres,center)
    local data={head=0,planes={{normal=Vector(0,0,1),distance=0},
        {normal=Vector(1,0,0),distance=0},{normal=Vector(1,0,0),distance=thickness}},
        nodes={{plane=1,front=1,back=-2},{plane=2,front=2,back=-1},{plane=3,front=-1,back=-2}},
        leaves={{solid=false},{solid=true}},faces={}}
    data.faces[1]={normal=Vector(0,0,1),tex={flags=0},low=Vector(-2000,-2000,0),high=Vector(2000,2000,0),
        vertices={Vector(-2000,-2000,0),Vector(2000,-2000,0),Vector(2000,2000,0),Vector(-2000,2000,0)}}
    for _,x in ipairs({0,thickness}) do
        data.faces[#data.faces+1]={normal=Vector(x==0 and -1 or 1,0,0),tex={flags=0},
            low=Vector(x,-2000,0),high=Vector(x,2000,2000),
            vertices={Vector(x,-2000,0),Vector(x,2000,0),Vector(x,2000,2000),Vector(x,-2000,2000)}}
    end
    local r=V.NewScanRegion(2350,center or Vector(20,0,60),metres or 16)
    for i=0,33^3-1 do local p,x,y,z=V.ScanPoint(r,i)
        r.values[V.Index(x,y,z,r)]=V.BSPSolid(data,p) and -r.step or r.step
    end
    V.PrepareBSPRegion(r,data)
    return r
end

local region
V.GetServerScanRegion=function() return region end
V.GetScanSession=function() return region and {region=region} end
function RunTankServerTests()
    messages={}
    local model=tank()
    local shape=V.MeasureTankOpening(model)
    assert(math.abs(shape.width-129.703)<0.002 and math.abs(shape.height-110.620)<0.002)
    assert(math.abs(shape.width-V.MeasureTankOpening(tank(1,math.pi/3)).width)<0.001)
    local scaled=V.MeasureTankOpening(tank(2))
    assert(math.abs(scaled.width/shape.width-2)<0.001)
    model.wheels[7]={GetPos=function() return Vector(0,80,8) end,GetRadius=function() return 12 end}
    assert(V.MeasureTankOpening(model).width>shape.width)
    local radius=V.TankCraterRadius(shape)
    assert(radius>=112 and radius*0.6*2>=shape.width*1.05,
        "tank blast lost its requested width plus 5 percent")
    local oldRadius=V.GetRPGCraterRadius
    V.GetRPGCraterRadius=function() return 160 end
    assert(V.TankCraterRadius(shape)==160 and V.TankCraterRadius(nil)==160)
    V.GetRPGCraterRadius=oldRadius
    print("PASS: tank dimensions/scale/wheels select RPG radius with a +5% target width; configured RPG radius and missing-model fallback are retained")

    region=scene(40)
    local originalTrace=V.TraceVoxelHull
    V.TraceVoxelHull=function() error("tank event performed a wall-presence or chassis sweep") end
    local impact=Vector(-8.01,0,70.03)
    assert(V.QueueGlideTankCrater({},tank(),impact,Vector(0,0,-1)))
    V.TraceVoxelHull=originalTrace
    local blast=queued
    assert(not blast.prepare and blast.floorZ==nil and blast.seed>0 and blast.source=="glide_tank")
    assert(blast.center:DistToSqr(V.SnapScanPosition(impact))<1e-6,
        "tank crater was moved away from the actual explosion point")
    assert(region.tankStats.mode=="rpg" and region.tankStats.radius==blast.radius)
    assert(V.QueueRPGCrater({},impact,blast.radius,blast.seed))
    local stock=queued
    assert(stock.radius==blast.radius and stock.seed==blast.seed and stock.floorZ==nil and not stock.prepare)
    assert(stock.center:DistToSqr(blast.center)<1e-6)
    local rpg=V.CloneScanField(region)
    V.ApplyBrush(rpg,stock.center,stock.radius,false,stock.seed)
    local dirty,changed=V.ApplyBrush(region,blast.center,blast.radius,false,blast.seed)
    region.revision=1 rpg.revision=1
    assert(changed and next(dirty) and #region.bspEdits==1)
    for i,value in ipairs(region.values) do assert(value==rpg.values[i],"tank blast is not the stock RPG crater") end
    assert(not V.TraceVoxelHull(region,Vector(-50,0,70),Vector(100,0,70),Vector(),Vector()).Hit,
        "RPG-sized blast in front of the voxel surface did not make an impact hole")
    print("PASS: tank uses the real RPG crater factory at the explosion point, with identical seeded density and a functional hole even when the impact is before the voxel surface")

    local elevated=tank()
    function elevated:LocalToWorld(p) return p+Vector(0,0,1034.225) end
    local side,step=16/0.0254,(16/0.0254)/32
    local cases={
        {model=elevated,center=Vector(20,0,60)},
        {model=tank(),center=Vector(20,0,0.5+35.8+side/2-step)},
        {model=tank(),center=Vector(20,shape.halfWidth-26.6-(side/2-step),0.5+24.8+side/2-step)},
        {model={},center=Vector(20,0,60)}
    }
    for _,case in ipairs(cases) do
        region=scene(40,16,case.center)
        local before=V.CloneScanField(region)
        assert(V.QueueGlideTankCrater({},case.model,Vector(-8,0,70),Vector()))
        local edit=queued
        assert(not edit.prepare and edit.floorZ==nil and edit.center.z==70,
            "old floor/cage preflight still controls the blast")
        local _,changed=V.ApplyBrush(region,edit.center,edit.radius,false,edit.seed)
        region.revision=1
        assert(changed and not V.TraceVoxelHull(region,Vector(-50,0,70),Vector(100,0,70),Vector(),Vector()).Hit,
            "chassis altitude or clipped cage still cancels a valid RPG impact")
        for i=0,33^3-1 do
            local _,x,y,z=V.ScanPoint(region,i)
            if x==0 or y==0 or z==0 or x==32 or y==32 or z==32 then
                local key=V.Index(x,y,z,region)
                assert(region.values[key]==before.values[key],"RPG blast modified a sealed cage node")
            end
        end
        V.ApplyBrush(before,edit.center,edit.radius,false,edit.seed)
        for i,value in ipairs(region.values) do assert(value==before.values[i],"RPG tank replay lost its seed or impact") end
    end
    assert(#messages==0,"tank still emits a wall-presence/cage refusal")
    print("PASS: tank altitude above the impact, both reported cage deficits and missing model metadata cannot veto the RPG blast; sealed borders and exact replay remain")

    region=scene(40)
    local before=V.TraceVoxelHull(region,Vector(-80,0,100),Vector(-80,0,-200),Vector(),Vector())
    assert(before.Hit and math.abs(before.HitPos.z)<0.01)
    assert(V.QueueGlideTankCrater({},tank(),Vector(-80,0,0),Vector(0,0,-1)))
    local ground=queued
    V.ApplyBrush(region,ground.center,ground.radius,false,ground.seed) region.revision=1
    local after=V.TraceVoxelHull(region,Vector(-80,0,100),Vector(-80,0,-200),Vector(),Vector())
    assert(after.Hit and after.HitPos.z< -20,"tank blast still preserves a special floor instead of digging like the RPG")
    assert(V.QueueGlideTankCrater({},tank(4),Vector(0,0,70),Vector(1,0,0)) and queued.radius>255)
    assert(not V.QueueGlideTankCrater({},tank(),Vector(0/0,0,70)))
    print("PASS: vertical tank impact excavates the ground like the RPG, large models retain 16-bit crater radii and invalid positions are rejected")
end

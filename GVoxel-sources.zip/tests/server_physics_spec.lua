-- Wire the production scanner/session to the production native-collider queue.
-- Only engine entry points are adapted; no transaction functions are stubbed.
local V=GVoxel
local s,p=_ScanFixture,_VoxelBodyFixture
local savedRelease,savedBSP=V.ReleaseVoxelMovement,V.GetBSPGeometry
net=s.net
util.AddNetworkString=function() end
util.PointContents=s.pointContents util.TraceLine=s.traceLine
V.Trace=s.trace V.CanEdit=s.canEdit V.CanManageScan=s.canEdit
V.ReleaseVoxelMovement=function() return true end
V.GetBSPGeometry=nil
s.advance(100) p.advance(100)

function RunServerPhysicsTests()
    local function tick()
        p.advance(0.02) s.advance(0.02)
        p.hooks["GVoxel.BSPScan"]()
        p.hooks["GVoxel.PropPhysics"]()
    end
    local function finish(predicate)
        for _=1,6000 do tick() if predicate() then return end end
        error("server/physics transaction did not finish")
    end
    V.PlaceRegion(s.ply,16)
    local scan=assert(V.GetScanSession())
    finish(function() return scan.completed and scan.peers[s.ply].done end)
    local r=scan.region
    assert(r.propPhysics.readyRevision==0 and not r.propPhysics.jobs)
    s.receive("vm_scan_ready",{r.id,0})
    local messageStart=#s.messages
    assert(V.EditScannedTerrain(s.ply,48,false))
    finish(function() return scan.editWork and scan.editWork.dirty end)
    assert(not scan.editWork.sent and r.revision==0,"hole sent before native collider preparation")
    assert(scan.editWork.previewSent and not scan.history[1],"client preparation was not started before collision, or leaked into committed history")
    local preview,permit
    for i=messageStart+1,#s.messages do
        local m=s.messages[i]
        if m.name=="vm_scan_prepare" and m.data[1]==r.id then preview=i end
        if m.name=="vm_scan_edit" and m.data[1]==r.id then permit=i end
    end
    assert(preview and not permit,"speculative preparation did not precede publication permission")
    local old={}
    for key,e in pairs(r.propPhysics.colliders) do old[key]=e end
    finish(function() return scan.editWork and scan.editWork.sent end)
    assert(r.propPhysics.preparedRevision==1 and r.propPhysics.readyRevision==0 and r.revision==0)
    for key,e in pairs(old) do assert(r.propPhysics.colliders[key]==e,"physics swapped before display acknowledgement") end
    local cooks=V.PropState.cookStats.count
    s.receive("vm_scan_ready",{r.id,1})
    assert(r.revision==1 and r.propPhysics.readyRevision==1 and not scan.editWork,
        "display acknowledgement did not publish field and colliders together")
    assert(V.PropState.cookStats.count==cooks,"acknowledgement performed a synchronous native cook")
    assert(r.editStats.phases and r.editStats.phases.brush and r.editStats.phases.collision
        and r.editStats.nativeCount>0 and r.editStats.nativeCPU>=0,"per-phase latency/cook diagnostics missing")
    local oldValues=r.values
    s.advance(1) p.advance(1)
    assert(V.EditScannedTerrain(s.ply,48,false))
    finish(function() return scan.editWork and scan.editWork.previewSent end)
    p.setCookFailure(true)
    finish(function() return not scan.editWork end)
    p.setCookFailure(false)
    local aborted=false
    for _,m in ipairs(s.messages) do if m.name=="vm_scan_abort" and m.data[1]==r.id and m.data[2]==2 then aborted=true end end
    assert(aborted and r.revision==1 and r.values==oldValues and not scan.history[2]
        and r.propPhysics.readyRevision==1 and not r.propPhysics.failed,"failed cook published or retained speculative terrain")
    print("PASS: native cook failure after early client preparation sends abort, keeps the previous field/support and excludes the failed revision from replay history")
    assert(V.ShutdownServerScan() and not V.GetScanSession())
    V.ReleaseVoxelMovement=savedRelease V.GetBSPGeometry=savedBSP
    print("PASS: client preparation starts before native cooking, stays out of history until permission; old support survives until ACK; commit performs no native work and records phase/cook timings")
end

local V=GVoxel
function RunVisibilityBridgeTests()
    local settings=V.BSPSkySettings('{"classname" "worldspawn" "skyname" "test_sky"}\n{"classname" "sky_camera" "origin" "128 -256 512" "scale" "16"}')
    assert(settings.name=="test_sky" and settings.camera.scale==16 and settings.camera.origin.z==512,"BSP sky camera/settings lost")
    assert(not V.BSPSkySettings('{"classname" "sky_camera" "origin" "0 0 0" "scale" "0"}').camera,"invalid sky scale accepted")
    -- A room only two units wide falls BETWEEN the former 5x5x5 probe grid.
    -- The huge source face centroid is outside the zone as on compiled maps.
    local data={head=0,faces={},planes={{normal=Vector(1,0,0),distance=7},{normal=Vector(1,0,0),distance=9}},
        nodes={{plane=1,front=1,back=-1},{plane=2,front=-3,back=-2}},
        leaves={{solid=false,cluster=0,area=0,flags=0},{solid=false,cluster=1,area=1,flags=4},{solid=false,cluster=2,area=2,flags=1}}}
    local r=V.NewScanRegion(8800,Vector(),16)
    local yields=0 local origins=V.BSPVisibilityOrigins(data,r,function() yields=yields+1 end)
    local found={}
    for _,p in ipairs(origins) do
        for _,axis in ipairs({"x","y","z"}) do
            assert(p[axis]>=r.origin[axis]-4 and p[axis]<=r.origin[axis]+r.side+4,"visibility origin escaped the local zone")
        end
        local leaf=V.BSPLeaf(data,p) assert(not leaf.solid and leaf.cluster>=0,"PVS origin inside old solid")
        found[leaf.cluster]=true
    end
    assert(found[0] and found[1] and found[2],"thin neighbouring room omitted from visibility bridge")
    assert(yields>0,"visibility preparation cannot yield")
    for _,sample in ipairs({{0,0},{8,4},{10,1}}) do
        local x,flags=sample[1],sample[2]
        local vertices={{pos=Vector(x,0,0)},{pos=Vector(x,1,0)},{pos=Vector(x,0,1)}}
        assert(V.PortalSkyFlags(data,vertices,Vector(0,1,0))==flags,"indoor/2D/3D exit sky classification changed")
    end
    print("PASS: sky settings parsed without executing entity text; exact local PVS origins cover thin rooms missed by coarse grid and stay in valid nearby leaves")
end

function RunNativeVisibilityTests(data)
    assert(data.sky and data.sky.name,"worldspawn sky name missing from real BSP")
    assert(data.sky.camera and data.sky.camera.scale>0,"3D sky camera missing from real BSP")
    local portals=0 for _ in pairs(data.areaPortals) do portals=portals+1 end
    assert(portals>0,"compiled area portal bounds absent")
    for i,center in ipairs({Vector(-2880,-2880,128),Vector(-3072,-2880,160),Vector(-2880,-3072,128)}) do
        local r=V.NewScanRegion(8900+i,center,16)
        local started=os.clock() local yields=0
        local points=V.BSPVisibilityOrigins(data,r,function() yields=yields+1 end)
        local elapsed=(os.clock()-started)*1000
        local represented={}
        for _,p in ipairs(points) do
            local leaf=V.BSPLeaf(data,p)
            assert(not V.BSPSolid(data,p) and leaf.cluster>=0,"compiled visibility point is inside original solid")
            represented[leaf.cluster..":"..leaf.area]=true
        end
        local samples=0
        for z=0,6 do for y=0,6 do for x=0,6 do
            local p=r.origin+Vector(x,y,z)*(r.side/6)
            local leaf=V.BSPLeaf(data,p)
            if leaf.cluster>=0 and not V.BSPSolid(data,p) then
                assert(represented[leaf.cluster..":"..leaf.area],"real neighbouring room omitted from local PVS") samples=samples+1
            end
        end end end
        assert(samples>0 and #points>0 and yields>0,"real bank region contains no tested room")
        print(string.format("PASS: Rockford v2b bank region %d: %d local visibility origins cover %d air probes; %d compiled portals; %.1f ms adapter preparation (not per hole)",i,#points,samples,portals,elapsed))
    end
end

local V=GVoxel
local r=V.NewScanRegion(1901,Vector(-1002.375,-478.375,-143.25),16)
V.PrepareBSPRegion(r,_NATIVE_BSP_DATA,nil,false)
r.values=_NATIVE_TERRAIN_VALUES
local function height(a,b,c,x,y)
    local area=(b.x-a.x)*(c.y-a.y)-(b.y-a.y)*(c.x-a.x)
    if math.abs(area)<1e-8 then return end
    local u=((x-a.x)*(c.y-a.y)-(y-a.y)*(c.x-a.x))/area
    local v=((b.x-a.x)*(y-a.y)-(b.y-a.y)*(x-a.x))/area
    if u>=-1e-5 and v>=-1e-5 and u+v<=1.00001 then return a.z+u*(b.z-a.z)+v*(c.z-a.z) end
end
local total,missing,first=0,0,{}
for y=1,30 do for x=16,30 do
    local faces={}
    for z=14,17 do
        V.ForCellTriangles(r,x,y,z,function(a,b,c,n) faces[#faces+1]={a+r.origin,b+r.origin,c+r.origin} end)
    end
    for _,dx in ipairs({0.23,0.71}) do for _,dy in ipairs({0.27,0.68}) do
        local px,py=r.origin.x+(x+dx)*r.step,r.origin.y+(y+dy)*r.step
        if px> -1010 and px< -700 and py> -780 and py< -180 then
            total=total+1
            local found=false
            for _,t in ipairs(faces) do
                local h=height(t[1],t[2],t[3],px,py)
                if h and h> -180 and h< -120 then found=true break end
            end
            if not found then
                missing=missing+1
                if #first<8 then first[#first+1]=string.format("%d,%d %g,%g density=%s triangles=%d",x,y,px,py,tostring(V.BSPCellUsesDensity(r,x,y,15)),#faces) end
            end
        end
    end end
end end
for _,s in ipairs(first) do print(s) end
assert(total>1000,"terrain footprint not tested")
assert(missing==0,string.format("flat Hammer ground has %d missing surface samples / %d with Source floats",missing,total))
print(string.format("PASS: %d flat Hammer ground coverage samples at actual engine coordinates with float Vectors",total))

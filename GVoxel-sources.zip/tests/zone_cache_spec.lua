function RunZoneCacheTests()
    local V=GVoxel
    local r=V.NewScanRegion(123,Vector(),16)
    for i=0,33^3-1 do r.values[i]=(i%31)-15 end
    local scan={completed=true,region=r,snapshot={values=r.values},history={}}
    local oldMap=game.GetMap game.GetMap=function() return "test_map" end
    local record=assert(V.MakeZoneCache(scan,"Mur banque","header-v1"))
    assert(V.ValidateZoneCache(record,"test_map","header-v1"))
    assert(not V.ValidateZoneCache(record,"other_map","header-v1"),"cache reused on a different BSP")
    assert(not V.ValidateZoneCache(record,"test_map","header-v2"),"outdated BSP fingerprint accepted")
    local value=record.values[19] record.values[19]=0/0
    assert(not V.ValidateZoneCache(record,"test_map","header-v1"),"nonfinite density reached meshing")
    record.values[19]=value
    record.history[1]={center={0,0,0},radius=112,adding=false,seed=441}
    assert(V.ValidateZoneCache(record,"test_map","header-v1"),"valid seeded crater history rejected")
    record.history[1].radius=math.huge
    assert(not V.ValidateZoneCache(record,"test_map","header-v1"),"unbounded cached blast accepted")
    scan.editWork={} assert(not V.MakeZoneCache(scan,"busy","header-v1"),"uncommitted edit saved")
    assert(record.values[1]==r.values[0] and record.values[33^3]==r.values[33^3-1],"zero-based density lost in JSON array")
    game.GetMap=oldMap
    print("PASS: versioned zone cache preserves zero-based field and seeded history, rejects map/BSP changes, corrupt data and uncommitted saves")
end

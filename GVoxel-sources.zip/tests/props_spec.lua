-- Native engine adapter: validates PhysicsFromMesh input and lifecycle, not a
-- replacement VPhysics solver. Mesh geometry itself uses the real field code.
local V=GVoxel
SERVER=true CLIENT=false FCVAR_ARCHIVE=1
MOVETYPE_NONE=0 MOVETYPE_STEP=3 MOVETYPE_VPHYSICS=6 MASK_NPCSOLID=1 MASK_NPCSOLID_BRUSHONLY=1 COLLISION_GROUP_NPC=9 SOLID_NONE=0 SOLID_VPHYSICS=6 EFL_IN_SKYBOX=8 MASK_SOLID_BRUSHONLY=1
local now,sys=100,0
local hooks,commands={},{}
local all,created={},{}
-- GMod intentionally reports worldspawn as invalid through IsValid.
local world={valid=false,IsWorld=function() return true end}
local null={valid=false}
local collisionsChanged,worldQueries,pairsCreated=0,0,0
local failPhysics=false
function IsValid(e) return type(e)=="table" and e.valid~=false end
function CurTime() return now end
function SysTime() sys=sys+0.00001 return sys end
function CreateConVar() return {GetFloat=function() return 0.5 end} end
function ErrorNoHalt() end
game={GetWorld=function() return world end}
hook={Add=function(_,name,fn) hooks[name]=fn end}
concommand={Add=function(name,fn) commands[name]=fn end}
local function physical()
    return {asleep=false,wakes=0,pos=Vector(),motion=true,
        EnableMotion=function(self,on) self.motion=on end,
        GetPos=function(self) return self.pos end,SetPos=function(self,p) self.pos=p end,
        GetAngles=function() return {p=0,y=0,r=0} end,
        WorldToLocal=function(self,p) return p-self.pos end,LocalToWorld=function(self,p) return p+self.pos end,
        ComputeShadowControl=function(self,p) self.shadow=p end,SetVelocity=function() end,
        IsAsleep=function(self) return self.asleep end,Wake=function(self) self.wakes=self.wakes+1 self.asleep=false end}
end
local function entity(class,pos,extent)
    local e={class=class,pos=pos or Vector(),extent=extent or Vector(5,5,5),phys=physical(),flags=0,constraints={}}
    e.bodies={e.phys} e.phys.pos=e.pos e.mt=MOVETYPE_VPHYSICS
    function e:GetClass() return self.class end
    function e:GetPos() return self.pos end
    function e:SetPos(p) self.pos=p end
    function e:WorldSpaceAABB() return self.pos+(self.mins or self.extent*(-1)),self.pos+(self.maxs or self.extent) end
    function e:GetPhysicsObject() return self.phys end
    function e:GetPhysicsObjectCount() return #self.bodies end
    function e:GetPhysicsObjectNum(bone) return self.bodies[bone+1] end
    function e:IsPlayer() return false end
    function e:IsWorld() return false end
    function e:IsNPC() return self.class:sub(1,4)=="npc_" end
    function e:IsNextBot() return false end
    function e:Health() return self.health or 100 end
    function e:GetMoveType() return self.mt end
    function e:GetCollisionBounds() return self.mins or self.extent*(-1),self.maxs or self.extent end
    function e:SetCollisionBounds(low,high) self.mins=low self.maxs=high end
    function e:GetVelocity() return self.velocity or Vector() end
    function e:SetLocalVelocity(v) self.velocity=v end
    function e:SetGroundEntity(e) self.ground=e end
    function e:GetPathDistanceToGoal() return 0 end
    function e:WorldToLocal(p) return p-self.pos end
    function e:LocalToWorld(p) return p+self.pos end
    function e:GetParent() return null end
    function e:IsEFlagSet(f) return bit.band(self.flags,f)~=0 end
    function e:AddEFlags(f) self.flags=bit.bor(self.flags,f) end
    function e:RemoveEFlags(f) self.flags=bit.band(self.flags,bit.bnot(f)) end
    function e:SetNW2Int(_,id) self.network=id end
    function e:CollisionRulesChanged() collisionsChanged=collisionsChanged+1 end
    function e:Remove() self.valid=false end
    function e:Spawn() end
    function e:SetMoveType(mt) self.mt=mt end
    function e:SetSolid() end
    function e:SetCustomCollisionCheck() end
    function e:EnableCustomCollisions() end
    function e:PhysicsFromMesh(vertices,material)
        if failPhysics then return nil end
        assert(#vertices>0 and #vertices%3==0 and material=="dirt")
        assert(#vertices<=128*3,"unbounded triangle soup reached native cooking")
        for _,p in ipairs(vertices) do assert(type(p.x)=="number" and not p.normal,"physics unnecessarily built render vertices") end
        for i=1,#vertices,3 do
            assert(V.PhysicsTriangleUsable(vertices[i],vertices[i+1],vertices[i+2]),"unsafe sliver reached PhysicsFromMesh")
        end
        self.vertices=vertices
        return true
    end
    return e
end
ents={Create=function(class) local e=entity(class) created[#created+1]=e return e end,
    FindInBox=function() return all end}
constraint={GetTable=function(ent) return ent.constraints end,
    NoCollide=function(ent,other,a,b,reverse)
        assert(other==world and a>=0 and a<ent:GetPhysicsObjectCount() and b==0 and reverse,"world collision will not be restored on removal")
        pairsCreated=pairsCreated+1
        ent.activePairs=ent.activePairs or {}
        local pair={valid=true,Remove=function(self)
            self.valid=false ent.activePairs[a]=nil ent.worldDisabled=next(ent.activePairs)~=nil
        end}
        ent.activePairs[a]=pair
        ent.worldDisabled=true ent.pair=pair
        return pair
    end}
util={TraceHull=function(data)
    if data.ignoreworld then return {Hit=false,StartSolid=false,Fraction=1,HitPos=data.endpos,HitNormal=Vector()} end
    worldQueries=worldQueries+1
    assert(data.mask==MASK_SOLID_BRUSHONLY and data.filter(world))
    assert(not data.filter({IsWorld=function() return false end}),"prop world probe includes voxel collider")
    return {StartSolid=data.start.z+data.mins.z< -0.001,AllSolid=false}
end}

function RunPropTests()
    local owner={}
    local r=V.NewScanRegion(901,Vector(),16)
    for i=0,33^3-1 do local p,x,y,z=V.ScanPoint(r,i) r.values[V.Index(x,y,z,r)]=p.z end
    local candidates=0 V.ForChunks(function(x,y,z) if V.CollisionChunkMayHaveSurface(r,x,y,z) then candidates=candidates+1 end end,r)
    assert(candidates==16,"empty/solid chunks entered native collision triangulation")
    local prop=entity("prop_physics",Vector(0,0,30))
    local welded=entity("prop_physics",Vector(30,0,30)) welded.constraints[1]={Type="Weld"}
    local large=entity("prop_physics",Vector(300,0,30),Vector(20,20,20))
    all={prop,welded,large}
    V.PreparePropRegion(r,owner)
    local function tick()
        local before=#created
        hooks["GVoxel.PropPhysics"]()
        assert(#created-before<=4,"native cook count exceeded its hard cap per tick")
    end
    assert(not prop.worldDisabled,"prop bypasses BSP before colliders exist")
    for _=1,20 do now=now+0.02 tick() end
    for _=1,100 do now=now+0.02 tick() if not r.propPhysics.jobs then break end end
    assert(next(r.propPhysics.colliders) and not r.propPhysics.jobs and prop.worldDisabled,"scan did not prepare and transfer an interior body onto voxel support")
    all={}
    r.revision=1 V.QueuePropColliders(r,{})
    local previousCreated=#created
    for _=1,30 do now=now+0.02 tick() end
    assert(#created==previousCreated and not r.propPhysics.jobs and r.propPhysics.initialized,
        "an empty dirty set rebuilt prepared native colliders")
    all={prop,welded,large}
    now=now+0.2 tick()
    assert(not r.propPhysics.jobs and prop.worldDisabled,"body could not use collision prepared during the scan")
    for _=1,100 do now=now+0.02 tick() if not r.propPhysics.jobs then break end end
    assert(not r.propPhysics.jobs and r.propPhysics.readyRevision==1,"initial physics did not commit")
    now=now+0.2 tick()
    assert(prop.worldDisabled and prop.VMPropRegion==r and prop.network==r.id,"ordinary prop cannot enter voxel terrain")
    assert(not welded.worldDisabled and not large.worldDisabled,"unsafe welded/boundary prop was enrolled")
    local pairHook=hooks["GVoxel.PropTerrainPairs"]
    local collider
    for _,e in pairs(r.propPhysics.colliders) do if IsValid(e) then collider=e break end end
    assert(collider and collider.vertices and r.propPhysics.guard.vertices,"missing native terrain/edge collider")
    assert(pairHook(collider,prop)==nil and pairHook(prop,collider)==nil)
    assert(pairHook(collider,welded)==false and pairHook(collider,world)==false,"personal collider affects ordinary BSP users")
    local beforeRules=collisionsChanged
    pairHook(collider,prop)
    assert(collisionsChanged==beforeRules,"ShouldCollide mutated physics rules")
    assert(hooks["GVoxel.ProtectTerrainColliders"](owner,collider)==false)
    local dirty=V.ApplyBrush(r,Vector(0,0,-25),75,false) r.revision=r.revision+1
    local old={}
    for key,e in pairs(r.propPhysics.colliders) do old[key]=e end
    prop.phys.asleep=true
    V.QueuePropColliders(r,dirty)
    assert(r.propPhysics.readyRevision==1 and collider.valid~=false,"old collision removed before staged replacement")
    now=now+0.02 tick()
    local staged={}
    for key,e in pairs(r.propPhysics.staged) do staged[key]=e end
    local current=r.propPhysics.current
    local field=r.propPhysics.field
    local more=V.ApplyBrush(r,Vector(-250,-250,-20),28,false) r.revision=r.revision+1
    V.QueuePropColliders(r,more)
    assert(r.propPhysics.field==field and field.revision==2 and r.propPhysics.targetRevision==2,
        "a new stroke mutated/restarted the frozen collider transaction")
    for key,e in pairs(staged) do
        if not more[key] then assert(r.propPhysics.staged[key]==e,"new disjoint stroke discarded completed collider work") end
    end
    if current and not more[current.key] then assert(r.propPhysics.current==current,"new disjoint stroke restarted a suspended collider") end
    for key,c in pairs(more) do dirty[key]=c end
    for _=1,100 do now=now+0.02 tick() if not r.propPhysics.jobs then break end end
    assert(r.propPhysics.readyRevision==3 and not prop.phys.asleep,"queued collider snapshots did not wake supported props")
    for key,e in pairs(old) do if not dirty[key] then assert(r.propPhysics.colliders[key]==e,"unmodified collider rebuilt") end end
    local centerCollider=r.propPhysics.colliders["2:2:1"]
    local rendered=V.BuildChunk(r,2,2,1)
    assert(IsValid(centerCollider),"missing excavated collider")
    local vertices={} local parts={centerCollider}
    for _,part in ipairs(centerCollider.VMAdditionalColliders or {}) do parts[#parts+1]=part end
    for _,part in ipairs(parts) do
        assert(part.VMActive and pairHook(part,prop)==nil,"a collider part was not activated with its chunk")
        for _,p in ipairs(part.vertices) do vertices[#vertices+1]=p end
    end
    assert(#vertices==#rendered,"split physics mesh does not match excavated render geometry")
    for i,p in ipairs(vertices) do assert(p:DistToSqr(rendered[i].pos)<1e-12) end
    assert(#r.propPhysics.guard.vertices==72,"boundary guard is not a complete two-sided cube")
    local nativeCalls=0
    local player={GetShootPos=function() return Vector(0,0,100) end,GetAimVector=function() return Vector(0,0,-1) end}
    util.TraceLine=function(data)
        nativeCalls=nativeCalls+1
        assert(not data.filter(player) and not data.filter(centerCollider),"hidden prop collider blocks sculpt targeting")
        return {Hit=false,Fraction=1}
    end
    assert(V.TraceSculpt(player,r,400).VoxelScan and nativeCalls>0,"new colliders intercept the digging tool")
    -- World collision stays disabled in a real carved cavity, until the body
    -- exits to native free space or the region safely restores the entry.
    prop:SetPos(Vector(0,0,-30)) tick()
    assert(prop.worldDisabled,"original BSP reactivated inside the hole")
    local previousQueries=worldQueries
    prop.phys.asleep=true
    for _=1,20 do now=now+0.02 tick() end
    assert(worldQueries==previousQueries,"sleeping prop repeatedly traced original world")
    prop.phys.asleep=false prop:SetPos(Vector(330,0,30)) tick()
    assert(not prop.worldDisabled and prop.network==0,"normal collision did not resume at free-space boundary")
    prop:SetPos(Vector(0,0,30)) now=now+0.2 tick()
    assert(prop.worldDisabled,"prop could not reenter after leaving")
    prop:SetPos(Vector(0,0,-30))
    assert(V.ReleasePropRegion(r),"clear could not evacuate ordinary prop")
    assert(not prop.worldDisabled and not prop.VMPropRegion and prop.network==0 and prop.pos.z>=5)
    assert(not prop:IsEFlagSet(EFL_IN_SKYBOX) and not prop.pair.valid,"world collision/network state leaked on clear")
    for _,e in ipairs(created) do assert(e.valid==false,"static collider leaked on clear") end
    -- Failed builds never disable a new prop's world collision.
    local failed=V.NewScanRegion(902,Vector(),16)
    failed.values=r.values failed.revision=1 failPhysics=true all={prop}
    V.PreparePropRegion(failed,owner)
    for _=1,100 do now=now+0.02 tick() if failed.propPhysics.failed then break end end
    assert(failed.propPhysics.failed and not prop.worldDisabled,"failed collider left prop without world collision")
    V.ReleasePropRegion(failed) failPhysics=false
    assert(pairsCreated==2,"prop world constraint duplicated per tick")
    -- A multi-part chunk remains private until every native piece is cooked.
    -- Cancellation must also remove the partial, not-yet-staged collider.
    local originalBuild=V.BuildCollisionChunk
    V.BuildCollisionChunk=function()
        local vertices={}
        for _=1,1200 do
            vertices[#vertices+1]=Vector(0,0,0) vertices[#vertices+1]=Vector(20,0,0) vertices[#vertices+1]=Vector(0,20,0)
        end
        return vertices
    end
    local split=V.NewScanRegion(903,Vector(),16) split.values=r.values split.revision=1
    local soil=entity("prop_physics",Vector(0,0,30))
    all={soil} V.PreparePropRegion(split,owner)
    local createdBefore=#created
    for _=1,100 do
        now=now+0.02 tick()
        if split.propPhysics.current and IsValid(split.propPhysics.current.collider) then break end
    end
    assert(split.propPhysics.current and IsValid(split.propPhysics.current.collider),"partial support job never started")
    assert(not soil.worldDisabled and not split.propPhysics.current.collider.VMActive,"partial collider became active before complete support")
    assert(V.ReleasePropRegion(split),"partial collision job cannot be cancelled")
    for i=createdBefore+1,#created do assert(not created[i].valid,"cancelled partial collider leaked") end
    V.BuildCollisionChunk=originalBuild all={}
    print("PASS: scan prepares native support; empty dirty sets perform zero cooks; arriving bodies wait for complete support")
    print("PASS: native cooks are limited to 128 triangles, elapsed CPU budget and four calls per tick; partial chunks stay inactive and cancel without leaks")
    print("PASS: staged native prop colliders, dirty-only rebuilds, pure pair filters, sleeping bodies, guarded boundaries and safe BSP restoration")
end

_VoxelBodyFixture={entity=entity,physical=physical,hooks=hooks,created=created,
    advance=function(dt) now=now+dt end,setEntities=function(list) all=list end,
    setCookFailure=function(value) failPhysics=value end,
    now=function() return now end}

function RunPropWorldLifetimeTests()
    local r=V.NewScanRegion(916,Vector(),16)
    for i=0,33^3-1 do local p,x,y,z=V.ScanPoint(r,i) r.values[V.Index(x,y,z,r)]=p.z end
    all={}
    V.PreparePropRegion(r,world)
    now=now+0.02 hooks["GVoxel.PropPhysics"]()
    assert(r.propPhysics,"worldspawn failed IsValid and the shared session lost its physics")
    for _=1,200 do now=now+0.02 hooks["GVoxel.PropPhysics"]() if not r.propPhysics.jobs then break end end
    assert(r.propPhysics and r.propPhysics.readyRevision==0 and next(r.propPhysics.colliders))
    assert(V.ReleasePropRegion(r))
    print("PASS: worldspawn is invalid like GMod; shared physics survives until explicit session release")
end

function RunPropAtomicEditTests()
    local r=V.NewScanRegion(915,Vector(),16)
    for i=0,33^3-1 do local p,x,y,z=V.ScanPoint(r,i) r.values[V.Index(x,y,z,r)]=p.z end
    all={}
    V.PreparePropRegion(r,{})
    local function finish(predicate)
        for _=1,3000 do now=now+0.02 hooks["GVoxel.PropPhysics"]() if predicate() then return end end
        error("atomic prop preparation never finished")
    end
    finish(function() return not r.propPhysics.jobs end)
    local old={}
    for key,e in pairs(r.propPhysics.colliders) do old[key]=e end
    local field=V.CloneScanField(r)
    local dirty=V.ApplyBrush(field,Vector(0,0,-25),75,false) field.revision=1
    V.StagePropEdit(r,field,dirty)
    finish(function() return V.PropEditReady(r,1) end)
    assert(r.revision==0 and r.propPhysics.readyRevision==0,"staged physics published before its terrain")
    for key,e in pairs(old) do assert(r.propPhysics.colliders[key]==e and (e==false or IsValid(e)),"old physics retired during staging") end
    for _,e in pairs(r.propPhysics.staged) do if IsValid(e) then assert(not e.VMActive,"staged collider affects current props") end end
    local count=#created
    V.PublishScanField(r,field) V.CommitPropEdit(r)
    assert(r.propPhysics.readyRevision==1 and #created==count,"commit cooked physics instead of swapping prepared colliders")
    for key,e in pairs(old) do if not dirty[key] then assert(r.propPhysics.colliders[key]==e,"distant collider rebuilt") end end
    local committed={}
    for key,e in pairs(r.propPhysics.colliders) do committed[key]=e end
    local nextField=V.CloneScanField(r)
    local nextDirty=V.ApplyBrush(nextField,Vector(50,0,-30),48,false) nextField.revision=2
    failPhysics=true V.StagePropEdit(r,nextField,nextDirty)
    finish(function() return r.propPhysics.failed end)
    assert(not V.PropEditReady(r,2) and r.revision==1,"failed cook published new terrain")
    V.AbortPropEdit(r) failPhysics=false
    for key,e in pairs(committed) do assert(r.propPhysics.colliders[key]==e,"abort destroyed committed colliders") end
    assert(not r.propPhysics.jobs and not r.propPhysics.failed and r.propPhysics.readyRevision==1)
    assert(V.ReleasePropRegion(r))
    print("PASS: native collider staging precedes publication; commit performs zero cooks, retains distant chunks and abort preserves current support")
end

function RunVehicleLightTests()
    local r=V.NewScanRegion(917,Vector(),16)
    for i=0,33^3-1 do local p,x,y,z=V.ScanPoint(r,i) r.values[V.Index(x,y,z,r)]=p.z end
    V.ApplyBrush(r,Vector(0,0,-20),80,false) r.revision=1
    all={} V.PreparePropRegion(r,world)
    for _=1,3000 do now=now+0.02 hooks["GVoxel.PropPhysics"]() if not r.propPhysics.jobs then break end end
    local bodies={}
    for _,class in ipairs({"prop_vehicle_jeep_old","prop_vehicle_jeep","prop_vehicle_airboat","prop_vehicle_prisoner_pod","prop_vehicle_apc","gmod_light","gmod_lamp"}) do
        local e=entity(class,Vector(0,0,30)) bodies[#bodies+1]=e
        if class:find("jeep",1,true) then
            e.wheels={e.phys,physical(),physical(),physical()}
            function e:GetWheelCount() return #self.wheels end
            function e:GetWheel(i) return self.wheels[i+1] end
        elseif class=="gmod_light" then e.constraints[1]={Type="Rope",anchor=world} end
        assert(V.TryEnrollVoxelBody(r,e) and e.worldDisabled,class.." was not transferred to voxel collision")
        local seen={} local count=0
        V.EachVoxelBody(e,function(body) assert(not seen[body],"wheel/body alias visited twice") seen[body]=true count=count+1 end)
        assert(count==(e.wheels and 4 or 1))
        if e.wheels then for _,wheel in ipairs(e.wheels) do assert(wheel.wakes>0,"separate native wheel was not woken") end end
        assert(hooks["GVoxel.PropTerrainPairs"](r.propPhysics.guard,e)==nil,"vehicle/light missed local voxel support")
    end
    local fixed=entity("gmod_light",Vector(0,0,30)) fixed.constraints[1]={Type="Weld"}
    assert(not V.TryEnrollVoxelBody(r,fixed) and not fixed.worldDisabled,"rigid light assembly transferred partially")
    assert(V.ReleasePropRegion(r))
    for _,e in ipairs(bodies) do
        assert(not e.worldDisabled and not e.VMPropRegion,"vehicle/light lost BSP collision on release")
        if e.class=="gmod_light" then assert(e.constraints[1].Type=="Rope","light's user attachment was destroyed") end
    end
    print("PASS: standard Jeep, Jalopy, Airboat, Pod, APC and GMod lights enroll on voxel support; separate wheels wake once; ropes survive, rigid assemblies stay native and BSP collision restores")
end

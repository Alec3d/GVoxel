function RunSingleSessionTests()
    local V=GVoxel
    assert(V.MaxZones==1,"creation still permits several active zones")
    V.ShutdownServerScan()
    local ply=_ScanFixture.ply
    local a={ply=ply,region=V.NewScanRegion(5501,Vector(),16),completed=true,solids=0,rays=0,started=0}
    local b={ply=ply,region=V.NewScanRegion(5502,Vector(2000,0,0),16),completed=true,solids=0,rays=0,started=0}
    V.BeginScanSession(a)
    assert(V.BeginScanSession(b)==false and V.GetScanSession()==a,"second session replaced the persistent zone")
    assert(not V.GetScanSession(5502) and V.GetScanSessions()[5501]==a,"foreign zone id aliases the active session")
    a.peers[ply].done=true a.peers[ply].sent=2 a.peers[ply].acknowledged=0
    local originalCommit=V.CommitScanEdit
    local commits=0
    V.CommitScanEdit=function(s) commits=commits+1 return originalCommit(s) end
    _ScanFixture.receive("vm_scan_ready",{5501,2})
    assert(a.peers[ply].acknowledged==2,"single-zone ACK stopped working")
    for _=1,1000 do _ScanFixture.receive("vm_scan_ready",{5501,2}) end
    assert(commits==1,"replayed ACK repeatedly invoked publication work")
    a.peers[ply].failed=true
    _ScanFixture.receive("vm_scan_ready",{5501,2})
    assert(commits==2 and not a.peers[ply].failed,"duplicate suppression prevented recovery after a failed build")
    V.CommitScanEdit=originalCommit
    V.RemoveScanSession(a)
    assert(not V.GetScanSession(),"individual removal retained an active session")
    print("PASS: one-zone limit rejects a second session without replacing the active terrain, validates ids and retains ACK/removal")
end

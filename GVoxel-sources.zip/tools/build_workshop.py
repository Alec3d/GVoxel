"""Build a reproducible allowlisted Workshop payload without publishing it."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import hashlib
import json
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[1]
DIST=ROOT/'dist'
PAYLOAD=DIST/'workshop'
PAYLOAD.mkdir(parents=True,exist_ok=True)
sources=sorted((ROOT/'lua').rglob('*.lua'))+[ROOT/'addon.json']
expected={p.relative_to(ROOT).as_posix():p.read_bytes() for p in sources}
for p in PAYLOAD.rglob('*'):
    if p.is_file() and p.relative_to(PAYLOAD).as_posix() not in expected:
        assert p.resolve().is_relative_to(PAYLOAD.resolve())
        p.unlink()
for name,data in expected.items():
    target=PAYLOAD/name
    target.parent.mkdir(parents=True,exist_ok=True)
    target.write_bytes(data)
gma=DIST/'gvoxel.gma'
subprocess.run([str(ROOT.parents[3]/'bin/gmad.exe'),'create','-folder',str(PAYLOAD),'-out',str(gma),'-quiet'],check=True)
sys.path.insert(0,str(ROOT/'tests'))
from inspect_vehicle_sources import entries
_,contents=entries(gma)
with gma.open('rb') as stream:
    for name,offset,length in contents:
        assert name in expected and name.startswith('lua/'),name
        stream.seek(offset)
        assert stream.read(length)==expected[name],name
assert {name for name,_,_ in contents}=={name for name in expected if name.startswith('lua/')}
compressed=DIST/'gvoxel-workshop.zip'
with ZipFile(compressed,'w',ZIP_DEFLATED,compresslevel=9) as archive:
    archive.write(gma,gma.name)
manifest={'lua_files':len(contents),'source_bytes':sum(map(len,expected.values())),'gma_bytes':gma.stat().st_size,
    'zip_bytes':compressed.stat().st_size,'sha256':hashlib.sha256(gma.read_bytes()).hexdigest(),
    'files':{name:hashlib.sha256(data).hexdigest() for name,data in expected.items()}}
(DIST/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in manifest.items() if k!='files'},indent=2))

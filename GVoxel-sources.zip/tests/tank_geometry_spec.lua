-- One smooth, floor-clipped blast uses the ordinary sculpt/mesh/SAT pipeline.
-- Also run under float_vectors.lua to exercise Source-sized coordinates.
local V=GVoxel

local function scene(base)
    local data={head=0,
        planes={{normal=Vector(0,0,1),distance=base.z},
            {normal=Vector(1,0,0),distance=base.x},
            {normal=Vector(1,0,0),distance=base.x+40}},
        nodes={{plane=1,front=1,back=-2},{plane=2,front=2,back=-1},{plane=3,front=-1,back=-2}},
        leaves={{solid=false},{solid=true}},faces={}}
    data.faces[1]={normal=Vector(0,0,1),tex={flags=0},
        vertices={base+Vector(-1000,-1000,0),base+Vector(1000,-1000,0),
            base+Vector(1000,1000,0),base+Vector(-1000,1000,0)},
        low=base+Vector(-1000,-1000,0),high=base+Vector(1000,1000,0)}
    for _,x in ipairs({0,40}) do
        data.faces[#data.faces+1]={normal=Vector(x==0 and -1 or 1,0,0),tex={flags=0},
            vertices={base+Vector(x,-1000,0),base+Vector(x,1000,0),
                base+Vector(x,1000,1000),base+Vector(x,-1000,1000)},
            low=base+Vector(x,-1000,0),high=base+Vector(x,1000,1000)}
    end
    local r=V.NewScanRegion(2310,base+Vector(20,0,0),16)
    for i=0,33^3-1 do
        local p,x,y,z=V.ScanPoint(r,i)
        r.values[V.Index(x,y,z,r)]=V.BSPSolid(data,p) and -r.step or r.step
    end
    V.PrepareBSPRegion(r,data)
    return r
end

function RunTankGeometryTests()
    local center=Vector(20,0,58)
    local floorZ=0
    assert(V.BrushSample(Vector(20,0,-10),center,140,0,floorZ)>0,
        "floor-clipped blast removes matter below its floor")
    assert(V.BrushSample(Vector(20,0,10),center,140,0,floorZ)<0)
    assert(V.BrushSample(Vector(20,0,0),center,140,0,floorZ)==0)
    assert(V.BrushInnerRadius(140,0,center.z,floorZ)==58)
    assert(V.BrushInnerRadius(140,0,0,0)==0)
    assert(V.BrushInnerRadius(140,0,-10,0)==0)
    assert(V.BrushInnerRadius(140,0)==140,
        "ordinary smooth sphere changed its guaranteed core")
    for _,seed in ipairs({0,719}) do
        for z=-50,150,10 do
            local p=Vector(20,0,z)
            assert(V.BrushSample(p,center,140,seed,floorZ)
                ==math.max(V.BrushSample(p,center,140,seed),floorZ-p.z))
        end
    end
    print("PASS: floor-clipped smooth/noisy brush samples preserve the floor and expose a safe inscribed core; ordinary spheres retain their previous field")

    -- The requested opening section is 136 x 116 SU. The 40-SU wall and
    -- lattice allowance are included in this sphere's enclosing dimensions.
    local base=Vector(2048,-1024,128)
    local r=scene(base)
    local replay=V.CloneScanField(r)
    center=base+Vector(20,0,58)
    local radius=math.ceil(math.sqrt(68^2+58^2+20^2)+r.step)
    local checkpoints=0
    local dirty,changed=V.ApplyBrush(r,center,radius,false,0,function() checkpoints=checkpoints+1 end,base.z)
    r.revision=1
    assert(changed and next(dirty) and checkpoints>0,
        "tank blast bypassed the ordinary yielding sculpt pipeline")
    V.ApplyBrush(replay,center,radius,false,0,nil,base.z) replay.revision=1
    for i,value in ipairs(r.values) do assert(value==replay.values[i],"clipped blast density differs on replay") end
    assert(#r.bspEdits==1 and r.bspEdits[1].floorZ==base.z-r.origin.z)
    assert(not select(2,V.ApplyBrush(r,center,radius,false,0,nil,base.z)),
        "identical floor-clipped blast is not idempotent")
    assert(not V.BSPBrushUnchanged(r,center,radius,false,nil,base.z-10),
        "changing the floor was mistaken for an identical blast")
    assert(not V.BSPBrushUnchanged(r,center,radius,false,nil),
        "a smooth sphere was mistaken for its clipped counterpart")
    for index,ops in pairs(r.bspCellEditBins) do
        local z=math.floor((index-1)/((r.nx+1)*(r.ny+1)))
        assert((z+1)*r.step>r.bspEdits[1].floorZ-0.001,
            "blast indexed cells wholly below the preserved floor")
        assert(ops[#ops].floorZ==r.bspEdits[1].floorZ)
    end
    print("PASS: one clipped blast reuses yielding sculpt caches, stores local floor coordinates, replays exact density and differentiates floor-only changes")

    local mins,maxs=Vector(-16,-68,0.5),Vector(16,68,116.5)
    local start,finish=base+Vector(-70,0,0),base+Vector(110,0,0)
    local tr=V.TraceVoxelHull(r,start,finish,mins,maxs)
    assert(not tr.Hit and not tr.StartSolid,
        "136 x 116 SU vehicle hull cannot pass through the complete 40-SU wall")
    for _,x in ipairs({-15,20,55}) do
        local ground=V.TraceVoxelHull(r,base+Vector(x,0,40),base+Vector(x,0,-20),Vector(-4,-4,0),Vector(4,4,12))
        assert(ground.Hit and not ground.StartSolid and math.abs(ground.HitPos.z-base.z)<0.02,
            "vehicle floor was removed or left a step under the opening")
        local below=base+Vector(x,0,-8)
        assert(V.TraceVoxelHull(r,below,below,Vector(),Vector()).StartSolid,
            "full-sphere shortcut erased the soil below the clipped blast")
    end
    local wall=V.TraceVoxelHull(r,base+Vector(-70,180,50),base+Vector(110,180,50),Vector(),Vector())
    assert(wall.Hit,"tank blast deleted a distant intact wall")
    for _,offset in ipairs({Vector(0,0,20),Vector(20,30,70),Vector(40,-40,110)}) do
        local p=base+offset
        local a=V.TraceVoxelHull(r,p,p,Vector(-0.1,-0.1,-0.1),Vector(0.1,0.1,0.1))
        local b=V.TraceVoxelHull(replay,p,p,Vector(-0.1,-0.1,-0.1),Vector(0.1,0.1,0.1))
        assert(a.StartSolid==b.StartSolid and a.Hit==b.Hit,"clipped BSP replay changed its collision")
    end
    print("PASS: 136 x 116 SU hull crosses a 40-SU wall after one clipped blast; floor contacts/subsoil and distant walls remain, BSP collision matches replay")

    -- The guaranteed region is a sphere INTERSECTED with the upper half-space,
    -- not only the smaller sphere tangent to the floor. Wholly cut cells far
    -- to either side still need no original BSP/tetrahedron reconstruction.
    local inside,capCell
    local op=r.bspEdits[1]
    local core=V.BrushInnerRadius(radius,nil,op.center.z,op.floorZ)
    for index in pairs(r.bspCellEditBins) do
        local i=index-1
        local x,y,z=i%(r.nx+1),math.floor(i/(r.nx+1))%(r.ny+1),math.floor(i/((r.nx+1)*(r.ny+1)))
        local low=Vector(x,y,z)*r.step
        local high=low+Vector(r.step,r.step,r.step)
        local far=math.max(math.abs(low.x-op.center.x),math.abs(high.x-op.center.x))^2
            +math.max(math.abs(low.y-op.center.y),math.abs(high.y-op.center.y))^2
            +math.max(math.abs(low.z-op.center.z),math.abs(high.z-op.center.z))^2
        if far<(radius-1/64)^2 then
            if low.z>op.floorZ+1/64 and far>core^2 and not inside then
                inside={index=index,x=x,y=y,z=z}
                local cell=V.BSPCell(r,x,y,z)
                assert(cell.solids and #cell.solids==0 and #cell.triangles==0 and not cell.tetrahedra,
                    "wholly removed upper cell rebuilt the BSP outside the small inscribed sphere")
            elseif low.z<=op.floorZ and high.z>op.floorZ then capCell=index end
        end
    end
    assert(inside and capCell,"test did not exercise upper-core and floor-crossing cells")
    local bucket,key=V.TerrainCellCache(r,"bspCells",inside.x,inside.y,inside.z)
    bucket[key]=nil
    local usesDensity=V.BSPCellUsesDensity
    V.BSPCellUsesDensity=function(region,x,y,z)
        assert(region~=r or x~=inside.x or y~=inside.y or z~=inside.z,
            "fully cut upper cell queried displacement/base geometry before its early-out")
        return usesDensity(region,x,y,z)
    end
    local earlyOK,earlyResult=pcall(V.BSPCell,r,inside.x,inside.y,inside.z)
    V.BSPCellUsesDensity=usesDensity
    assert(earlyOK,earlyResult)
    local history=V.CloneScanField(r)
    V.RecordBSPBrush(history,center,radius+1,false,nil,nil,base.z)
    assert(#history.bspCellEditBins[inside.index]==1,
        "wholly removed upper cell retained an unnecessary edit history")
    assert(#history.bspCellEditBins[capCell]==2,
        "floor-crossing cell dropped the history supporting its lower solid")
    local below=base+Vector(20,0,-8)
    assert(V.TraceVoxelHull(r,below,below,Vector(),Vector()).StartSolid,
        "upper-core shortcut crossed the preserved floor")
    print("PASS: clipped upper-core cells skip BSP reconstruction and obsolete history while cells crossing the floor retain their support")

    -- Cover the cap normal in both renderer and sculpt ray: radial sphere
    -- normals would tilt the preserved horizontal floor and its cursor.
    -- A solid BSP leaf has no old floor face at this height. Every cap vertex
    -- below therefore comes from the new clipped brush rather than the map.
    local capped=V.NewScanRegion(2311,base+Vector(20,0,0),16)
    for i=1,#capped.values do capped.values[i]=-capped.step end
    V.PrepareBSPRegion(capped,{head=-1,nodes={},planes={},leaves={{solid=true}},faces={}})
    local capDirty=V.ApplyBrush(capped,center,radius,false,0,nil,base.z) capped.revision=1
    local hit=V.TraceScanRegion(capped,base+Vector(20,0,35),Vector(0,0,-1),60)
    assert(hit and math.abs(hit.HitPos.z-base.z)<0.02 and hit.HitNormal.z>0.999,
        "floor-clipped brush left a radial aiming normal on its planar cap")
    local capVertices=0
    for _,chunk in pairs(capDirty) do
        for _,vertex in ipairs(V.BuildChunk(capped,chunk[1],chunk[2],chunk[3])) do
            local p=vertex.pos+Vector(chunk[1],chunk[2],chunk[3])*(capped.step*8)+capped.origin
            if math.abs(p.z-base.z)<0.02 and math.abs(p.x-base.x-20)<10 and math.abs(p.y-base.y)<10 then
                assert(vertex.normal.z>0.999,"floor-clipped render cap retained radial normals")
                capVertices=capVertices+1
            end
        end
    end
    assert(capVertices>0,"regression did not inspect a rendered floor cap")
    print("PASS: clipped floor has matching upward render and sculpt normals")
end
